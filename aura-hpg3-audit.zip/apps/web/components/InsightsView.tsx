'use client';

import React, { useState, useMemo } from 'react';
import { computeAverageTimedSessionMinutes } from '../lib/activityDuration';
import { toInsightsObservation, todayDateKey, lastNCalendarDateKeys, isInCalendarMonth } from '../lib/insightsTimezone';
import { addDaysToDateStr } from '../lib/timezone';
import { classifyInsightsWindow, insightsWindowWeight } from '../lib/insightsWindowAlignment';
import { deriveInsightsEvidenceState } from '../lib/insightsEvidence';
import {
  formatGoalProgressLabel,
  formatGoalActivityRhythmWeeklyProgressLabel,
  formatGoalActivityRhythmRemainingCapacityLabel,
  type GoalActivityRhythmView,
} from '../lib/goalsPresentation';
import type { DerivedGoalActivityState } from '../lib/goals';
import { colors, spacing, typography, radius } from './theme';
import { PageHeader, SegmentedControl, SurfaceCard, StatusBadge, TextButton, EmptyState } from './ui';
import { LoggedEntryItem } from './CalendarViewSection';
import { InsightsDailyBriefingSection } from './InsightsDailyBriefingSection';

// ============================================================
// Insights V1 PR4 -- Read-Only Goal and Planning Reporting. Wire-shaped
// types mirroring GET /api/insights/reporting's own JSON response
// exactly (never a client-side re-derivation of any count/status --
// every number here is already-computed server-side, reusing the SAME
// business rules Goal Detail itself uses, see insightsReporting.ts).
// ============================================================
export interface GoalReportingActivityView {
  id: string;
  title: string;
  derivedState: DerivedGoalActivityState;
  currentValue: number | null;
  rhythm: GoalActivityRhythmView;
}
export interface GoalReportingGoalView {
  id: string;
  title: string;
  kind: 'RHYTHM' | 'FINITE' | 'MIXED' | 'EMPTY';
  activities: GoalReportingActivityView[];
  progress: { total: number; completed: number; hasOngoingRhythmActivity: boolean };
}
/**
 * Insights V1 PR5 -- Evidence-Backed Improvement Prompts. Wire-shaped
 * mirror of ImprovementSuggestion (lib/improvementSignals.ts) exactly as
 * GET /api/insights/reporting now returns it under `suggestions`. No
 * client-side re-derivation of eligibility -- every field here is
 * already-decided server-side; this component only renders and (session-
 * locally) dismisses.
 */
export interface SuggestionView {
  id: string;
  signal: 'AWAITING_CONFIRMATION' | 'PLANNING_OVERLOAD' | 'REPEATED_RESCHEDULING' | 'WEEKLY_GOAL_OPPORTUNITY';
  message: string;
  evidence: string;
  cta: {
    label: string;
    action: 'OPEN_PLAN_REVIEW' | 'OPEN_GOAL';
    goalId?: string;
    /** Insights V1 PR7 -- mirrors ImprovementSuggestionCta.planId/planFilter
     * (improvementSignals.ts) exactly; see onOpenPlanReview below. */
    planId?: string;
    planFilter?: 'AWAITING_CONFIRMATION';
  };
  subjectId: string;
}

export interface GoalReportingResponse {
  range: { from: string; to: string };
  goals: GoalReportingGoalView[];
  planningStatus: {
    confirmedCompleted: number;
    scheduled: number;
    skipped: number;
    cancelled: number;
    rescheduled: number;
    awaitingConfirmation: number;
    total: number;
  };
  awaitingConfirmation: {
    count: number;
    items: { id: string; title: string; plannedStartAt: string; plannedEndAt: string }[];
    truncated: boolean;
  };
  limitations: string[];
  /** Insights V1 PR5 -- `null` only when nothing is eligible to show
   * (a real empty state); never an empty-array placeholder standing in
   * for "still loading". */
  suggestions?: { primary: SuggestionView | null; secondary: SuggestionView[] } | null;
}

/**
 * Insights Timezone Consistency V1 -- a calendar date's weekday, formatted
 * deterministically from its "YYYY-MM-DD" string rather than from an
 * already-local `Date` object. A calendar date has exactly one weekday
 * regardless of what clock time within that date you evaluate it at, so
 * anchoring the lookup at UTC noon (nowhere near a UTC-midnight boundary)
 * and formatting with an explicit `timeZone: 'UTC'` makes this immune to
 * the executing browser/process's own local timezone -- unlike the
 * previous `d.toLocaleDateString(...)` call, which implicitly read
 * whatever `Date` object it was handed.
 */
function formatWeekdayLabel(dateKey: string, style: 'narrow' | 'short'): string {
  const [year, month, day] = dateKey.split('-').map(Number);
  const anchor = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
  return anchor.toLocaleDateString('en-US', { weekday: style, timeZone: 'UTC' });
}

// Pending Activity Visual Consistency V1 -- this used to be a second,
// independently-declared LoggedEntryItem shape that lacked syncStatus,
// even though the runtime objects this component receives (the exact
// same array page.tsx passes to Timeline/CalendarViewSection) always
// carry it. Reusing the canonical type (already the one Timeline.tsx
// imports) instead of maintaining a third incompatible copy.
export type { LoggedEntryItem };

interface InsightsViewProps {
  /** AURA DB3 -- the SAME per-user identity DB2's Home card already uses
   * (HomeDashboard.tsx's own `userId`), threaded here only so a future
   * per-user view-state key could reuse it if ever needed; the
   * Personalized Daily Briefing section itself needs no persistence
   * (Insights, unlike Home, has no "first visit of the day" expand/
   * compact state to track). */
  userId?: string;
  onOpenBirthProfile?: () => void;
  /** Insights Timezone Consistency V1 -- the owner's current Timing
   * Location IANA timezone (`user.timezone`), the sole timezone source for
   * every calendar-day/daypart calculation in this component (This Month,
   * past-7-days trend, 30-day heatmap, streak, time-of-day pattern
   * counts). Never Birth Location, Event Location, SavedPerson, or SHARED
   * context -- and never implicitly the browser's own local timezone,
   * which every one of those calculations previously read via bare
   * `new Date().getFullYear()/getHours()`-style getters. Required (not
   * optional) because every render site already has `user.timezone`
   * available at the point it renders this component, matching the same
   * pattern PlanWithAuraView's own `timezone` prop already uses. */
  timezone: string;
  logEntries?: LoggedEntryItem[];
  assistantInsight?: {
    reflectionCount: number;
    alignedDays: number;
    unalignedDays: number;
    /** Insights Correctness + Historical Integrity V1 -- a signed
     * percentage-POINT delta on the 0-1 outcome scale (never a relative
     * percent), or `null` when there isn't yet a valid two-sided
     * comparison (one of the two groups has zero check-ins). Renamed from
     * the old peakFlowLiftPercent, which conflated a relative-percent
     * formula with an absolute-percent formula depending on the
     * denominator, and could not represent a negative result at all. */
    alignmentDeltaPoints: number | null;
    insightText: string;
    /** Canonical Aura Fit Insights V1 -- a SEPARATE, activity-aware metric
     * from every other value on this object and from this component's own
     * window-only C1 calculations (analytics.alignmentScore/
     * monthAlignmentScore/past7Days/distribution). Only observations with
     * a genuinely known canonical ActivityProfile.id are eligible; NULL/
     * unknown-id logs contribute nothing to averageScore, never a
     * fabricated neutral value. See apps/web/lib/insightsAuraFit.ts. */
    auraFit: {
      state: 'NO_DATA' | 'LIMITED' | 'AVAILABLE';
      eligibleCount: number;
      totalCount: number;
      averageScore: number | null;
    };
  } | null;
  /** Insights V1 PR4 -- Goal/planning reporting, fetched the same way as
   * assistantInsight above (GET /api/insights/reporting). `null` renders
   * this section's own empty state -- never a fabricated zero. */
  goalReporting?: GoalReportingResponse | null;
  /** Insights V1 PR7 -- explicit fetch-lifecycle state for `goalReporting`
   * (AURA_INSIGHTS_V1_PRODUCT_COMPLETION_AUDIT.md §19 scenario 20: the
   * reporting block previously had no loading indicator at all, so it was
   * reproducibly blank for 1-3+ seconds on every fresh navigation with
   * nothing telling the user more was coming). 'loading' shows an
   * accessible, honest loading state (never a fabricated 0); 'error' shows
   * a real, visible error instead of staying silently blank forever;
   * 'loaded' is the existing, unchanged behavior (goalReporting itself
   * decides empty-vs-populated, as before). Defaults to 'loaded' so every
   * existing caller/test that doesn't pass this prop keeps today's exact
   * behavior. */
  goalReportingStatus?: 'loading' | 'loaded' | 'error';
  /** Insights V1 PR5 -- the CTA destination for every suggestion whose
   * action is 'OPEN_PLAN_REVIEW' (Signals 1, 2, 4): the existing Plan tab,
   * where Reschedule/Log/Skip already exist for every relevant plan (the
   * SAME destination page.tsx's own handleOpenPlan/onPlanMyDay already
   * route to). 'OPEN_GOAL' (Signal 3) needs no callback: it links directly
   * to the existing /goals/[goalId] route.
   *
   * Insights V1 PR7 (finding F-4) -- now receives the clicked suggestion's
   * own `cta` so the Plan tab can open the SPECIFIC plan the suggestion is
   * about (`planId`) or a pre-filtered review list when more than one
   * plan is the subject (`planFilter`), instead of always landing on the
   * generic new-activity composer. The argument is optional (omitted for
   * PLANNING_OVERLOAD, which is about the whole day, not one plan) --
   * every existing caller that ignores its argument keeps working. */
  onOpenPlanReview?: (target?: { planId?: string; planFilter?: 'AWAITING_CONFIRMATION' }) => void;
}

export function InsightsView({ userId, onOpenBirthProfile, timezone, logEntries = [], assistantInsight, goalReporting, goalReportingStatus = 'loaded', onOpenPlanReview }: InsightsViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'patterns' | 'trends' | 'streaks'>('overview');

  // Insights V1 PR5 -- session-local dismissal ONLY (ticket section H: no
  // DB write, no new persistence model). Plain component state -- cleared
  // on remount/reload, never persisted across devices or visits, and
  // never claimed to be. Keyed by `SuggestionView.id` (stable per
  // underlying evidence), so a dismissed suggestion cannot reappear from
  // an unrelated rerender of this component as long as its own id is
  // unchanged.
  const [dismissedSuggestionIds, setDismissedSuggestionIds] = useState<ReadonlySet<string>>(new Set());
  const dismissSuggestion = (id: string) => setDismissedSuggestionIds((prev) => new Set(prev).add(id));

  // ---------------------------------------------------------------------------
  // ANALYTICS & INSIGHTS ENGINE
  // ---------------------------------------------------------------------------
  const analytics = useMemo(() => {
    // Pending Activity Visual Consistency V1 -- product decision: pending
    // (not yet server-confirmed) HabitLogs must not influence evidence-based
    // Insights. Every calculation below uses confirmedLogEntries, never the
    // raw logEntries prop -- only the separate Recent Activity Trail render
    // (outside this useMemo) is allowed to show the full, unfiltered list,
    // and only because it visibly labels pending entries rather than
    // treating them as settled evidence.
    const confirmedLogEntries = logEntries.filter((entry) => entry.syncStatus !== 'pending');
    const totalActivities = confirmedLogEntries.length;
    const now = new Date();

    // Insights Timezone Consistency V1 -- the ONE timezone-normalization
    // pass every date-bucketed calculation below reads from, instead of
    // each individually calling `new Date(e.loggedAt).getFullYear()/
    // getHours()`-style getters (which read the executing browser/
    // process's own local timezone, not the owner's Timing Location).
    // Cached per entry (a Map keyed by entry id) so the 30-day heatmap, the
    // 7-day trend, the daypart counts, the streak set, and the This-Month
    // filter below all agree on the exact same observation for a given
    // log, computed once.
    const observations = new Map(confirmedLogEntries.map((entry) => [entry.id, toInsightsObservation(new Date(entry.loggedAt), timezone)]));
    const observationOf = (entry: LoggedEntryItem) => observations.get(entry.id)!;

    // 1. 30-Day Habit Consistency Heatmap -- 30 Timing-Location calendar
    // dates ending today (inclusive), DST-safe date-string stepping
    // (never millisecond arithmetic).
    const heatmapDateKeys = lastNCalendarDateKeys(timezone, now, 30);
    const heatmapDays = heatmapDateKeys.map((dateKey) => {
      const day = Number(dateKey.split('-')[2]);
      const dayLogs = confirmedLogEntries.filter((e) => observationOf(e).dateKey === dateKey);

      return {
        dateStr: dateKey,
        dayNum: day,
        weekday: formatWeekdayLabel(dateKey, 'narrow'),
        count: dayLogs.length,
      };
    });

    // 2. 7-Day Weekly Alignment Trend -- 7 Timing-Location calendar dates
    // ending today (date axis unchanged, Insights Timezone Consistency V1).
    //
    // Insights Window-Alignment Semantic Correction V1 -- the score itself
    // is now built entirely from the shared classifyInsightsWindow()/
    // INSIGHTS_WINDOW_BAND_WEIGHT taxonomy (SUPPORTIVE=1.0, NEUTRAL=0.7,
    // FRICTION=0.0 -- GULIKA lands in NEUTRAL, never the top tier). Two
    // corrections from the previous formula:
    //   - No artificial 30% floor: an all-friction day now genuinely
    //     shows 0%, not a floor-clamped 30%.
    //   - An empty day (no logs at all) is `null`, not a fabricated 75%.
    //     A day with no observation is not the same claim as a day that
    //     was observed and scored moderately -- rendering must show a
    //     distinct "no data" state, never silently substitute a number.
    const past7DateKeys = lastNCalendarDateKeys(timezone, now, 7);
    const past7Days = past7DateKeys.map((dateKey) => {
      const dayLogs = confirmedLogEntries.filter((e) => observationOf(e).dateKey === dateKey);

      const score: number | null =
        dayLogs.length > 0
          ? Math.round((dayLogs.reduce((sum, e) => sum + insightsWindowWeight(e.activeWindow), 0) / dayLogs.length) * 100)
          : null;

      return {
        dayLabel: formatWeekdayLabel(dateKey, 'short'),
        score,
        count: dayLogs.length,
      };
    });

    // Insights Evidence & Sample-Size Integrity V1 -- the "Avg" figure
    // badged onto the "7-Day Solar Alignment Trend" card must actually be
    // a 7-day statistic. It previously displayed `alignmentScore` (the
    // full up-to-400-day lifetime figure defined below) next to a chart
    // whose seven bars only ever cover the last 7 days -- a real
    // mislabeling, not just a rounding quirk. Computed the same way C1
    // computes every other alignment percentage: a weighted mean across
    // every individual HabitLog whose calendar date falls in the 7-day
    // range (never a naive average of the seven already-rounded daily
    // percentages above, which would give a single-log day the same
    // weight as a ten-log day). Logs outside past7DateKeys never
    // contribute -- observationOf(e).dateKey is compared by exact string
    // equality against the Set below, so a log from day 8+ back cannot
    // leak in. Null (not 0) when zero logs fall in the 7-day range at
    // all -- the same NO_DATA-vs-real-zero distinction every other fixed
    // metric in this PR now preserves.
    const past7DateKeySet = new Set(past7DateKeys);
    const past7Logs = confirmedLogEntries.filter((e) => past7DateKeySet.has(observationOf(e).dateKey));
    const sevenDayAlignmentScore: number | null =
      past7Logs.length > 0
        ? Math.round((past7Logs.reduce((sum, e) => sum + insightsWindowWeight(e.activeWindow), 0) / past7Logs.length) * 100)
        : null;

    // 3. Time-of-Day Pattern Counts -- daypart boundaries UNCHANGED
    // (05:00/12:00/17:00/22:00), derived in the Timing Location timezone
    // instead of browser-local. This remains a plain clock-hour bucket,
    // deliberately distinct from a Panchang solar window (Abhijit/Rahu
    // Kalam/etc.) -- see classifyDayPart()'s own doc comment.
    const todCounts = { morning: 0, afternoon: 0, evening: 0, night: 0 };
    confirmedLogEntries.forEach((e) => {
      const dayPart = observationOf(e).dayPart;
      if (dayPart === 'MORNING') todCounts.morning++;
      else if (dayPart === 'AFTERNOON') todCounts.afternoon++;
      else if (dayPart === 'EVENING') todCounts.evening++;
      else todCounts.night++;
    });

    // Active Day Streak Calculation -- consecutive Timing-Location
    // calendar dates with >=1 log, walking back via date-string stepping
    // (never millisecond arithmetic, so a DST transition anywhere in the
    // walk can't skip or duplicate a day). Padded "YYYY-MM-DD" keys
    // throughout (the old unpadded "y-m-d" variant is gone). Control flow
    // is otherwise IDENTICAL to the previous browser-local version,
    // including the existing today-may-be-empty grace.
    const loggedDaysSet = new Set(confirmedLogEntries.map((entry) => observationOf(entry).dateKey));

    let streak = 0;
    let cursor = todayDateKey(timezone, now);

    while (true) {
      if (loggedDaysSet.has(cursor)) {
        streak++;
        cursor = addDaysToDateStr(cursor, -1);
      } else {
        if (streak === 0) {
          const yesterday = addDaysToDateStr(cursor, -1);
          if (loggedDaysSet.has(yesterday)) {
            streak++;
            cursor = addDaysToDateStr(yesterday, -1);
            continue;
          }
        }
        break;
      }
    }

    // Insights Timezone Consistency V1, brief section 13 -- "This Month"
    // month-scoped metrics. A SEPARATE computation from the full-history
    // ("lifetime", up to INSIGHTS_HISTORY_DAYS) values below: totalActivities/
    // alignmentScore (unscoped) are still used elsewhere in this component
    // (the Patterns tab's Planning Loop copy, the Trends tab's 7-Day trend
    // average) and must NOT be redefined to mean "this month" there --
    // only the "This Month" card's own four stats are month-scoped.
    // `streak` deliberately stays the overall/current streak (brief
    // section 14): the card's own label is "day streak", not "day streak
    // this month", and truncating a genuine ongoing streak at a month
    // boundary would misrepresent the user's real data, not correct it.
    const todayKey = todayDateKey(timezone, now);
    const [currentYear, currentMonth] = todayKey.split('-').map(Number);
    const monthEntries = confirmedLogEntries.filter((e) => isInCalendarMonth(observationOf(e).dateKey, currentYear, currentMonth));
    const monthTotalActivities = monthEntries.length;
    let monthWeightedAlignment = 0;
    let monthAuraGuidedCount = 0;
    monthEntries.forEach((entry) => {
      monthWeightedAlignment += insightsWindowWeight(entry.activeWindow);
      const source = entry.logSource ?? 'MANUAL';
      if (source === 'AURA_PLANNED' || source === 'AURA_DO_NOW') monthAuraGuidedCount++;
    });
    // Insights Evidence & Sample-Size Integrity V1 -- null (not 0) when
    // there are no current-month activities at all. "0 activities" and "3
    // activities that all happened to be friction-only" are different
    // claims; the old `: 0` fallback rendered both as an identical "0%",
    // indistinguishable from a real, measured worst-case score. The
    // "This Month" card's own evidence-state gating (below) decides how
    // to present a null vs. a LIMITED vs. an AVAILABLE score -- this
    // computation only needs to stop fabricating a number that was never
    // observed.
    const monthAlignmentScore: number | null = monthTotalActivities > 0 ? Math.min(100, Math.max(0, Math.round((monthWeightedAlignment / monthTotalActivities) * 100))) : null;
    const monthAuraGuidedRate: number | null = monthTotalActivities > 0 ? Math.round((monthAuraGuidedCount / monthTotalActivities) * 100) : null;
    // Insights Evidence & Sample-Size Integrity V1 -- the shared 0/1-2/3+
    // boundary (apps/web/lib/insightsEvidence.ts), reused rather than a
    // bespoke threshold, applied to the "This Month" card's own natural
    // evidence unit: current-month HabitLog count. Drives whether the
    // card shows a NO_DATA/LIMITED/AVAILABLE presentation for its two
    // percentage stats -- the factual activity count and streak always
    // display regardless of this state (facts may be shown immediately;
    // only percentages/comparisons need to respect the evidence count).
    const monthEvidenceState = deriveInsightsEvidenceState(monthTotalActivities);

    // Window Breakdown
    let weightedAlignment = 0;
    let frictionCount = 0;
    let auraPlannedCount = 0;
    let auraDoNowCount = 0;
    let manualCount = 0;
    let overrideCautionCount = 0;
    let auraPlannedAlignment = 0;
    let manualAlignment = 0;

    const windowCounts: Record<string, number> = {};
    const frictionLogs: LoggedEntryItem[] = [];

    confirmedLogEntries.forEach((entry) => {
      const win = (entry.activeWindow || 'NEUTRAL').toUpperCase().replace(/_/g, ' ');
      windowCounts[win] = (windowCounts[win] || 0) + 1;

      // Insights Window-Alignment Semantic Correction V1 -- the per-entry
      // timing weight now comes ONLY from the shared window-band
      // classification, never from logSource or activitySignificance.
      // "Aura guided" (provenance -- did Aura suggest this?) and "timing
      // pattern" (was this logged during a supportive/neutral/friction
      // window?) are deliberately independent claims; Aura suggesting an
      // activity must not, by itself, change how well-timed that activity
      // is judged to have been.
      const entryScore = insightsWindowWeight(entry.activeWindow);
      const source = entry.logSource ?? 'MANUAL';
      weightedAlignment += entryScore;

      if (source === 'AURA_PLANNED') {
        auraPlannedCount++;
        auraPlannedAlignment += entryScore;
      } else if (source === 'AURA_DO_NOW') {
        auraDoNowCount++;
      } else if (source === 'OVERRIDE_CAUTION') {
        overrideCautionCount++;
      } else {
        manualCount++;
        manualAlignment += entryScore;
      }

      if (classifyInsightsWindow(entry.activeWindow) === 'FRICTION') {
        frictionCount++;
        frictionLogs.push(entry);
      }
    });

    // Insights Evidence & Sample-Size Integrity V1 -- null (not 0) with
    // zero logs. Previously this fallback was defended as "real or zero,
    // no placeholder values" -- true for a genuine friction-only history,
    // but a brand-new user with NO history at all is a different claim
    // ("nothing observed yet") from one whose logs were observed and
    // scored the worst possible way ("observed, and it was 0"). This
    // value has no direct render consumer as of this PR (the 7-Day
    // card's "Avg" badge now uses sevenDayAlignmentScore, its own
    // correctly 7-day-scoped figure, above) but is fixed here too since
    // it remains part of this component's public analytics shape.
    const alignmentScore: number | null =
      totalActivities > 0
        ? Math.min(100, Math.max(0, Math.round((weightedAlignment / totalActivities) * 100)))
        : null;

    const resolvedDurations = confirmedLogEntries.map((e) => e.durationMinutes ?? 30);
    const totalMinutes = resolvedDurations.reduce((sum, minutes) => sum + minutes, 0);
    const formattedHours = `${(totalMinutes / 60).toFixed(1)} hrs`;
    const auraGuidedCount = auraPlannedCount + auraDoNowCount;
    const plannedAlignmentScore = auraPlannedCount > 0 ? Math.round((auraPlannedAlignment / auraPlannedCount) * 100) : 0;
    const manualAlignmentScore = manualCount > 0 ? Math.round((manualAlignment / manualCount) * 100) : 0;
    // Insights Evidence & Sample-Size Integrity V1 -- a comparative "lift"
    // sentence now also requires the two groups' COMBINED observation
    // count to reach AVAILABLE (3+), not merely that both groups are
    // non-empty. Previously 1 Aura-planned + 1 manual log (the weakest
    // possible non-degenerate comparison) was already enough to produce
    // "Aura-planned logs are X points more aligned than manual logs" --
    // comparative language from two single data points. Each GROUP still
    // only needs >=1 (never require 3 in each group in V1, per design);
    // only the combined total needs to clear the shared evidence bar.
    const planningLift =
      auraPlannedCount > 0 && manualCount > 0 && deriveInsightsEvidenceState(auraPlannedCount + manualCount) === 'AVAILABLE'
        ? plannedAlignmentScore - manualAlignmentScore
        : null;

    const distribution = Object.entries(windowCounts).map(([winName, count]) => ({
      name: winName,
      count,
      percentage: totalActivities > 0 ? Math.round((count / totalActivities) * 100) : 0,
    }));

    // Behavioral patterns computed from the user's actual logs. Hidden until
    // there's enough data to say anything meaningful.
    const patterns: { icon: string; color: string; title: string; text: string }[] = [];
    if (totalActivities >= 3) {
      const topWindow = Object.entries(windowCounts).sort((a, b) => b[1] - a[1])[0];
      if (topWindow) {
        patterns.push({
          icon: '🎯',
          color: '#4ade80',
          title: 'Most-used window',
          text: `${topWindow[1]} of your ${totalActivities} activities (${Math.round((topWindow[1] / totalActivities) * 100)}%) happen during ${topWindow[0]} windows.`,
        });
      }

      // Only timed activities (durationMinutes > 0) participate in this
      // average -- an INSTANT completion isn't a session with a length.
      // null (no timed entries at all yet) hides the stat rather than
      // claiming "sessions average 0 minutes". Insights Evidence &
      // Sample-Size Integrity V1 -- the overall totalActivities >= 3 gate
      // above does NOT guarantee 3 TIMED entries (e.g. 3 total activities
      // where only 1 has a nonzero duration previously still produced
      // "Your sessions average N minutes" from a single observation, with
      // no count disclosed at all). This pattern now requires its own
      // evidence unit -- timed entries -- to independently reach
      // AVAILABLE (3+) before the behavioral "average" claim is made.
      const timedDurationsCount = resolvedDurations.filter((minutes) => minutes > 0).length;
      const avgMinutes = computeAverageTimedSessionMinutes(resolvedDurations);
      if (avgMinutes !== null && deriveInsightsEvidenceState(timedDurationsCount) === 'AVAILABLE') {
        patterns.push({
          icon: '⏱️',
          color: '#38bdf8',
          title: 'Session length',
          text: `Your sessions average ${avgMinutes} minutes.`,
        });
      }

      // Insights Evidence & Sample-Size Integrity V1 -- comparative
      // language ("most consistent time") now requires a STRICT winner.
      // Previously a tie (e.g. 1/1/1 across three dayparts, or 2/2/1)
      // still emitted this pattern because only `topTod[1] > 0` was
      // checked -- an arbitrary Object.entries/sort ordering, not a real
      // behavioral signal, was being reported as "most consistent". No
      // percentage-margin threshold is introduced (deliberately out of
      // scope for this PR) -- a strict greater-than against the
      // runner-up is enough to stop reporting a coin-flip as a pattern.
      const todEntries = Object.entries(todCounts).sort((a, b) => b[1] - a[1]);
      const topTod = todEntries[0];
      const runnerUpTod = todEntries[1];
      const hasStrictTodWinner = Boolean(topTod && topTod[1] > 0 && (!runnerUpTod || topTod[1] > runnerUpTod[1]));
      if (topTod && hasStrictTodWinner) {
        patterns.push({
          icon: '☀️',
          color: '#facc15',
          title: 'Time of day',
          text: `${topTod[0].charAt(0).toUpperCase() + topTod[0].slice(1)} is your most consistent time — ${topTod[1]} of ${totalActivities} activities.`,
        });
      }
    }

    return {
      totalActivities,
      streak,
      formattedHours,
      alignmentScore,
      auraPlannedCount,
      auraDoNowCount,
      auraGuidedCount,
      manualCount,
      overrideCautionCount,
      plannedAlignmentScore,
      manualAlignmentScore,
      planningLift,
      distribution,
      frictionLogs,
      heatmapDays,
      past7Days,
      sevenDayAlignmentScore,
      todCounts,
      patterns,
      // Insights Timezone Consistency V1 -- "This Month" card values only;
      // see the computation above for why these are separate from
      // totalActivities/alignmentScore/streak above.
      monthTotalActivities,
      monthAlignmentScore,
      monthAuraGuidedRate,
      monthEvidenceState,
    };
  }, [logEntries, timezone]);

  const patterns = analytics.patterns;

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
        paddingBottom: 24,
        fontFamily: 'sans-serif',
        color: '#f8fafc',
      }}
    >
      <PageHeader title="Insights" subtitle="Patterns from your journey." />

      <SegmentedControl
        options={(['overview', 'patterns', 'trends', 'streaks'] as const).map((tab) => ({
          value: tab,
          label: tab.charAt(0).toUpperCase() + tab.slice(1),
        }))}
        value={activeSubTab}
        onChange={setActiveSubTab}
      />

      {/* ==================== TAB 1: OVERVIEW ==================== */}
      {activeSubTab === 'overview' && (
        <>
          {/* Insights V1 PR4 -- Goal and planning reporting, placed FIRST
           * in the existing Overview hierarchy (architecture audit's own
           * suggested ordering: confirmed progress, Goals this week,
           * planning patterns, awaiting confirmation -- ahead of the
           * existing Alignment/This-Month cards below, never replacing
           * them). Renders nothing extra when goalReporting is absent
           * (still loading, or the fetch failed) -- no fabricated
           * placeholder numbers. */}
          {/* Insights V1 PR5 -- "Aura suggests", placed ahead of PR4's own
           * reporting section (the most immediately actionable thing a
           * user can do, ahead of the detail they'd act ON). Renders
           * nothing when there is no eligible suggestion at all, or when
           * every eligible one has been dismissed this session -- a real
           * empty state, never a fabricated placeholder. */}
          {/* Insights V1 PR7 -- an immediate, accessible loading state for
           * this entire block (AURA_INSIGHTS_V1_PRODUCT_COMPLETION_AUDIT.md
           * §19 scenario 20: previously nothing rendered here at all while
           * the fetch was in flight, reproducibly for 1-3+ seconds on every
           * fresh navigation, with no indication more content was coming).
           * `role="status"`/`aria-live="polite"` so assistive tech
           * announces it without stealing focus; a single compact card
           * (not five separate skeletons) keeps layout shift small while
           * still clearly NOT looking like real, populated data -- no
           * number, no card chrome matching the real cards below. */}
          {/* AURA DB3 -- the Personalized Daily Briefing, placed FIRST in
           * Overview (ahead of PR4's own Goal/planning reporting and
           * PR5's "Aura suggests" below), matching this exact section's
           * own established "newest addition goes first, never replaces
           * what's below" precedent. Entirely self-contained (its own
           * fetch/loading/error/unavailable states) -- renders its own
           * card regardless of goalReportingStatus, never blocked by or
           * blocking the existing Goal/suggestion loading below. */}
          <InsightsDailyBriefingSection userId={userId} timezone={timezone} onOpenBirthProfile={onOpenBirthProfile} />

          {goalReportingStatus === 'loading' && (
            <SurfaceCard role="status" ariaLive="polite">
              <div style={{ display: 'flex', alignItems: 'center', gap: spacing.sm }}>
                <StatusBadge label="Loading" tone="neutral" />
                <span style={{ fontSize: 13, color: colors.textSecondary }}>Loading your Insights…</span>
              </div>
            </SurfaceCard>
          )}

          {/* A real, visible error instead of the previous silent
           * console.error-only failure, which left this entire block
           * permanently blank with no way for the user to tell "there's
           * nothing to show" apart from "this is broken". No fabricated
           * metric is ever substituted. */}
          {goalReportingStatus === 'error' && (
            <SurfaceCard accentColor={colors.danger} role="alert">
              <div style={typography.sectionEyebrow}>Insights</div>
              <div style={{ fontSize: 14, color: colors.textPrimary, marginTop: spacing.sm }}>
                We couldn&rsquo;t load your Insights summary right now.
              </div>
              <div style={{ ...typography.meta, marginTop: spacing.xs }}>
                Your other Insights below are unaffected. Try reloading in a moment.
              </div>
            </SurfaceCard>
          )}

          {goalReportingStatus === 'loaded' && goalReporting?.suggestions && (
            <AuraSuggestsSection
              suggestions={goalReporting.suggestions}
              dismissedIds={dismissedSuggestionIds}
              onDismiss={dismissSuggestion}
              onOpenPlanReview={onOpenPlanReview}
            />
          )}

          {goalReportingStatus === 'loaded' && goalReporting && <GoalPlanningReportingSection reporting={goalReporting} />}

          {assistantInsight && (
            <SurfaceCard accentColor={colors.positive}>
              <div style={typography.sectionEyebrow}>Your Alignment</div>
              {/* Insights Correctness + Historical Integrity V1 -- the
                * signed delta is shown as-is (never clamped to 0, which
                * would misrepresent a genuinely negative result as "no
                * difference"); a null delta (not enough two-sided evidence
                * yet) shows a plain "Not enough data yet" state instead of
                * a fabricated number. */}
              {assistantInsight.alignmentDeltaPoints !== null ? (
                <div style={{ fontSize: 32, color: colors.textPrimary, fontWeight: 850, marginTop: spacing.sm }}>
                  {assistantInsight.alignmentDeltaPoints > 0 ? '+' : ''}
                  {assistantInsight.alignmentDeltaPoints} pts
                </div>
              ) : (
                <div style={{ fontSize: 16, color: colors.textSecondary, fontWeight: 700, marginTop: spacing.sm }}>
                  Not enough data yet
                </div>
              )}
              <div style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 1.4, marginTop: spacing.xs }}>
                {assistantInsight.insightText}
              </div>
              <div style={{ ...typography.meta, marginTop: spacing.sm }}>
                {assistantInsight.reflectionCount} check-ins · {assistantInsight.alignedDays} aligned days
              </div>
            </SurfaceCard>
          )}

          {/* This Month -- brief section 50: a lighter 2x2 inline treatment
           * instead of four separately-bordered boxes.
           *
           * Insights Timezone Consistency V1 (brief section 13): activities/
           * Aura-guided%/supportive-windows% are now genuinely scoped to
           * the current Timing-Location calendar month (analytics.month*),
           * not the full up-to-400-day history this card previously,
           * silently, drew from. `streak` deliberately stays the overall/
           * current streak (brief section 14) -- this card's label never
           * promised "day streak this month", and truncating a real
           * ongoing streak at a month boundary would be a regression.
           *
           * Insights Evidence & Sample-Size Integrity V1 -- the two
           * PERCENTAGE stats (Aura guided / supportive windows) now
           * respect analytics.monthEvidenceState (the shared 0/1-2/3+
           * boundary applied to monthTotalActivities); the two FACTUAL
           * stats (activities count, streak) always display, since facts
           * may be shown immediately regardless of evidence. NO_DATA
           * never shows "0%" as though zero were measured; LIMITED shows
           * a single compact early-signal caption instead of two bold
           * percentages carrying the same visual authority as a mature
           * (3+) month; AVAILABLE is the pre-existing, unchanged
           * percentage-tile presentation. */}
          <div>
            <div style={typography.sectionEyebrow}>This Month</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: `${spacing.sm}px ${spacing.lg}px`, marginTop: spacing.sm }}>
              <InlineStat value={analytics.monthTotalActivities} label="activities" color={colors.positive} />
              <InlineStat value={analytics.streak} label="day streak" color={colors.caution} />
              {analytics.monthEvidenceState === 'AVAILABLE' && (
                <>
                  <InlineStat value={`${analytics.monthAuraGuidedRate}%`} label="Aura guided" color={colors.info} />
                  <InlineStat value={`${analytics.monthAlignmentScore}%`} label="supportive windows" color={colors.traditional} />
                </>
              )}
            </div>
            {analytics.monthEvidenceState === 'LIMITED' && (
              <div style={{ ...typography.meta, marginTop: spacing.sm }}>
                Early signal · based on {analytics.monthTotalActivities} {analytics.monthTotalActivities === 1 ? 'activity' : 'activities'} this month
              </div>
            )}
            {analytics.monthEvidenceState === 'NO_DATA' && (
              <div style={{ ...typography.meta, marginTop: spacing.sm }}>
                No activities logged this month yet
              </div>
            )}
          </div>

          {/* Aura Fit -- Canonical Aura Fit Insights V1 (C3). A SEPARATE,
           * activity-aware metric from Alignment/This Month above (C1,
           * window-only) -- driven entirely by assistantInsight.auraFit
           * (server-computed, apps/web/lib/insightsAuraFit.ts), never by
           * this component's own `analytics` useMemo. Only observations
           * with a genuinely known canonical ActivityProfile.id are
           * eligible; NO_DATA/LIMITED never show a fabricated percentage. */}
          {assistantInsight && (
            <SurfaceCard accentColor={colors.traditional}>
              <div style={typography.sectionEyebrow}>Aura Fit</div>

              {assistantInsight.auraFit.state === 'AVAILABLE' && (
                <>
                  <div style={{ fontSize: 32, color: colors.textPrimary, fontWeight: 850, marginTop: spacing.sm }}>
                    {assistantInsight.auraFit.averageScore}%
                  </div>
                  <div style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 1.4, marginTop: spacing.xs }}>
                    Activity-aware fit for this month's recognized Aura activities.
                  </div>
                </>
              )}

              {assistantInsight.auraFit.state === 'LIMITED' && (
                <>
                  <div style={{ fontSize: 16, color: colors.textSecondary, fontWeight: 700, marginTop: spacing.sm }}>
                    Building up
                  </div>
                  <div style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 1.4, marginTop: spacing.xs }}>
                    Based on {assistantInsight.auraFit.eligibleCount} {assistantInsight.auraFit.eligibleCount === 1 ? 'activity' : 'activities'} with known Aura context. Log a few more recognized activities to see your monthly Aura Fit.
                  </div>
                </>
              )}

              {assistantInsight.auraFit.state === 'NO_DATA' && (
                <div style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 1.4, marginTop: spacing.sm }}>
                  {assistantInsight.auraFit.totalCount > 0
                    ? "This month's logged activities don't yet have recognized Aura context."
                    : 'Aura Fit becomes available as you log activities from Good Right Now suggestions that Aura recognizes.'}
                </div>
              )}

              {assistantInsight.auraFit.state !== 'NO_DATA' && (
                <div style={{ ...typography.meta, marginTop: spacing.sm }}>
                  Based on {assistantInsight.auraFit.eligibleCount} of {assistantInsight.auraFit.totalCount} logged activities this month
                </div>
              )}

              <div style={{ fontSize: 11, color: colors.textFaint, lineHeight: 1.4, marginTop: spacing.xs }}>
                Aura Fit reflects the specific activity; Alignment above reflects the broader timing window.
              </div>
            </SurfaceCard>
          )}

          {/* Your Patterns -- brief section 51: made more prominent, simple
           * rows/dividers instead of a card full of individually-bordered
           * row cards. */}
          <div>
            <div style={typography.sectionEyebrow}>Your Patterns</div>
            <div style={{ display: 'flex', flexDirection: 'column', marginTop: spacing.sm }}>
              {patterns.length === 0 && (
                <span style={{ fontSize: 13, color: colors.textFaint, lineHeight: 1.4 }}>
                  Log at least 3 activities to start seeing patterns — computed from your own data.
                </span>
              )}
              {patterns.map((item, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: spacing.md,
                    padding: `${spacing.md}px 0`,
                    borderTop: idx > 0 ? `1px solid ${colors.borderSubtle}` : 'none',
                  }}
                >
                  <span style={{ fontSize: 18, flexShrink: 0 }} aria-hidden="true">{item.icon}</span>
                  <span style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 1.4 }}>{item.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Window Distribution -- brief section 53: keep the existing
           * data, simple bars only. */}
          <SurfaceCard padding={spacing.xl}>
            <div style={{ ...typography.sectionEyebrow, marginBottom: spacing.lg }}>Window Distribution</div>

            {analytics.distribution.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.md }}>
                {analytics.distribution.map((item) => (
                  <div key={item.name} style={{ display: 'flex', flexDirection: 'column', gap: spacing.xs }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                      <span style={{ fontWeight: 650, color: colors.textSecondary }}>{item.name}</span>
                      <span style={{ fontFamily: 'var(--as-font-mono)', color: colors.textMuted }}>
                        {item.count} logs ({item.percentage}%)
                      </span>
                    </div>
                    <div style={{ width: '100%', height: 6, background: colors.borderSubtle, borderRadius: radius.sm, overflow: 'hidden' }}>
                      <div
                        style={{
                          height: '100%',
                          width: `${item.percentage}%`,
                          // Insights Window-Alignment Semantic Correction V1 --
                          // shared classification (GULIKA lands in NEUTRAL/
                          // colors.info here, same as before this change since
                          // this particular bar-color check never treated
                          // Gulika as positive, but now centralized rather than
                          // an independent local check).
                          background:
                            classifyInsightsWindow(item.name) === 'FRICTION'
                              ? colors.danger
                              : classifyInsightsWindow(item.name) === 'SUPPORTIVE'
                              ? colors.positive
                              : colors.info,
                          borderRadius: radius.sm,
                          transition: 'width 0.3s ease',
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState title="No activity logs yet." description="Start logging from Home to see your patterns here." />
            )}
          </SurfaceCard>

          {/* Things to watch -- brief section 54: was "Friction Guardrail
           * Alerts" in error-red styling, which read as too technical/
           * alarming for ordinary advisory information. Caution (gold)
           * styling now, calmer copy; internal naming/semantics (still
           * driven by analytics.frictionLogs -- Rahu Kalam/Yama logs)
           * unchanged. */}
          {analytics.frictionLogs.length > 0 && (
            <SurfaceCard accentColor={colors.caution} style={{ background: colors.cautionSoft }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: spacing.sm, color: colors.caution, fontSize: 13, fontWeight: 750 }}>
                <span aria-hidden="true">☀️</span>
                <span>Things to watch</span>
              </div>
              <p style={{ fontSize: 12, color: colors.textSecondary, marginTop: spacing.xs, lineHeight: 1.4 }}>
                You logged {analytics.frictionLogs.length} {analytics.frictionLogs.length === 1 ? 'activity' : 'activities'} during caution windows. For important activities, Aura may suggest a more supportive time.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.xs, marginTop: spacing.sm }}>
                {analytics.frictionLogs.map((log) => (
                  <div key={log.id} style={{ fontSize: 12, color: colors.textSecondary, background: 'rgba(15, 23, 42, 0.4)', padding: '6px 10px', borderRadius: radius.sm, display: 'flex', justifyContent: 'space-between' }}>
                    <span>• {log.activityTitle}</span>
                    <span style={{ fontFamily: 'var(--as-font-mono)', opacity: 0.8 }}>{log.activeWindow}</span>
                  </div>
                ))}
              </div>
            </SurfaceCard>
          )}
        </>
      )}

      {/* ==================== TAB 2: PATTERNS ==================== */}
      {activeSubTab === 'patterns' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div
            style={{
              background: 'var(--as-surface-raised, #0f172a)',
              border: '1px solid rgba(74, 222, 128, 0.22)',
              borderRadius: 16,
              padding: 16,
            }}
          >
            <span style={{ fontSize: 10, fontFamily: 'monospace', textTransform: 'uppercase', color: '#4ade80', letterSpacing: '0.05em', fontWeight: 700 }}>
              Planning Loop
            </span>
            <p style={{ fontSize: 12, color: '#cbd5e1', margin: '8px 0 0', lineHeight: 1.45 }}>
              {analytics.auraGuidedCount > 0
                ? `${analytics.auraGuidedCount} of your ${analytics.totalActivities} activities came through Aura suggestions or planned moments.`
                : 'Plan or accept a few Aura suggestions to compare guided timing against your manual activities.'}
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 14 }}>
              <MiniStat value={analytics.auraPlannedCount} label="Planned" color="#4ade80" />
              <MiniStat value={analytics.auraDoNowCount} label="Do Now" color="#38bdf8" />
              <MiniStat value={analytics.overrideCautionCount} label="Overrides" color="#fb7185" />
            </div>
            {analytics.planningLift !== null && (
              <div style={{ marginTop: 12, color: analytics.planningLift >= 0 ? '#4ade80' : '#fb7185', fontSize: 12, fontWeight: 750 }}>
                {/* Insights Evidence & Sample-Size Integrity V1 -- kept
                  * explicitly observational/past-tense ("were... in your
                  * logged history"), never causal ("Aura improves...",
                  * "following Aura made you..."). Aura-guided activities
                  * were, by construction, already timed favorably by the
                  * recommendation engine before the user acted on them --
                  * a higher score among them is expected by that
                  * construction, not proof the user personally performs
                  * better during those windows. */}
                Aura-planned activities were {Math.abs(analytics.planningLift)} points {analytics.planningLift >= 0 ? 'more aligned' : 'less aligned'} than manual activities in your logged history.
              </div>
            )}
          </div>

          {/* Time of Day Segment Cards */}
          <div
            style={{
              background: 'var(--as-surface-raised, #0f172a)',
              border: '1px solid var(--as-border, #1e293b)',
              borderRadius: 16,
              padding: 16,
            }}
          >
            <span style={{ fontSize: 10, fontFamily: 'monospace', textTransform: 'uppercase', color: '#4ade80', letterSpacing: '0.05em', fontWeight: 700 }}>
              Peak Energy Windows (Time of Day)
            </span>
            <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 4, lineHeight: 1.4 }}>
              Distribution of logged activities across diurnal solar segments.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10, marginTop: 14 }}>
              <TODCard title="Morning (5AM-12PM)" count={analytics.todCounts.morning} icon="🌅" color="#facc15" />
              <TODCard title="Afternoon (12PM-5PM)" count={analytics.todCounts.afternoon} icon="☀️" color="#38bdf8" />
              <TODCard title="Evening (5PM-10PM)" count={analytics.todCounts.evening} icon="🌆" color="#c084fc" />
              <TODCard title="Night (10PM-5AM)" count={analytics.todCounts.night} icon="🌙" color="#818cf8" />
            </div>
          </div>

          <div
            style={{
              background: 'var(--as-surface-raised, #0f172a)',
              border: '1px solid var(--as-border, #1e293b)',
              borderRadius: 16,
              padding: 16,
            }}
          >
            <span style={{ fontSize: 10, fontFamily: 'monospace', textTransform: 'uppercase', color: '#4ade80', letterSpacing: '0.05em', fontWeight: 700 }}>
              Deep Pattern Analysis
            </span>
            <p style={{ fontSize: 12, color: '#94a3b8', marginTop: 4, lineHeight: 1.4 }}>
              Correlating habit execution timestamps against optimal Vedic energy windows.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 14 }}>
              {patterns.length === 0 && (
                <span style={{ fontSize: 12, color: '#94a3b8', lineHeight: 1.4 }}>
                  Log at least 3 activities to start seeing patterns. This analysis builds itself from your own history.
                </span>
              )}
              {patterns.map((item, idx) => (
                <div
                  key={idx}
                  style={{
                    background: 'rgba(30, 41, 59, 0.6)',
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    borderRadius: 12,
                    padding: 14,
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 6,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 18 }}>{item.icon}</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: item.color }}>{item.title}</span>
                  </div>
                  <p style={{ fontSize: 12, color: '#e2e8f0', margin: 0, lineHeight: 1.4 }}>{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 3: TRENDS ==================== */}
      {activeSubTab === 'trends' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* 7-Day Interactive Alignment Bar Chart */}
          <div
            style={{
              background: 'var(--as-surface-raised, #0f172a)',
              border: '1px solid var(--as-border, #1e293b)',
              borderRadius: 16,
              padding: 16,
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontSize: 10, fontFamily: 'monospace', textTransform: 'uppercase', color: '#38bdf8', letterSpacing: '0.05em', fontWeight: 700 }}>
                7-Day Solar Alignment Trend
              </span>
              {/* Insights Evidence & Sample-Size Integrity V1 -- this badge
                * previously showed analytics.alignmentScore, the full
                * up-to-400-day lifetime figure, mislabeled as a 7-day
                * statistic next to a chart that only ever covers the last
                * 7 days. Now sevenDayAlignmentScore, computed strictly
                * from HabitLogs whose calendar date falls within the same
                * 7-day range the bars below represent -- null (never a
                * fabricated 0%) when zero logs fall in that range. */}
              <span style={{ fontSize: 11, color: '#4ade80', fontFamily: 'monospace', fontWeight: 600 }}>
                Avg: {analytics.sevenDayAlignmentScore !== null ? `${analytics.sevenDayAlignmentScore}%` : '—'}
              </span>
            </div>
            <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 4, lineHeight: 1.4 }}>
              Daily alignment score based on favorable vs. friction activity timing.
            </p>

            {/* FIXED: Bar Chart Track Container with explicit 80px height */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', height: 140, marginTop: 16, padding: '0 8px 8px 8px' }}>
              {analytics.past7Days.map((day, idx) => (
                <div key={idx} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end', gap: 6, flex: 1 }}>
                  {/* Insights Window-Alignment Semantic Correction V1 -- a
                    * null score (no logs that day) renders as "—", never a
                    * fabricated percentage; the bar track stays empty
                    * rather than showing a filled bar for a day with no
                    * observation at all. */}
                  <span style={{ fontSize: 9, fontFamily: 'monospace', color: '#94a3b8' }}>{day.score !== null ? `${day.score}%` : '—'}</span>

                  {/* Fixed Track Container */}
                  <div style={{ width: 18, height: 80, background: 'rgba(255, 255, 255, 0.05)', borderRadius: 4, display: 'flex', alignItems: 'flex-end', overflow: 'hidden' }}>
                    {day.score !== null && (
                      <div
                        style={{
                          width: '100%',
                          height: `${Math.max(day.score, 15)}%`,
                          background: day.score > 70 ? '#4ade80' : day.score > 50 ? '#38bdf8' : '#fb6b6b',
                          borderRadius: 4,
                          transition: 'height 0.3s ease',
                        }}
                      />
                    )}
                  </div>
                  <span style={{ fontSize: 10, color: '#e2e8f0', fontWeight: 600 }}>{day.dayLabel}</span>
                </div>
              ))}
            </div>
          </div>

          <div
            style={{
              background: 'var(--as-surface-raised, #0f172a)',
              border: '1px solid var(--as-border, #1e293b)',
              borderRadius: 16,
              padding: 16,
            }}
          >
            <span style={{ fontSize: 10, fontFamily: 'monospace', textTransform: 'uppercase', color: '#94a3b8', letterSpacing: '0.05em' }}>
              Window Session Frequency
            </span>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 14 }}>
              {analytics.distribution.map((item) => (
                <div key={item.name} style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                    <span style={{ fontWeight: 600, color: '#f8fafc' }}>{item.name}</span>
                    <span style={{ fontFamily: 'monospace', color: '#38bdf8' }}>{item.count} total sessions</span>
                  </div>
                  <div style={{ width: '100%', height: 8, background: '#1e293b', borderRadius: 4, overflow: 'hidden' }}>
                    <div
                      style={{
                        height: '100%',
                        width: `${item.percentage}%`,
                        background: '#38bdf8',
                        borderRadius: 4,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 4: STREAKS ==================== */}
      {activeSubTab === 'streaks' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Active Streak Banner */}
          <div
            style={{
              background: 'var(--as-surface-raised, #0f172a)',
              border: '1px solid var(--as-border, #1e293b)',
              borderRadius: 16,
              padding: 20,
              textAlign: 'center',
            }}
          >
            <div style={{ fontSize: 42, margin: '0 0 8px 0' }}>🔥</div>
            <div style={{ fontSize: 28, fontWeight: 800, color: '#facc15' }}>{analytics.streak} Days</div>
            <div style={{ fontSize: 12, color: '#94a3b8', marginTop: 4 }}>Active Logging Streak</div>
          </div>

          {/* 30-Day Activity Heatmap Matrix */}
          <div
            style={{
              background: 'var(--as-surface-raised, #0f172a)',
              border: '1px solid var(--as-border, #1e293b)',
              borderRadius: 16,
              padding: 16,
            }}
          >
            <span style={{ fontSize: 10, fontFamily: 'monospace', textTransform: 'uppercase', color: '#facc15', letterSpacing: '0.05em', fontWeight: 700 }}>
              30-Day Habit Consistency Heatmap
            </span>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8, marginTop: 14 }}>
              {analytics.heatmapDays.map((day) => {
                let cellColor = 'rgba(255, 255, 255, 0.05)';
                let textColor = '#64748b';
                if (day.count >= 3) {
                  cellColor = '#22c55e';
                  textColor = '#020617';
                } else if (day.count === 2) {
                  cellColor = '#4ade80';
                  textColor = '#020617';
                } else if (day.count === 1) {
                  cellColor = 'rgba(74, 222, 128, 0.3)';
                  textColor = '#4ade80';
                }

                return (
                  <div
                    key={day.dateStr}
                    style={{
                      background: cellColor,
                      border: '1px solid rgba(255, 255, 255, 0.06)',
                      borderRadius: 8,
                      padding: '8px 4px',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <span style={{ fontSize: 9, color: textColor, fontFamily: 'monospace' }}>{day.weekday}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: textColor, marginTop: 2 }}>{day.dayNum}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Logging History */}
          <div
            style={{
              background: 'var(--as-surface-raised, #0f172a)',
              border: '1px solid var(--as-border, #1e293b)',
              borderRadius: 16,
              padding: 16,
            }}
          >
            <span style={{ fontSize: 10, fontFamily: 'monospace', textTransform: 'uppercase', color: '#94a3b8', letterSpacing: '0.05em' }}>
              Recent Activity Trail
            </span>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
              {logEntries.slice(0, 5).map((entry) => (
                <div
                  key={entry.id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '8px 12px',
                    borderRadius: 10,
                    background: 'rgba(30, 41, 59, 0.5)',
                    fontSize: 12,
                  }}
                >
                  <div style={{ minWidth: 0 }}>
                    <span style={{ color: '#f8fafc', fontWeight: 600 }}>{entry.activityTitle}</span>
                    <div style={{ marginTop: 3, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <SourceBadge source={entry.logSource ?? 'MANUAL'} />
                      {/* Pending Activity Visual Consistency V1 -- this recent-activity
                       * display is allowed to show a not-yet-confirmed entry (unlike
                       * every evidence-based calculation above, which excludes it via
                       * confirmedLogEntries), but only when it's visibly labeled as
                       * such -- never presented identically to a confirmed log. */}
                      {entry.syncStatus === 'pending' && <StatusBadge label="Pending sync" tone="caution" />}
                    </div>
                  </div>
                  <span style={{ color: '#4ade80', fontFamily: 'monospace', fontSize: 11, whiteSpace: 'nowrap' }}>{entry.activeWindow}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Insights V1 PR5 -- "Aura suggests". One compact section, never another
 * dashboard card grid: the primary suggestion renders prominently, up to
 * two secondary ones render as lightweight single lines below it (ticket
 * section G/J). Every suggestion already carries its own evidence-backed,
 * calm-toned copy (lib/improvementSignals.ts's own approved strings) --
 * this component adds no new wording of its own beyond the CTA button
 * label and the dismiss control. Dismissal is session-local only (this
 * component's own `dismissedIds` state, owned by the parent
 * InsightsView instance) -- reloading the page or revisiting later shows
 * the suggestion again if it is still eligible, which this component
 * never promises otherwise.
 */
function AuraSuggestsSection({
  suggestions,
  dismissedIds,
  onDismiss,
  onOpenPlanReview,
}: {
  suggestions: { primary: SuggestionView | null; secondary: SuggestionView[] };
  dismissedIds: ReadonlySet<string>;
  onDismiss: (id: string) => void;
  onOpenPlanReview?: (target?: { planId?: string; planFilter?: 'AWAITING_CONFIRMATION' }) => void;
}) {
  const visiblePrimary = suggestions.primary && !dismissedIds.has(suggestions.primary.id) ? suggestions.primary : null;
  // A dismissed PRIMARY leaves its own slot empty rather than promoting a
  // secondary into it -- promoting would silently change what "primary"
  // meant mid-session from the same server response, never a re-ranking
  // this component is allowed to perform on its own.
  const visibleSecondary = suggestions.secondary.filter((s) => !dismissedIds.has(s.id));

  if (!visiblePrimary && visibleSecondary.length === 0) return null;

  const handleCta = (suggestion: SuggestionView) => {
    // Insights V1 PR7 (finding F-4) -- thread the suggestion's own
    // planId/planFilter through so the Plan tab can open the specific
    // plan (or a pre-filtered review list) this suggestion is about,
    // instead of always landing on the generic new-activity composer.
    if (suggestion.cta.action === 'OPEN_PLAN_REVIEW') {
      onOpenPlanReview?.({ planId: suggestion.cta.planId, planFilter: suggestion.cta.planFilter });
    }
    // OPEN_GOAL is rendered as a real <a href="/goals/...">  below --
    // no click handler needed for it.
  };

  return (
    <SurfaceCard accentColor={colors.info}>
      <div style={typography.sectionEyebrow}>Aura Suggests</div>

      {visiblePrimary && (
        <div style={{ marginTop: spacing.sm, display: 'flex', flexDirection: 'column', gap: spacing.xs }}>
          <div style={{ fontSize: 15, color: colors.textPrimary, lineHeight: 1.45 }}>{visiblePrimary.message}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: spacing.md, marginTop: 2 }}>
            {visiblePrimary.cta.action === 'OPEN_GOAL' && visiblePrimary.cta.goalId ? (
              <a
                href={`/goals/${visiblePrimary.cta.goalId}`}
                style={{ fontSize: 13, fontWeight: 700, color: colors.info, textDecoration: 'none' }}
              >
                {visiblePrimary.cta.label} &rarr;
              </a>
            ) : (
              <TextButton onClick={() => handleCta(visiblePrimary)} color={colors.info}>{visiblePrimary.cta.label}</TextButton>
            )}
            <TextButton onClick={() => onDismiss(visiblePrimary.id)} color={colors.textSecondary} ariaLabel="Dismiss this suggestion">
              Dismiss
            </TextButton>
          </div>
        </div>
      )}

      {visibleSecondary.length > 0 && (
        <div style={{ marginTop: visiblePrimary ? spacing.md : spacing.sm, display: 'flex', flexDirection: 'column', gap: spacing.xs }}>
          {visibleSecondary.map((suggestion) => (
            <div key={suggestion.id} style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: spacing.sm }}>
              <span style={{ fontSize: 13, color: colors.textSecondary, lineHeight: 1.4 }}>{suggestion.message}</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: spacing.sm, flexShrink: 0 }}>
                {suggestion.cta.action === 'OPEN_GOAL' && suggestion.cta.goalId ? (
                  <a href={`/goals/${suggestion.cta.goalId}`} style={{ fontSize: 12, fontWeight: 700, color: colors.info, textDecoration: 'none' }}>
                    {suggestion.cta.label}
                  </a>
                ) : (
                  <TextButton onClick={() => handleCta(suggestion)} color={colors.info} style={{ fontSize: 12 }}>{suggestion.cta.label}</TextButton>
                )}
                <TextButton onClick={() => onDismiss(suggestion.id)} color={colors.textSecondary} ariaLabel="Dismiss this suggestion" style={{ fontSize: 12 }}>
                  &times;
                </TextButton>
              </div>
            </div>
          ))}
        </div>
      )}
    </SurfaceCard>
  );
}

/**
 * Insights V1 PR4 -- the four-part Goal/planning reporting hierarchy
 * (confirmed progress, Goals this week, planning patterns, awaiting
 * confirmation), reusing the EXACT same presentation helpers Goal Detail
 * already uses (formatGoalProgressLabel/formatGoalActivityRhythmWeeklyProgressLabel/
 * formatGoalActivityRhythmRemainingCapacityLabel) -- no second label
 * vocabulary, no score, no streak claim, no causal language. Every
 * number is already-computed server-side (insightsReporting.ts); this
 * component only arranges and labels it.
 */
function GoalPlanningReportingSection({ reporting }: { reporting: GoalReportingResponse }) {
  const rhythmGoals = reporting.goals.filter((goal) => goal.activities.some((activity) => activity.rhythm.kind === 'N_PER_WEEK'));
  const finiteGoals = reporting.goals.filter((goal) => goal.kind === 'FINITE' || goal.kind === 'MIXED');
  const hasAnyGoals = reporting.goals.length > 0;
  const goalActivitiesWithProgress = reporting.goals.reduce((sum, g) => sum + g.progress.completed, 0);

  return (
    <>
      {/* 1. Confirmed progress
       *
       * Insights V1 PR7 (finding F-1) -- these two numbers count
       * DIFFERENT units and were previously both bare-labeled "done"/
       * "completed" with no way to tell them apart: `confirmedCompleted`
       * is every confirmed completion EVENT (a rhythm activity done 5
       * times contributes 5), while `goals.reduce(...completed)` counts
       * DISTINCT Goal activities that have reached a completed state at
       * least once (that same 5x-completed rhythm activity still
       * contributes exactly 1 -- see computeGoalProgress/goals.ts, not
       * changed by this fix). Relabeled to name the actual unit each one
       * counts, plus one plain-language line making the distinction
       * explicit -- the underlying calculations themselves are
       * unchanged. */}
      <SurfaceCard accentColor={colors.positive}>
        <div style={typography.sectionEyebrow}>Confirmed Progress</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: `${spacing.sm}px ${spacing.lg}px`, marginTop: spacing.sm }}>
          <InlineStat
            value={reporting.planningStatus.confirmedCompleted}
            label={reporting.planningStatus.confirmedCompleted === 1 ? 'confirmed completion' : 'confirmed completions'}
            color={colors.positive}
          />
          <InlineStat
            value={goalActivitiesWithProgress}
            label={goalActivitiesWithProgress === 1 ? 'Goal activity with progress' : 'Goal activities with progress'}
            color={colors.info}
          />
        </div>
        <div style={{ ...typography.meta, marginTop: spacing.sm }}>
          Completions counts every confirmed activity. Goal activities counts distinct Goal activities with at least one completion — doing the same one repeatedly still counts once here.
        </div>
      </SurfaceCard>

      {/* 2. Goals this week */}
      <SurfaceCard padding={spacing.xl}>
        <div style={typography.sectionEyebrow}>Goals This Week</div>
        {!hasAnyGoals ? (
          <EmptyState title="No active Goals yet." description="Set up a Goal to see its progress here." />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.md, marginTop: spacing.sm }}>
            {rhythmGoals.map((goal) => (
              <div key={goal.id}>
                <div style={{ ...typography.bodyStrong, color: colors.textPrimary }}>{goal.title}</div>
                {goal.activities.filter((a) => a.rhythm.kind === 'N_PER_WEEK').map((activity) => (
                  <div key={activity.id} style={{ marginTop: spacing.xs }}>
                    <div style={{ fontSize: 13, color: colors.textSecondary }}>{formatGoalActivityRhythmWeeklyProgressLabel(activity.rhythm)}</div>
                    {formatGoalActivityRhythmRemainingCapacityLabel(activity.rhythm) && (
                      <div style={{ ...typography.meta, marginTop: 2 }}>{formatGoalActivityRhythmRemainingCapacityLabel(activity.rhythm)}</div>
                    )}
                  </div>
                ))}
              </div>
            ))}
            {finiteGoals.map((goal) => {
              const label = formatGoalProgressLabel(goal.progress);
              return label ? (
                <div key={goal.id} style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ ...typography.bodyStrong, color: colors.textPrimary }}>{goal.title}</span>
                  <span style={{ fontSize: 13, color: colors.textSecondary }}>{label}</span>
                </div>
              ) : null;
            })}
          </div>
        )}
      </SurfaceCard>

      {/* 3. Planning patterns */}
      <SurfaceCard padding={spacing.xl}>
        <div style={typography.sectionEyebrow}>Planning Patterns</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: `${spacing.sm}px ${spacing.lg}px`, marginTop: spacing.sm }}>
          <InlineStat value={reporting.planningStatus.scheduled} label="scheduled" color={colors.info} />
          <InlineStat value={reporting.planningStatus.rescheduled} label="rescheduled" color={colors.caution} />
          <InlineStat value={reporting.planningStatus.skipped} label="explicitly skipped" color={colors.textSecondary} />
          <InlineStat value={reporting.planningStatus.cancelled} label="cancelled" color={colors.textSecondary} />
        </div>
      </SurfaceCard>

      {/* 4. Awaiting confirmation */}
      <SurfaceCard accentColor={colors.caution} style={{ background: colors.cautionSoft }}>
        <div style={typography.sectionEyebrow}>Awaiting Confirmation</div>
        {reporting.awaitingConfirmation.count === 0 ? (
          <div style={{ fontSize: 14, color: colors.textSecondary, marginTop: spacing.sm }}>Everything&rsquo;s confirmed.</div>
        ) : (
          <>
            <div style={{ fontSize: 14, color: colors.textPrimary, marginTop: spacing.sm }}>
              {reporting.awaitingConfirmation.count} past {reporting.awaitingConfirmation.count === 1 ? 'activity has' : 'activities have'} no recorded outcome.
            </div>
            <div style={{ ...typography.meta, marginTop: spacing.xs }}>
              This isn&rsquo;t a judgment -- just activities Aura hasn&rsquo;t heard back about yet.
            </div>
          </>
        )}
      </SurfaceCard>

      {reporting.limitations.length > 0 && (
        <div style={{ ...typography.meta, color: colors.textSecondary, lineHeight: 1.5 }}>
          {reporting.limitations.join(' ')}
        </div>
      )}
    </>
  );
}

/** brief section 50 -- a lighter inline stat, no per-stat border/box. */
function InlineStat({ value, label, color }: { value: string | number; label: string; color: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
      <span style={{ fontSize: 20, fontWeight: 800, color }}>{value}</span>
      <span style={{ fontSize: 12, color: '#94a3b8' }}>{label}</span>
    </div>
  );
}

function MiniStat({ value, label, color }: { value: string | number; label: string; color: string }) {
  return (
    <div style={{ background: 'rgba(30, 41, 59, 0.5)', border: '1px solid rgba(255, 255, 255, 0.06)', borderRadius: 12, padding: 10, textAlign: 'center' }}>
      <div style={{ color, fontSize: 18, fontWeight: 900 }}>{value}</div>
      <div style={{ color: '#94a3b8', fontSize: 10, marginTop: 3 }}>{label}</div>
    </div>
  );
}

function SourceBadge({ source }: { source: NonNullable<LoggedEntryItem['logSource']> }) {
  const meta = source === 'AURA_PLANNED'
    ? { label: 'Aura planned', color: '#4ade80' }
    : source === 'AURA_DO_NOW'
      ? { label: 'Aura do now', color: '#38bdf8' }
      : source === 'OVERRIDE_CAUTION'
        ? { label: 'Caution override', color: '#fb7185' }
        : { label: 'Manual', color: '#94a3b8' };

  return (
    <span style={{ display: 'inline-flex', border: `1px solid ${meta.color}44`, background: `${meta.color}16`, color: meta.color, borderRadius: 999, padding: '2px 7px', fontSize: 9, fontWeight: 850, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
      {meta.label}
    </span>
  );
}

function TODCard({
  title,
  count,
  icon,
  color,
}: {
  title: string;
  count: number;
  icon: string;
  color: string;
}) {
  return (
    <div
      style={{
        background: 'rgba(30, 41, 59, 0.5)',
        border: '1px solid rgba(255, 255, 255, 0.05)',
        borderRadius: 10,
        padding: '10px 12px',
        display: 'flex',
        alignItems: 'center',
        gap: 10,
      }}
    >
      <span style={{ fontSize: 18 }}>{icon}</span>
      <div>
        <div style={{ fontSize: 12, fontWeight: 700, color }}>{count} logged</div>
        <div style={{ fontSize: 9, color: '#94a3b8', marginTop: 2 }}>{title}</div>
      </div>
    </div>
  );
}
