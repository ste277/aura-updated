'use client';

import React, { useEffect, useMemo, useState, useCallback, useRef } from 'react';
import { computeSolarEphemeris } from '../../../packages/astronomy/src/ephemeris';
import {
  computePanchangWindows,
  getActiveWindow,
  SolarWindowType,
  WeekdayIndex,
} from '../../../packages/panchang/src/windows';
import { computeDailyEnergyInsight } from '../lib/scoreEngine';
import { computeCurrentWindowStatus } from '../lib/currentWindowStatus';
import { getActionCards, ActionCard } from '../../../packages/recommendation/src/actionCards';
import { findActivityIntent } from '../../../packages/recommendation/src/personalizedTasks';
import type { PersonalMuhurtaContext } from '../../../packages/recommendation/src/auraFitEngine';
import type { DailyBriefing, PlanningHorizon } from '../../../packages/recommendation/src/dailyAssistant';
import type { TimingSearchDateRange, TimingSearchMode, TimingTimePreference } from '../../../packages/recommendation/src/timingSearch';
import type { TimingSearchResponseWithDailyRhythm } from '../lib/timingSearchDailyRhythm';
import type { AuraUpdatesResponse } from '../lib/auraUpdates';
import type { AuraReminder } from '../lib/auraReminders';
import type { DailyAgenda, DailyAgendaItem } from '../lib/dailyAgenda';
import type { DailyStory } from '../lib/dailyStory';
import type { DailyReflection } from '../lib/dailyReflection';
import type { TomorrowPreview } from '../lib/tomorrowPreview';
import { shouldRefreshMyDayForDateChange } from '../lib/myDayRefreshPolicy';
import { classifyHabitLogSyncOutcome } from '../lib/habitLogSyncPolicy';
import { readOfflineHabitQueue, toPendingLoggedEntry, mergeConfirmedLogEntries, selectQueueItemsToReconstruct } from '../lib/offlineHabitQueue';
import { refreshAfterHomeCompletion } from '../lib/homeRefresh';
import { selectTodaysPendingActivities } from '../lib/myDayPendingOverlay';
import type { GuidanceUiState } from '../lib/bestForYouViewModel';

// UI Modules
import { HomeDashboard } from '../components/HomeDashboard';
import { TimelineView } from '../components/Timeline';
import { AskAuraView } from '../components/AskAuraView';
import { CalendarViewSection, LoggedEntryItem } from '../components/CalendarViewSection';
import { InsightsView } from '../components/InsightsView';
import { WindowShiftToast } from '../components/WindowShiftToast';
import { LocationTrustBanner } from '../components/LocationTrustBanner';
import { OnboardingJourney } from '../components/OnboardingJourney';
import { PlanWithAuraView } from '../components/PlanWithAuraView';
import { YouView } from '../components/YouView';
import { PanchangCalendarView } from '../components/PanchangCalendarView';
import { MuhurthamFinderView } from '../components/MuhurthamFinderView';
import { PeopleView } from '../components/PeopleView';
import { ExploreView } from '../components/ExploreView';
import { UpdatesView } from '../components/UpdatesView';
import { ForwardPlannerView } from '../components/ForwardPlannerView';

import { BirthChartSection } from '../components/BirthChartSection';
import { LoginScreen } from '../components/LoginScreen';
import { useCurrentMinuteOfDay } from '../lib/useCurrentMinuteOfDay';
import { resolveTzOffsetMinutes, getDatePartsInTimezone } from '../lib/timezone';
import { formatDisplayName } from '../lib/displayName';
import { trackEvent } from '../lib/trackEvent';
import { Capacitor } from '@capacitor/core';
import {
  loadNotificationPrefs,
  saveNotificationPrefs,
  syncWindowNotifications,
  DEFAULT_NOTIFICATION_PREFS,
  NotificationPrefs,
} from '../lib/windowNotifications';

interface SessionUser {
  id: string;
  email: string;
  cityName: string;
  latitude: number;
  longitude: number;
  timezone: string;
  /** Onboarding V1 PR 1 -- Location Trust Foundation. An ISO timestamp
   * string (as it arrives over JSON) or null -- never parsed into a
   * `Date` here, since every consumer only ever needs "is this null or
   * not" (see `locationConfirmed` derivations below), matching this
   * client type's own existing convention of carrying wire-shaped
   * values, not domain `Date` objects. */
  locationConfirmedAt: string | null;
  remindersEnabled: boolean;
  reminderLeadMinutes: number;
  dayBuilderEnabled: boolean;
  dayBuilderMutedGroups: string[];
  dayBuilderPriorities: string[];
  dayBuilderPriorityPersonIds: string[];
  dayBuilderPrioritiesPromptDismissed: boolean;
}

interface DailyReflectionState {
  outputLevel: 'LOW' | 'MODERATE' | 'PEAK_FLOW';
  followedGuidance: boolean;
}

interface PlannedActivityState {
  id: string;
  title: string;
  icon?: string | null;
  status: 'UPCOMING' | 'LOGGED' | 'CANCELLED' | 'SKIPPED' | 'MOVED';
  plannedStartAt: string;
  plannedEndAt: string;
  durationMinutes: number;
  windowType?: string | null;
  windowLabel?: string | null;
  matchLabel?: string | null;
  recommendation?: string | null;
}

const FALLBACK_TZ = 'Asia/Kolkata';

type LogSource = 'AURA_PLANNED' | 'AURA_DO_NOW' | 'MANUAL' | 'OVERRIDE_CAUTION';
type ActivitySignificance = 'LOW' | 'MEDIUM' | 'HIGH';

function inferActivitySignificance(activityTitle: string): ActivitySignificance {
  return findActivityIntent(activityTitle)?.significance ?? 'MEDIUM';
}

function isFrictionWindow(windowName: string): boolean {
  const normalized = windowName.toUpperCase();
  return normalized.includes('RAHU') || normalized.includes('YAMA');
}

export default function DashboardPage() {
  const [user, setUser] = useState<SessionUser | null | undefined>(undefined);
  // Onboarding V1 PR 1 -- Location Trust Foundation: lets the global
  // disclosure banner's action land directly on the already-expanded
  // Location & Time panel, instead of a collapsed You tab the user then
  // has to find the right row in themselves. Read only once on YouView's
  // initial mount (see YouView's own `initialOpenPanel` doc comment).
  const [youInitialPanel, setYouInitialPanel] = useState<'location' | undefined>(undefined);
  // Onboarding V1 PR 2 -- Welcome journey. `onboardingActive` decides
  // whether the Welcome/Confirm Location/Recommendation flow renders
  // instead of the normal tab UI. Seeded ONLY from the first resolved
  // `GET /api/auth/session` response of this page load (`onboardingResolved`,
  // a durable server-side fact -- see that route's own doc comment) via
  // `onboardingDecidedRef`. This guard is still required even though the
  // underlying signal is now durable (First-Run Reliability Correction):
  // without it, a LATER session refetch (plan logged, offline sync, 401
  // re-check) landing before handleExitOnboarding's own PATCH call has
  // finished persisting would see onboardingResolved still false and could
  // yank the user back into Welcome mid-use -- exactly the "trap the
  // user"/redirect-loop failure this guard exists to prevent. Exiting the
  // journey (Skip, Go to Home, Plan my day) sets it false locally and
  // fires that PATCH; it is never true again for the rest of this page
  // load regardless of what a later session fetch reports.
  const [onboardingActive, setOnboardingActive] = useState(false);
  const onboardingDecidedRef = useRef(false);
  const [logEntries, setLogEntries] = useState<LoggedEntryItem[]>([]);
  const [, setHabits] = useState<any[]>([]);
  const [dailyBriefing, setDailyBriefing] = useState<DailyBriefing | null>(null);
  // Home Good Right Now Personalization V1 -- the owner's derived natal
  // context (never raw birth date/time/timezone), returned as a sibling
  // field alongside DailyBriefing by the SAME existing
  // GET /api/daily-assistant/briefing request below -- no second Home API
  // call. Undefined for an incomplete birth profile, exactly
  // buildPersonalMuhurtaContextForUser's own existing contract.
  const [personalContext, setPersonalContext] = useState<PersonalMuhurtaContext | undefined>(undefined);
  const [assistantInsight, setAssistantInsight] = useState<any>(null);
  // Insights V1 PR4 -- Goal/planning reporting, fetched the SAME way as
  // assistantInsight above (one GET, state set on success, logged (never
  // thrown) on failure) -- InsightsView renders its own empty state when
  // this stays null, same as it already does for a null assistantInsight.
  const [goalReporting, setGoalReporting] = useState<any>(null);
  // Insights V1 PR7 -- explicit fetch-lifecycle state for goalReporting
  // (AURA_INSIGHTS_V1_PRODUCT_COMPLETION_AUDIT.md §19 scenario 20), so
  // InsightsView can show an honest loading/error state instead of
  // silently staying blank. 'loading' until the first fetch below
  // resolves one way or the other.
  const [goalReportingStatus, setGoalReportingStatus] = useState<'loading' | 'loaded' | 'error'>('loading');
  // Insights V1 PR7 (finding F-4) -- the "Review plans"/"Open Plan"/
  // "Review today's plan" CTAs now thread the clicked suggestion's own
  // plan identity through to the Plan tab (planFocusId for a single
  // deterministic plan, planFocusFilter for a pre-filtered review list)
  // instead of always landing on the generic new-activity composer.
  // planFocusKey mirrors momentsFocusKey's own established pattern: an
  // incrementing counter so PlanWithAuraView's effect re-fires even when
  // the SAME plan/filter is requested twice in a row.
  const [planFocusKey, setPlanFocusKey] = useState(0);
  const [planFocusId, setPlanFocusId] = useState<string | null>(null);
  const [planFocusFilter, setPlanFocusFilter] = useState<'AWAITING_CONFIRMATION' | null>(null);
  const [todayReflection, setTodayReflection] = useState<DailyReflectionState | null>(null);
  const [plannedActivities, setPlannedActivities] = useState<PlannedActivityState[]>([]);
  // Recipient Conversion V1 Hardening (brief section 8) -- an existing
  // user routed here from /find with `?activity=` (their acquisition
  // intent, e.g. "Date Night") lands directly in Plan with it prefilled,
  // via the exact same mechanism handleOpenPlan() already uses for every
  // other "jump into Plan with this activity" entry point in the app.
  // HPG1 -- activityId is optional and ONLY ever set by a caller that
  // already has a genuine, non-title-derived catalog identity in hand
  // (e.g. a Good Right Now card's own ActionCard.activityId, or Ask
  // Aura's own resolved action.activityId) -- never backfilled here by
  // matching `activity`'s text. The `?activity=` URL entry point below has
  // no such id available, so it correctly stays title-only, exactly as
  // before this field was added.
  const [planPrefill, setPlanPrefill] = useState<{ activity: string; activityId?: string; key: number; horizon?: PlanningHorizon } | null>(() => {
    if (typeof window === 'undefined') return null;
    const requested = new URLSearchParams(window.location.search).get('activity');
    return requested?.trim() ? { activity: requested.trim(), key: Date.now() } : null;
  });
  const [mounted, setMounted] = useState(false);
  const [auraUpdates, setAuraUpdates] = useState<AuraUpdatesResponse | null>(null);
  const [myDay, setMyDay] = useState<{ agenda: DailyAgenda; story: DailyStory; reflection: DailyReflection | null; tomorrowPreview: TomorrowPreview | null } | null>(null);
  // New Aura Home V1 -- the "Best For You" section's own guidance fetch
  // state. Reset to 'loading' on every user?.id change (stricter than
  // several legacy Home slices, which only ever overwrite on the next
  // successful fetch and never explicitly reset) -- see the loadGuidance
  // effect below for why this one is deliberately stricter: guidance is
  // highly personalized, so a stale prior user's recommendations must
  // never render attributed to a different logged-in user.
  const [guidance, setGuidance] = useState<GuidanceUiState>({ status: 'loading' });
  // Product Structure V2 -- "Your Moments" now lives inside Plan (brief
  // section 19), so any entry point that used to jump to the standalone
  // Shared Moments tab (Home's actionable card, You's row) now jumps into
  // Plan and focuses this token instead.
  const [momentsFocusToken, setMomentsFocusToken] = useState<string | undefined>(undefined);
  const [momentsFocusKey, setMomentsFocusKey] = useState(0);
  // Cross-tab timeline handoff -- Ask Aura's TODAY_GUIDANCE "See all
  // activities" and Plan with Aura's "View my day" both navigate to Home
  // and bump this key so HomeDashboard scrolls/focuses its real timeline
  // region once mounted (mirrors momentsFocusKey's own pattern).
  const [homeTimelineFocusKey, setHomeTimelineFocusKey] = useState(0);
  // Product Structure V2 (brief section 28): Plan -> People -> Plan return
  // flow. One small piece of local state, not a global navigation
  // framework -- People's own onBack just reads it.
  const [peopleReturnTo, setPeopleReturnTo] = useState<'you' | 'plan' | 'home'>('you');

  type AppTab = 'home' | 'timeline' | 'ask' | 'plan' | 'insights' | 'you' | 'chart' | 'activity' | 'explore' | 'panchang' | 'muhurtham' | 'people' | 'updates' | 'planner';
  const VALID_TABS: AppTab[] = ['home', 'timeline', 'ask', 'plan', 'insights', 'you', 'chart', 'activity', 'explore', 'panchang', 'muhurtham', 'people', 'updates', 'planner'];
  // Recipient Conversion V1 (brief section 16/33) -- an already-signed-in
  // visitor who lands on /find (e.g. via "Find your own moment" on a Moment
  // they received) is redirected to `/?tab=plan` rather than the guest
  // wizard. This is the one place that redirect needs to land on a specific
  // tab; every other entry to '/' keeps defaulting to Home, unaffected.
  const [activeTab, setActiveTab] = useState<AppTab>(() => {
    if (typeof window === 'undefined') return 'home';
    const requested = new URLSearchParams(window.location.search).get('tab');
    return (VALID_TABS as string[]).includes(requested ?? '') ? (requested as AppTab) : 'home';
  });
  const [panchangDateJump, setPanchangDateJump] = useState<{ date: string; key: number } | null>(null);
  const [muhurthamActivityJump, setMuhurthamActivityJump] = useState<{ activityId: string; key: number } | null>(null);

  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPrefs>(DEFAULT_NOTIFICATION_PREFS);

  // Product Instrumentation V1 -- client-side "viewed"/"started" UI intent
  // signals with no reliable server equivalent. Fires once per tab switch,
  // only once the user is actually signed in (never for the logged-out
  // LoginScreen). Outcome events (searches completing, moments created,
  // etc.) are tracked server-side instead -- see the relevant API routes.
  useEffect(() => {
    if (!user) return;
    if (activeTab === 'home') trackEvent('AURA_HOME_VIEWED');
    else if (activeTab === 'panchang') trackEvent('PANCHANG_CALENDAR_VIEWED');
    else if (activeTab === 'plan') trackEvent('PLAN_STARTED');
  }, [activeTab, user]);

  useEffect(() => {
    setMounted(true);
    setNotificationPrefs(loadNotificationPrefs());

    // Web-only permission request (in-app toast alerts). In the native shells
    // the LocalNotifications plugin runs its own permission flow when window
    // alerts are scheduled — see syncWindowNotifications.
    if (
      typeof window !== 'undefined' &&
      !Capacitor.isNativePlatform() &&
      'Notification' in window &&
      Notification.permission === 'default'
    ) {
      Notification.requestPermission();
    }

    // Register Service Worker for PWA Offline Caching
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.error('ServiceWorker registration failed:', err);
      });
    }

    if (typeof window !== 'undefined' && 'serviceWorker' in navigator && process.env.NODE_ENV !== 'production') {
      navigator.serviceWorker.getRegistrations().then((registrations) => {
        registrations.forEach((registration) => registration.unregister());
      }).catch((err) => {
        console.warn('Could not clear development service worker:', err);
      });
      if ('caches' in window) {
        caches.keys().then((keys) => {
          keys.filter((key) => key.startsWith('aura-')).forEach((key) => caches.delete(key));
        }).catch((err) => {
          console.warn('Could not clear development app cache:', err);
        });
      }
    }
  }, []);

  const currentMinuteOfDay = useCurrentMinuteOfDay(user?.timezone ?? FALLBACK_TZ);

  // Shared by loadUserDataAndLogs and the Home post-completion refresh: maps
  // the confirmed /api/habit-logs rows into Home's log entries (unchanged logic).
  const applyConfirmedLogs = useCallback((logs: any[]) => {
    const confirmedEntries: LoggedEntryItem[] = logs.map((l: any) => ({
      id: l.id,
      activityTitle: l.activityTitle,
      activeWindow: l.activeWindow,
      loggedAt: new Date(l.logTimestamp || l.createdAt || Date.now()),
      logMinuteOfDay: l.logMinuteOfDay,
      durationMinutes: l.durationMinutes ?? 30,
      notes: l.notes || null,
      logSource: l.logSource || 'MANUAL',
      activitySignificance: l.activitySignificance || 'MEDIUM',
      // Pending Activity Reload Visibility V1 -- propagated so a
      // still-queued offline entry (reconstructed from
      // localStorage's own copy of this same clientRequestId) can be
      // reliably recognized as now-confirmed and never shown as a
      // duplicate pending row alongside its real, persisted one.
      clientRequestId: l.clientRequestId ?? undefined,
    }));
    // Pending Activity Reload Visibility V1 -- this used to be a hard
    // replace (setLogEntries(confirmedEntries)), which would silently
    // wipe out any pending entry reconstructed from the offline queue
    // if this confirmed fetch happened to resolve AFTER that
    // reconstruction ran. mergeConfirmedLogEntries (lib/offlineHabitQueue.ts)
    // makes the final state the same deterministic union regardless of
    // which of the two initialization paths finishes first, while
    // still correctly clearing a permanently-rejected (4xx) entry's
    // stale row once it's no longer in the queue (PR #86's own
    // invariant) -- see that function's own doc comment.
    setLogEntries((prev) => {
      const queuedClientRequestIds = new Set(readOfflineHabitQueue().map((item) => item.clientRequestId));
      return mergeConfirmedLogEntries(confirmedEntries, prev, queuedClientRequestIds);
    });
  }, []);

  // Parallelize Session & Initial Data Fetches
  const loadUserDataAndLogs = useCallback(async () => {
    try {
      const sessionRes = await fetch('/api/auth/session');
      const sessionData = await sessionRes.json();

      if (!sessionData?.user) {
        setUser(null);
        setPlannedActivities([]);
        return;
      }

      setUser(sessionData.user);

      // Onboarding V1 PR 2 -- captured exactly once per page load (see
      // onboardingDecidedRef's own doc comment above); a later refetch
      // (plan logged elsewhere, offline sync, 401 re-check) must never
      // re-trigger the Welcome journey after this page's first decision.
      if (!onboardingDecidedRef.current) {
        onboardingDecidedRef.current = true;
        setOnboardingActive(sessionData.onboardingResolved === false);
      }

      const [logsRes, habitsRes, plansRes] = await Promise.all([
        fetch('/api/habit-logs'),
        fetch('/api/habits'),
        fetch('/api/plans'),
      ]);

      if (logsRes.ok) {
        applyConfirmedLogs(await logsRes.json());
      }

      if (habitsRes.ok) {
        const habitsData = await habitsRes.json();
        setHabits(habitsData);
      }

      if (plansRes.ok) {
        setPlannedActivities(await plansRes.json());
      }
    } catch {
      setUser(null);
      setPlannedActivities([]);
    }
  }, [applyConfirmedLogs]);

  useEffect(() => {
    loadUserDataAndLogs();
  }, [loadUserDataAndLogs]);

  // Pending Activity Reload Visibility V1 -- a still-queued offline log
  // (localStorage['offline_habit_queue'], written by handleLogActivity's
  // own catch branch below) has no server row yet, so the confirmed fetch
  // above can never know about it. This is a pure, read-only
  // reconstruction into presentation state -- it never mutates the queue,
  // never POSTs, and is entirely separate from the Offline Log Sync
  // Listener effect further down (which does attempt to resync and IS
  // allowed to mutate the queue). Runs once on mount; order-independent
  // relative to the confirmed fetch above by construction (see that
  // effect's own setLogEntries merge comment) -- whichever of the two
  // resolves first, the other's setLogEntries call preserves it rather
  // than overwriting it.
  useEffect(() => {
    const queued = readOfflineHabitQueue();
    if (queued.length === 0) return;
    setLogEntries((prev) => {
      const reconstructed = selectQueueItemsToReconstruct(queued, prev).map(toPendingLoggedEntry);
      if (reconstructed.length === 0) return prev;
      return [...reconstructed, ...prev];
    });
  }, []);

  // My Day Timing Location Change Refresh V1 -- extracted from its
  // original inline form (previously only reachable via the user-id-gated
  // mount effect below) so it can ALSO be called directly from a confirmed
  // Timing Location save (handleLocationChanged below). Endpoints, response
  // handling, and state updates are unchanged; only the shape moved.
  const loadAssistantSignals = useCallback(async () => {
    try {
      const [briefingRes, insightRes, reflectionRes, goalReportingRes] = await Promise.all([
        fetch('/api/daily-assistant/briefing'),
        fetch('/api/daily-assistant/insights'),
        fetch('/api/daily-assistant/reflection'),
        fetch('/api/insights/reporting'),
      ]);

      if (briefingRes.ok) {
        const briefingData = await briefingRes.json();
        setDailyBriefing(briefingData);
        setPersonalContext(briefingData.personalContext);
      }
      if (insightRes.ok) setAssistantInsight(await insightRes.json());
      if (goalReportingRes.ok) {
        setGoalReporting(await goalReportingRes.json());
        setGoalReportingStatus('loaded');
      } else {
        // loadAssistantSignals can also run again later (e.g. a manual
        // refresh) after an earlier successful load -- a transient
        // refetch failure must not tear down already-displayed data back
        // into a blank error state, only the FIRST load (still 'loading')
        // surfaces as 'error'. Same reasoning in the catch block below.
        setGoalReportingStatus((prev) => (prev === 'loaded' ? prev : 'error'));
      }
      if (reflectionRes.ok) {
        const reflection = await reflectionRes.json();
        setTodayReflection(reflection ? {
          outputLevel: reflection.outputLevel,
          followedGuidance: Boolean(reflection.followedGuidance),
        } : null);
      }
    } catch (err) {
      console.error('Failed to load daily assistant signals:', err);
      setGoalReportingStatus((prev) => (prev === 'loaded' ? prev : 'error'));
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    loadAssistantSignals();
  }, [user?.id, loadAssistantSignals]);

  // New Aura Home V1 -- GET /api/daily-assistant/guidance, same
  // best-effort fetch discipline as loadAssistantSignals/loadMyDay above
  // (silent console.error on failure, no retry infrastructure, no global
  // error UI). Parses the response as PersonalDailyGuidanceResult
  // verbatim -- never reorders/filters `recommendations`, that stays
  // #104's own contract.
  const loadGuidance = useCallback(async () => {
    try {
      const res = await fetch('/api/daily-assistant/guidance');
      if (res.ok) {
        setGuidance(await res.json());
      } else {
        setGuidance({ status: 'error' });
      }
    } catch (err) {
      console.error('Failed to load daily guidance:', err);
      setGuidance({ status: 'error' });
    }
  }, []);

  // New Aura Home V1 -- resets to 'loading' on EVERY user?.id change
  // (including a transition to no user at all) BEFORE fetching, so a
  // prior user's personalized recommendations can never render
  // attributed to a different logged-in user during the gap -- stricter
  // than the loadAssistantSignals/loadMyDay effect above, deliberately,
  // since this state is the most personalized slice on Home.
  useEffect(() => {
    setGuidance({ status: 'loading' });
    if (!user) return;
    loadGuidance();
  }, [user?.id, loadGuidance]);

  // Aura Updates V1 -- ordinary fetch on the same lifecycle as the other
  // Home data above, no polling faster than the app's existing refresh
  // pattern (brief: "not faster than existing normal app refresh
  // patterns"). Refetched after actions that change seen/actionable state
  // (see loadAuraUpdates callers below) so the badge/section stay current
  // without a background timer.
  const loadAuraUpdates = useCallback(async () => {
    try {
      const res = await fetch('/api/aura-updates');
      if (res.ok) setAuraUpdates(await res.json());
    } catch {
      // Best-effort -- Home/You already render fine with no updates data.
    }
  }, []);

  // My Day V1 -- same on-mount/on-tab-switch lifecycle as Aura Updates
  // above, no polling. Home-only (unlike Aura Updates, which also serves
  // the Updates tab) since My Day's own agenda/story only render on Home.
  // My Day Day-Boundary Refresh V1 -- lastLoadedMyDayDateKeyRef records
  // which Timing Location date this snapshot actually reflects, read
  // straight off the server's own agenda.localDate (no new server field,
  // no separate client-side "today" computation that could itself drift
  // from the server's). Only recorded on a CONFIRMED success -- a failed
  // fetch leaves the previous key in place so a later natural lifecycle
  // event retries instead of silently giving up (brief section 17).
  const lastLoadedMyDayDateKeyRef = useRef<string | null>(null);
  const loadMyDay = useCallback(async () => {
    try {
      const res = await fetch('/api/my-day');
      if (res.ok) {
        const data = await res.json();
        setMyDay({ agenda: data.agenda, story: data.story, reflection: data.reflection ?? null, tomorrowPreview: data.tomorrowPreview ?? null });
        lastLoadedMyDayDateKeyRef.current = data.agenda.localDate;
      }
    } catch {
      // Best-effort -- Home already degrades gracefully with myDay null.
    }
  }, []);

  // My Day Day-Boundary Refresh V1 -- the one thing that decides whether a
  // "the app just became visible again" moment is worth a refetch is the
  // pure shouldRefreshMyDayForDateChange() comparison (lib/myDayRefreshPolicy.ts)
  // against the user's Timing Location date key (getDatePartsInTimezone,
  // the exact same timezone-aware helper My Day's own display logic
  // already uses below -- never browser-local, never UTC). Deliberately
  // NOT a timer: this only runs from the visibilitychange/focus listeners
  // wired below, so an idle background tab does no work at all until the
  // user actually returns to it. myDayDateBoundaryRefreshInFlightRef stops
  // visibilitychange and focus firing together for the same return-to-app
  // moment from starting two concurrent fetches.
  const myDayDateBoundaryRefreshInFlightRef = useRef<string | null>(null);
  const checkMyDayDateBoundary = useCallback(() => {
    if (!user || typeof document === 'undefined' || document.visibilityState !== 'visible') return;
    const currentDateKey = getDatePartsInTimezone(user.timezone, new Date()).dateStr;
    if (!shouldRefreshMyDayForDateChange(lastLoadedMyDayDateKeyRef.current, currentDateKey)) return;
    if (myDayDateBoundaryRefreshInFlightRef.current === currentDateKey) return;
    myDayDateBoundaryRefreshInFlightRef.current = currentDateKey;
    loadMyDay().finally(() => {
      if (myDayDateBoundaryRefreshInFlightRef.current === currentDateKey) {
        myDayDateBoundaryRefreshInFlightRef.current = null;
      }
    });
  }, [user, loadMyDay]);

  // visibilitychange covers the app being backgrounded/foregrounded
  // (mobile web, Capacitor's WKWebView/Android WebView, or a desktop tab
  // being switched away and back); window focus covers alt-tabbing back
  // on desktop without a visibility change. Both are standard DOM events
  // that already fire inside a Capacitor WebView (it's a real browser
  // context) -- no @capacitor/app plugin needed just for this. Neither
  // listener does anything by itself; both only ever call the same
  // guarded checkMyDayDateBoundary, so there is exactly one decision point.
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') checkMyDayDateBoundary();
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', checkMyDayDateBoundary);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', checkMyDayDateBoundary);
    };
  }, [checkMyDayDateBoundary]);

  // Web Push V1 (brief section 10) -- when a push notification is clicked
  // while Aura is ALREADY open, the service worker focuses this tab and
  // posts a message instead of opening a second one. The mark-seen call
  // and REMINDER_OPENED analytics already happened in the service worker
  // itself (sw.js's notificationclick handler) -- this listener only
  // handles navigation, reusing the EXACT same target semantics
  // handleOpenReminder already uses for in-app clicks, so a push-driven
  // open behaves identically to an in-app one once the tab is focused.
  useEffect(() => {
    if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type !== 'AURA_REMINDER_NAVIGATE') return;
      const target = event.data.target as AuraReminder['target'] | undefined;
      if (!target) return;
      if (target.type === 'MOMENT') {
        window.open(`${window.location.origin}/moment/${target.momentToken}`, '_blank', 'noopener,noreferrer');
      } else {
        setActiveTab('plan');
      }
      loadAuraUpdates();
    };
    navigator.serviceWorker.addEventListener('message', handleMessage);
    return () => navigator.serviceWorker.removeEventListener('message', handleMessage);
  }, [loadAuraUpdates]);

  // Aura Reminders V1 (brief section 27) extended this beyond its original
  // "once on sign-in" trigger: a Starting Soon reminder is time-sensitive in
  // a way moment responses alone weren't (a Plan saved for "15 minutes from
  // now" needs to actually show up within that window, not just at the next
  // full page load). Reusing the existing per-tab-switch refresh point (the
  // same activeTab effect above that fires AURA_HOME_VIEWED) rather than
  // adding a new timer -- signing in, or visiting Home/Updates, simply
  // re-fetches the same data those screens already render. Deliberately NOT
  // a setInterval/polling loop (section 27 explicitly forbids that); a
  // reminder becoming active while the user sits idle on Home only appears
  // on their next natural visit/switch, matching V1's scope (real-time
  // delivery while idle is Web Push V1's job).
  useEffect(() => {
    if (!user) return;
    if (activeTab === 'home' || activeTab === 'updates') loadAuraUpdates();
    if (activeTab === 'home') loadMyDay();
  }, [activeTab, user?.id, loadAuraUpdates, loadMyDay]);

  // Moment View Navigation Fix -- the owner's own "View details" on a
  // responded-to Moment update must land on the OWNER's canonical Plan/
  // Moment details destination (the Plan tab, PlanWithAuraView.tsx via
  // setActiveTab('plan')), the exact same destination every other "open my
  // own scheduled item" action in this app already uses
  // (handleOpenAgendaItem's PLAN branch, handleOpenReminder's
  // PLAN_APPROACHING branch, handleFindAnotherTimeForMoment below).
  // Previously this opened /moment/[token] -- the PUBLIC, RECIPIENT-facing
  // page (see AuraMomentClient.tsx: "✓ [sender] will know you're in", "Does
  // this work for you?") -- which reads as wrong/confusing from the
  // owner's own point of view, and is never the right default destination
  // for the owner's "View" action regardless of SOLO/SHARED scope or
  // response state. The invitation page itself is untouched and remains
  // reachable via the separate, explicit handleViewMomentInvitation below.
  const handleViewMomentUpdate = useCallback((momentToken: string) => {
    setActiveTab('plan');
    // E2E Journey Coverage V1.1 stabilization -- this previously called
    // loadAuraUpdates() unchained, racing the seen POST instead of waiting
    // for it (handleOpenReminder below already gets this right). Matching
    // that convention: never blocks the navigation on the POST, but the
    // refetch now always happens after it settles.
    fetch(`/api/aura-moments/${momentToken}/seen`, { method: 'POST' }).catch(() => {}).finally(() => loadAuraUpdates());
  }, [loadAuraUpdates]);

  // Moment View Navigation Fix -- the SEPARATE, explicit "View invitation"
  // action (brief: "if the invitation screen is still needed, expose it as
  // a separate explicit action"). This is exactly handleViewMomentUpdate's
  // OWN previous behavior, preserved verbatim and simply no longer the
  // default -- the public /moment/[token] page and its own accept/decline/
  // response logic are completely untouched by this fix. Deliberately no
  // /seen POST here: that side effect stays tied to the main "View
  // details" action above, which is the action guaranteed to be available
  // for every update; this secondary action is purely navigational.
  const handleViewMomentInvitation = useCallback((momentToken: string) => {
    window.open(`${window.location.origin}/moment/${momentToken}`, '_blank', 'noopener,noreferrer');
  }, []);

  const handleFindAnotherTimeForMoment = useCallback((momentToken: string) => {
    setMomentsFocusToken(momentToken);
    setMomentsFocusKey(Date.now());
    setActiveTab('plan');
  }, []);

  // Aura Reminders V1 (brief section 22) -- every reminder needs an
  // explicit destination: MOMENT_APPROACHING opens the moment's own public
  // link (same navigation pattern handleViewMomentUpdate already uses,
  // reused rather than duplicated), PLAN_APPROACHING opens Plan (Plans have
  // no dedicated detail route -- Home's own Upcoming Plans section already
  // lives there). Never routes to Home itself.
  //
  // Notification Delivery Readiness V1 (brief section 6) -- this is the
  // ONE place a reminder is marked seen: the owner intentionally opening
  // this SPECIFIC reminder, from either Home's Starting Soon card or
  // Updates' Upcoming section (both already call this same handler, so
  // there is no separate Bell-vs-destination path to double-fire from --
  // opening the Bell itself never marks anything seen). Best-effort POST,
  // same convention as handleViewMomentUpdate's own /seen call just below:
  // never blocks the navigation/open action on it.
  const handleOpenReminder = useCallback((reminder: AuraReminder) => {
    if (reminder.target.type === 'MOMENT') {
      window.open(`${window.location.origin}/moment/${reminder.target.momentToken}`, '_blank', 'noopener,noreferrer');
    } else {
      setActiveTab('plan');
    }
    fetch('/api/reminders/seen', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        scheduledItemType: reminder.scheduledItemType,
        scheduledItemId: reminder.scheduledItemId,
        reminderAt: reminder.reminderAt,
      }),
    }).catch(() => {}).finally(() => loadAuraUpdates());
    trackEvent('REMINDER_OPENED', {
      metadata: {
        scheduledItemType: reminder.scheduledItemType,
        leadTimeMinutes: Math.max(0, Math.round((new Date(reminder.startAt).getTime() - new Date(reminder.reminderAt).getTime()) / 60000)),
        // Web Push V1 (brief section 31) -- distinguishes this in-app open
        // from the service worker's own REMINDER_OPENED call (source:
        // 'PUSH', sw.js) for the same canonical event.
        source: 'IN_APP',
      },
    });
  }, [loadAuraUpdates]);

  // My Day V1 (brief section 36) -- same routing convention
  // handleOpenReminder already uses: a Moment target opens the owner's own
  // public /moment/[token] link (the same one Aura Updates' "View" and
  // reminders already use), everything else opens Plan (My Day items have
  // no per-row deep link into Plan/Timeline yet -- a reasonable V1 scope
  // limit, not a new navigation system).
  const handleOpenAgendaItem = useCallback((item: DailyAgendaItem) => {
    trackEvent('MY_DAY_ITEM_OPENED', { metadata: { itemType: item.type, dayPhase: myDay?.story.phase ?? 'MORNING' } });
    if (item.target.type === 'MOMENT') {
      window.open(`${window.location.origin}/moment/${item.target.id}`, '_blank', 'noopener,noreferrer');
    } else {
      setActiveTab('plan');
    }
  }, [myDay]);

  // The focus token is only meant for ONE visit to Your Moments -- clear it
  // as soon as the tab changes away, so a later, unrelated visit to Plan
  // never auto-re-triggers an old moment's alternatives search.
  useEffect(() => {
    if (activeTab !== 'plan') setMomentsFocusToken(undefined);
  }, [activeTab]);

  const handleOpenUpdates = useCallback(() => {
    setActiveTab('updates');
  }, []);

  // Aura Reminders V1 (brief section 14/15) -- optimistic toggle, same
  // pattern as onLocationChanged: update local user state immediately, then
  // persist. Refetches Aura Updates so a just-disabled toggle clears
  // Starting Soon/Upcoming without waiting for the next natural refresh.
  const handleRemindersEnabledChange = useCallback(async (next: boolean) => {
    setUser((current) => (current ? { ...current, remindersEnabled: next } : current));
    try {
      const res = await fetch('/api/users/reminder-preferences', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ remindersEnabled: next }),
      });
      if (res.ok) loadAuraUpdates();
    } catch {
      // Best-effort -- the optimistic UI already reflects the user's choice.
    }
  }, [loadAuraUpdates]);

  // Intentional Day Builder V1 (brief section 6/35), extended by
  // Personalization Foundation V1 -- same optimistic pattern as
  // handleRemindersEnabledChange above. Accepts a PARTIAL update (any
  // subset of the 5 Day Builder preference fields) -- PATCH
  // /api/users/day-builder-preferences itself defaults any omitted field
  // to the user's current stored value, so a caller that only knows about
  // priorities (PersonalizationPromptCard) never has to also know/send
  // dayBuilderEnabled/dayBuilderMutedGroups just to avoid wiping them.
  const handleDayBuilderPrefsChange = useCallback(async (next: Partial<{
    dayBuilderEnabled: boolean;
    dayBuilderMutedGroups: string[];
    dayBuilderPriorities: string[];
    dayBuilderPriorityPersonIds: string[];
    dayBuilderPrioritiesPromptDismissed: boolean;
  }>) => {
    setUser((current) => (current ? { ...current, ...next } : current));
    try {
      await fetch('/api/users/day-builder-preferences', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(next),
      });
    } catch {
      // Best-effort -- the optimistic UI already reflects the user's choice.
    }
  }, []);

  const handleOpenMomentsFromYou = useCallback(() => {
    setMomentsFocusKey(Date.now());
    setActiveTab('plan');
  }, []);

  // Offline Log Sync Listener
  // Good Right Now / Log Activity Failure State Correctness V1 -- this
  // previously POSTed every queued payload without ever checking the
  // response, then unconditionally cleared the WHOLE queue regardless of
  // outcome -- a permanently-failing entry was silently and irrecoverably
  // discarded with no signal to the user. Each item's outcome is now
  // checked individually: 2xx (including an idempotent replay that finds
  // its own already-committed row) is confirmed and removed; a 4xx is a
  // permanent failure (would fail identically forever) and is also
  // removed, but never counted as a success; a 5xx or a thrown network
  // exception during replay is retained for a later attempt. The queue is
  // rewritten to hold only what's still genuinely retry-worthy, never
  // blanket-cleared.
  useEffect(() => {
    const syncOfflineLogs = async () => {
      const rawQueue = localStorage.getItem('offline_habit_queue');
      if (!rawQueue) return;

      let queue: any[];
      try {
        queue = JSON.parse(rawQueue);
      } catch {
        return;
      }
      if (!Array.isArray(queue) || queue.length === 0) return;

      const remaining: any[] = [];
      let anyConfirmed = false;

      for (const queuedItem of queue) {
        const { tempId, ...payload } = queuedItem;
        try {
          const res = await fetch('/api/habit-logs', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });
          const outcome = classifyHabitLogSyncOutcome(res.status);
          if (outcome === 'confirmed') {
            anyConfirmed = true;
          } else if (outcome === 'retry') {
            // Transient-looking server failure -- keep for a later retry.
            remaining.push(queuedItem);
          }
          // 'permanent-failure' (a 4xx) here -- deliberately NOT pushed back
          // onto `remaining`, so it stops being retried, but it was also never
          // counted in anyConfirmed, so it's never treated as a success.
        } catch {
          // Genuine network failure mid-replay -- still ambiguous, keep it.
          remaining.push(queuedItem);
        }
      }

      if (remaining.length > 0) {
        localStorage.setItem('offline_habit_queue', JSON.stringify(remaining));
      } else {
        localStorage.removeItem('offline_habit_queue');
      }

      // Refresh whenever anything was attempted, not only on a confirmed
      // success -- a permanently-discarded 4xx entry still needs the stale
      // "pending" optimistic row cleared out of logEntries, which this
      // full refetch-and-replace already does as a side effect.
      loadUserDataAndLogs();
      if (anyConfirmed) loadMyDay();
    };

    // Mount-time reconciliation (brief section 11) -- a queued entry must
    // not depend indefinitely on a future offline -> online transition
    // that may never come (e.g. every attempt failed with 5xx while the
    // browser was online the whole time). This is a one-shot check on
    // mount, never a poll/interval.
    syncOfflineLogs();

    window.addEventListener('online', syncOfflineLogs);
    return () => window.removeEventListener('online', syncOfflineLogs);
  }, [loadUserDataAndLogs, loadMyDay]);

  // The panchang day is defined by the USER'S timezone (their selected city),
  // never the browser clock or UTC: the weekday selects the Rahu/Gulika/Yama
  // segments and the date drives the ephemeris, so a NY browser with a Chennai
  // profile must still compute Chennai's "today".
  const userTz = user?.timezone ?? FALLBACK_TZ;
  const todayParts = mounted ? getDatePartsInTimezone(userTz, new Date()) : null;
  const todayDateStr = todayParts?.dateStr ?? '';

  // Precise Date-Filtered Titles for Activities Logged TODAY (user-tz day)
  const loggedActivitiesToday = useMemo(() => {
    if (!todayDateStr) return [];
    return logEntries
      .filter(
        (entry) =>
          getDatePartsInTimezone(userTz, new Date(entry.loggedAt)).dateStr === todayDateStr
      )
      .map((entry) => entry.activityTitle.trim().toLowerCase());
  }, [logEntries, userTz, todayDateStr]);

  // Pending Activity My Day Visibility V1 -- a client-only presentation
  // composition: today's still-pending logEntries (already reload-safe
  // and already correctly deduped against confirmation by PR #91's own
  // mergeConfirmedLogEntries), classified as "today" using the exact
  // same Timing-Location timezone helper as loggedActivitiesToday above.
  // myDay/myDay.agenda themselves are never touched -- this is passed
  // down as a separate prop, composed only at the YourDayTimeline render
  // boundary.
  const myDayPendingActivities = useMemo(
    () => selectTodaysPendingActivities(logEntries, userTz, todayDateStr),
    [logEntries, userTz, todayDateStr]
  );

  // Date-memoized Solar Ephemeris Calculation
  const solar = useMemo(() => {
    if (!user || !mounted || !todayParts) return null;
    const tzOffsetMinutes = resolveTzOffsetMinutes(user.timezone, new Date());
    return computeSolarEphemeris({
      year: todayParts.year,
      month: todayParts.month,
      day: todayParts.day,
      latitude: user.latitude,
      longitude: user.longitude,
      tzOffsetMinutes,
    });
  }, [user?.latitude, user?.longitude, user?.timezone, todayDateStr, mounted]);

  const weekday = (todayParts?.weekday ?? 0) as WeekdayIndex;

  // Memoize static daily Panchang windows
  const windows = useMemo(() => {
    return solar ? computePanchangWindows(solar, weekday) : [];
  }, [solar, weekday]);

  // Keep the device's scheduled window alerts in sync with today's windows
  // and the user's per-window preferences. Reads the current minute through a
  // ref so the per-minute clock tick doesn't cancel/reschedule every minute.
  const minuteRef = React.useRef(currentMinuteOfDay);
  minuteRef.current = currentMinuteOfDay;
  useEffect(() => {
    if (!user || windows.length === 0) return;
    syncWindowNotifications(windows, minuteRef.current, notificationPrefs).catch((err) => {
      console.warn('Could not sync window notifications:', err);
    });
  }, [user?.id, windows, notificationPrefs]);

  // Active window type lookup
  const activeType = useMemo(() => {
    return solar ? getActiveWindow(windows, currentMinuteOfDay) : 'NEUTRAL';
  }, [solar, windows, currentMinuteOfDay]);

  // Daily energy insight score
  const energyInsight = useMemo(() => {
    return computeDailyEnergyInsight(windows, activeType, currentMinuteOfDay);
  }, [windows, activeType, currentMinuteOfDay]);

  // Safe Next Shift fallback computation
  const safeNextShift = useMemo(() => {
    if (!energyInsight?.nextShift) {
      return {
        windowName: 'Next Shift',
        startsIn: 'In 1h 20m',
        startTime: '04:30 AM',
        score: 7.8,
        themeText: 'Balanced and stable energy. Good for consistent, incremental execution.',
      };
    }

    const { windowName, startsIn, startTime, score, themeText } = energyInsight.nextShift;

    const validStartsIn = startsIn && !startsIn.includes('NaN') ? startsIn : 'In 45m';
    const validStartTime = startTime && !startTime.includes('NaN') ? startTime : '11:40 AM';

    return {
      windowName: windowName ? String(windowName).replace('_', ' ') : 'Next Shift',
      startsIn: validStartsIn,
      startTime: validStartTime,
      score,
      themeText,
    };
  }, [energyInsight]);

  // Current window timing calculations for TimelineView Banner.
  //
  // This answers "how long until the next meaningful timing change" — NOT
  // "how long until this window's underlying block ends." Those are different
  // questions: when we're in a Neutral gap, the gap itself may run until
  // midnight, but if a real window (Gulika, Rahu Kalam, etc.) starts sooner,
  // that's the moment the user's experience actually changes, so that's what
  // should drive the countdown. Previously this always used the matched
  // window's own end time and fell back to literal midnight for Neutral,
  // which produced misleading "8h 9m left" countdowns straight through a
  // window that started in the next hour.
  const currentWindowInfo = useMemo(
    () => computeCurrentWindowStatus(activeType, windows, currentMinuteOfDay),
    [windows, activeType, currentMinuteOfDay]
  );

  // Dynamically map timeline windows and auto-fill unassigned time gaps as Neutral Flow
  const mappedTimelineWindows = useMemo(() => {
    const parseMinute = (val: any) => {
      if (typeof val === 'number' && !isNaN(val)) return val;
      if (typeof val === 'string' && val.includes(':')) {
        const [h, m] = val.split(':').map(Number);
        if (!isNaN(h) && !isNaN(m)) return h * 60 + m;
      }
      return 0;
    };

    const formatTime = (m: number) => {
      const totalMins = Math.floor(m) % 1440;
      const hrs = Math.floor(totalMins / 60);
      const mins = totalMins % 60;
      const period = hrs >= 12 ? 'PM' : 'AM';
      const displayHr = hrs % 12 === 0 ? 12 : hrs % 12;
      return `${displayHr}:${String(mins).padStart(2, '0')} ${period}`;
    };

    const rawWindows = windows
      .map((w: any) => {
        const windowType = w.type || w.windowType || w.name || 'NEUTRAL';
        const cleanName = String(windowType).replace('_', ' ');

        const sMin = parseMinute(w.startMinutes ?? w.startMinute ?? w.start);
        const eMin = parseMinute(w.endMinutes ?? w.endMinute ?? w.end);

        const isFriction = cleanName.includes('RAHU') || cleanName.includes('YAMA');
        const isAuspicious = cleanName.includes('ABHIJIT') || cleanName.includes('VIJAYA');

        return {
          name: cleanName,
          startMinute: sMin,
          endMinute: eMin,
          startTime: formatTime(sMin),
          endTime: formatTime(eMin),
          type: isFriction ? 'friction' : isAuspicious ? 'auspicious' : 'neutral',
          color: isFriction ? '#fb6b6b' : isAuspicious ? '#4ade80' : '#facc15',
        };
      })
      .sort((a, b) => a.startMinute - b.startMinute);

    const completeTimeline: typeof rawWindows = [];
    let currentCursor = 0;

    rawWindows.forEach((win) => {
      if (win.startMinute > currentCursor) {
        completeTimeline.push({
          name: 'Neutral Flow',
          startMinute: currentCursor,
          endMinute: win.startMinute,
          startTime: formatTime(currentCursor),
          endTime: formatTime(win.startMinute),
          type: 'neutral',
          color: '#64748b',
        });
      }
      completeTimeline.push(win);
      currentCursor = Math.max(currentCursor, win.endMinute);
    });

    if (currentCursor < 1440) {
      completeTimeline.push({
        name: 'Neutral Flow',
        startMinute: currentCursor,
        endMinute: 1440,
        startTime: formatTime(currentCursor),
        endTime: '12:00 AM',
        type: 'neutral',
        color: '#64748b',
      });
    }

    return completeTimeline;
  }, [windows]);

  // Quick-Log Habit Handler with Optimistic UI & Offline Queueing
  const handleLogActivity = useCallback(
    async (
      activityTitle: string,
      notes?: string,
      customTimestamp?: Date,
      overrideWindowType?: string,
      durationMinutes = 30,
      logSource: LogSource = 'MANUAL',
      activitySignificance?: ActivitySignificance,
      // Prospective Canonical Activity Identity V1 -- appended last so
      // every existing positional caller (Timeline, PastActivityModal via
      // onConfirmLog, etc.) keeps working unchanged. Passed straight
      // through to the server, never derived/guessed here -- the server
      // (POST /api/habit-logs) independently re-validates it against
      // FULL_ACTIVITY_CATALOG regardless of what this client sends.
      activityId?: string
    ): Promise<'confirmed' | 'pending'> => {
      const targetDate = customTimestamp ? new Date(customTimestamp) : new Date();
      const calculatedMinute = targetDate.getHours() * 60 + targetDate.getMinutes();
      const tempId = `temp-${Date.now()}`;
      // Good Right Now / Log Activity Failure State Correctness V1 --
      // generated once and reused verbatim across every retry, including
      // offline-queue replay -- never regenerated per attempt. This is
      // what lets the server (POST /api/habit-logs's own idempotent-replay
      // check) recognize a retry as the SAME request instead of a new one.
      const clientRequestId = crypto.randomUUID();
      const activeWindowForLog = overrideWindowType || activeType || 'NEUTRAL';
      const inferredSignificance = activitySignificance ?? inferActivitySignificance(activityTitle);
      const finalLogSource = logSource === 'MANUAL' && isFrictionWindow(activeWindowForLog) && inferredSignificance !== 'LOW'
        ? 'OVERRIDE_CAUTION'
        : logSource;

      const optimisticEntry: LoggedEntryItem = {
        id: tempId,
        activityTitle,
        activeWindow: activeWindowForLog,
        loggedAt: targetDate,
        logMinuteOfDay: calculatedMinute,
        durationMinutes,
        notes: notes ? String(notes).trim() : null,
        logSource: finalLogSource,
        activitySignificance: inferredSignificance,
      };

      // 1. Optimistic UI Update
      setLogEntries((prev) => [optimisticEntry, ...prev]);

      const payload = {
        activityTitle,
        // Prospective Canonical Activity Identity V1 -- only the value
        // explicitly propagated by the caller (e.g. a Good Right Now
        // ActionCard's own activityId), never derived/guessed here.
        // Omitted (undefined) for every non-catalog-backed caller, which
        // JSON.stringify drops from the request body entirely -- the
        // server then persists activityId = null, exactly as intended.
        activityId,
        activeWindow: optimisticEntry.activeWindow,
        logMinuteOfDay: calculatedMinute,
        logTimestamp: targetDate.toISOString(),
        notes: optimisticEntry.notes || undefined,
        durationMinutes,
        logSource: finalLogSource,
        activitySignificance: inferredSignificance,
        clientRequestId,
      };

      // Good Right Now / Log Activity Failure State Correctness V1 -- the
      // fetch call itself is the ONLY thing wrapped in try/catch. A thrown
      // exception here means no HTTP response was ever received (DNS
      // failure, connection reset, genuinely offline) -- the server's
      // outcome is truly ambiguous, which is the one legitimate case for
      // the offline queue. A non-2xx response, by contrast, IS a
      // definitive answer from the server and is handled below, outside
      // this catch, never queued as if it were a connectivity problem.
      let res: Response;
      try {
        res = await fetch('/api/habit-logs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } catch {
        // Pending Activity Reload Visibility V1 -- clientRequestId is
        // stamped here (it already exists as a local variable, generated
        // above) so this live, in-session pending entry carries the same
        // identity a reload-reconstructed one does. loadUserDataAndLogs's
        // own merge needs this to tell a genuinely-still-queued pending
        // row apart from a stale one whose replay was permanently
        // rejected (4xx) and already removed from the queue -- without
        // it, a permanently-failed entry could never be told apart from
        // a real one and would linger here forever instead of being
        // correctly cleared, regressing PR #86's own invariant.
        setLogEntries((prev) => prev.map((item) => (item.id === tempId ? { ...item, syncStatus: 'pending', clientRequestId } : item)));
        const rawQueue = localStorage.getItem('offline_habit_queue');
        const queue = rawQueue ? JSON.parse(rawQueue) : [];
        queue.push({ ...payload, tempId });
        localStorage.setItem('offline_habit_queue', JSON.stringify(queue));
        return 'pending';
      }

      if (!res.ok) {
        // Good Right Now / Log Activity Failure State Correctness V1 -- ANY
        // HTTP response, 4xx or 5xx alike, is a definitive server answer,
        // never an "offline" condition. Roll the optimistic entry back out
        // entirely (no lingering false-success state) and reject so the
        // caller's own catch path -- already written in every one of
        // GoodRightNowCard/Timeline/PastActivityModal, previously
        // unreachable because this function never used to reject --
        // actually runs. A 4xx would fail identically on every retry (bad
        // request/auth/unknown activity); a 5xx deserves a visible,
        // explicitly-retryable failure, not a silent invisible queue entry.
        setLogEntries((prev) => prev.filter((item) => item.id !== tempId));
        throw new Error(`Unable to log this activity (server responded ${res.status}).`);
      }

      const serverLog = await res.json();
      setLogEntries((prev) =>
        prev.map((item) =>
          item.id === tempId
            ? {
                ...item,
                id: serverLog.id,
                loggedAt: new Date(serverLog.logTimestamp || serverLog.createdAt),
                // Insights Correctness + Historical Integrity V1 -- the
                // optimistic entry's own activeWindowForLog is at best a
                // same-day guess (today's live activeType for a
                // backdated log); the server now always computes the
                // real, historically-correct window for the actual
                // logTimestamp (apps/web/lib/historicalActivityWindow.ts).
                // Sync it here so a backdated entry's displayed window
                // (and everything InsightsView derives from it) reflects
                // the authoritative value, not the optimistic guess.
                activeWindow: serverLog.activeWindow ?? item.activeWindow,
                // Insights Timezone Consistency V1 -- same reasoning as
                // activeWindow above: the optimistic calculatedMinute is
                // browser-local, the server now always derives the real
                // Timing-Location minute-of-day for the actual
                // logTimestamp (apps/web/app/api/habit-logs/route.ts).
                logMinuteOfDay: serverLog.logMinuteOfDay ?? item.logMinuteOfDay,
                syncStatus: undefined,
              }
            : item
        )
      );
      // Your Day Ghost Activities + Logged Activity Requires Refresh V1 --
      // a confirmed server-side log can change today's agenda (a linked
      // Plan flips to COMPLETED, or a bare log becomes a new
      // COMPLETED_ACTIVITY row), but myDay state is a separate snapshot
      // from logEntries and was never re-fetched here. Reuses the exact
      // same onCreated -> onMyDayChanged -> loadMyDay() pattern Plan
      // creation (MyDayStoryCard) and Day Builder Add (DayBuilderCard)
      // already use, and only fires after a CONFIRMED success -- never on
      // the pending/failure paths above, so a failed or merely-queued log
      // never makes Your Day look like it succeeded.
      loadMyDay();
      // New Aura Home V1 -- a confirmed log can also change what Plans/
      // intent exist for today, which GET /api/daily-assistant/guidance
      // depends on; refreshed alongside loadMyDay() above, same
      // confirmed-success-only discipline.
      loadGuidance();
      return 'confirmed';
    },
    [activeType, loadMyDay, loadGuidance]
  );

  const handleLogout = useCallback(async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
  }, []);

  // My Day Timing Location Change Refresh V1 -- LocationPicker only ever
  // calls onChanged (routed here) after PATCH /api/users/location has
  // already returned a real 2xx, i.e. the User row's cityName/latitude/
  // longitude/timezone are already committed (audited, not assumed -- see
  // updateUserLocation's own single UPDATE statement). GET /api/my-day and
  // GET /api/daily-assistant/* each independently re-read the User row
  // fresh (getUserById) on every request, so neither refresh below needs
  // to wait on this setUser's own render -- both are already guaranteed to
  // observe the new persisted location the moment they run. Client-side
  // Panchang (solar/windows/activeType/energyInsight, all derived via
  // useMemo from user.latitude/longitude/timezone) already recomputes
  // automatically once setUser lands; it never needed a fetch and isn't
  // touched here. Only the server-derived daily state that previously had
  // no location-change trigger at all -- My Day's agenda/story/reflection/
  // tomorrowPreview, and the daily-assistant briefing/insight/reflection
  // signals -- needed one.
  const handleLocationChanged = useCallback(async (city: { cityName: string; latitude: number; longitude: number; timezone: string; locationConfirmedAt: string | null }) => {
    setUser((prev) => (prev ? { ...prev, ...city } : prev));
    await Promise.all([loadMyDay(), loadAssistantSignals()]);
  }, [loadMyDay, loadAssistantSignals]);

  // Onboarding V1 PR 1 -- the global disclosure banner's one action:
  // reuses the EXISTING Location & Time editing experience (YouView ->
  // LocationPicker), never a new form. Setting activeTab directly (no
  // window.location.href reload) keeps this a normal in-SPA navigation,
  // same as every other setActiveTab call in this file.
  const handleConfirmLocationFromBanner = useCallback(() => {
    setYouInitialPanel('location');
    setActiveTab('you');
  }, []);

  // Onboarding V1 PR 2 -- the journey's own TRUE exit points, exactly three:
  // Welcome's "Skip for now", Recommendation's "Go to Home", and
  // Recommendation's "Plan my day" (the last via the onPlanMyDay callback
  // below, which also calls this). The Location step's OWN "Skip" is
  // deliberately NOT wired here -- it only advances to the Recommendation
  // step (OnboardingJourney.tsx's own onSkip={() => setStep('RECOMMENDATION')}),
  // which is not itself an exit (First-Run Reliability Correction's own
  // explicit rule: advancing between steps never resolves onboarding).
  //
  // First-Run Reliability Correction -- this is also the ONE place
  // onboarding resolution is persisted: fires PATCH /api/users/onboarding
  // best-effort (never awaited before letting the user proceed, same
  // fire-and-forget convention as loadAuraUpdates/trackEvent elsewhere in
  // this file) so a slow or failed request can never trap the user behind
  // onboarding or delay reaching Home. A failed request is never reported
  // as success to the user (there is no "saved!" UI here to lie in) and
  // naturally retries itself: if it didn't persist, the user's NEXT visit
  // still sees onboardingResolved false and will resolve it again the next
  // time they exit -- no client-side retry queue needed. Local state
  // (`setOnboardingActive(false)`) is never rolled back on failure, so the
  // user is never yanked back into onboarding within this same page load
  // regardless of the request's outcome.
  const handleExitOnboarding = useCallback(() => {
    setOnboardingActive(false);
    fetch('/api/users/onboarding', { method: 'PATCH' }).catch(() => {});
  }, []);

  const handleTimingSearch = useCallback(async (request: {
    mode: TimingSearchMode;
    activityId?: string;
    taskTitle?: string;
    durationMinutes: number;
    dateRange?: TimingSearchDateRange;
    horizon?: PlanningHorizon;
    customStartDate?: string;
    customEndDate?: string;
    timePreference?: TimingTimePreference;
    limit?: number;
    candidateStart?: string;
    checkNearbyWindowMinutes?: number;
    candidateStarts?: string[];
  }): Promise<TimingSearchResponseWithDailyRhythm> => {
    const res = await fetch('/api/timing-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...request, clientNow: new Date().toISOString() }),
    });
    if (!res.ok) throw new Error('Unable to run timing search.');
    return res.json();
  }, []);

  // Plan Log -> My Day Refresh Consistency V1 -- POST /api/plans/[planId]/log
  // (logPlannedActivity) is a single DB transaction: a 2xx response is
  // unconditional proof BOTH the HabitLog insert and the PlannedActivity
  // status update committed together (audited, not assumed -- see
  // logPlannedActivity's own BEGIN/COMMIT). loadUserDataAndLogs already
  // refreshes user/logEntries/habits/plannedActivities on that same
  // confirmed-success signal, but never touched myDay -- Your Day
  // Timeline, Daily Story, and the Next Best Moment selection all stayed
  // on their pre-log snapshot until an unrelated event (a tab switch, a
  // day-boundary check) happened to refetch it. One shared callback, used
  // at every confirmed Plan-log call site, closes that gap the same way
  // PR #86 already closed it for direct HabitLog logging: both refreshes
  // are independent GETs, run concurrently, and -- like every other
  // loadMyDay() call site in this file -- only ever invoked after a real
  // server confirmation, never from a catch/failure path.
  const handlePlanLogged = useCallback(async () => {
    // New Aura Home V1 -- loadGuidance() added alongside the existing two
    // refreshes; a logged Plan can change today's eligible-intent set.
    await Promise.all([loadUserDataAndLogs(), loadMyDay(), loadGuidance()]);
  }, [loadUserDataAndLogs, loadMyDay, loadGuidance]);

  // New Aura Home V1 -- passed to HomeDashboard as onMyDayChanged in
  // place of the bare loadMyDay reference, so both of its own existing
  // confirmed-success call sites (MyDayStoryCard's onCreated after a new
  // Plan is created, DayBuilderCard's onCreated after "Add") also refresh
  // guidance -- a newly-created Plan/intent is exactly what
  // GET /api/daily-assistant/guidance needs to see.
  // Daily Experience V1 PR B -- Home's own post-completion synchronization. NOT
  // handlePlanLogged: loadUserDataAndLogs clears the authenticated user on ANY
  // exception, so a transient refresh failure right after a durable completion
  // would render the sign-in screen. This path never touches `user`; each slice
  // keeps its last-known-good value on failure; a definitive 401 re-runs the
  // authoritative session check (loadUserDataAndLogs).
  const handleHomePlanCompleted = useCallback(
    () =>
      refreshAfterHomeCompletion({
        fetchImpl: (...args) => fetch(...args),
        applyLogs: (json) => applyConfirmedLogs(json as any[]),
        applyHabits: (json) => setHabits(json as any),
        applyPlans: (json) => setPlannedActivities(json as any),
        refreshMyDay: loadMyDay,
        refreshGuidance: loadGuidance,
        refreshAuraUpdates: loadAuraUpdates,
        reauthenticate: loadUserDataAndLogs,
      }).then(() => undefined),
    [applyConfirmedLogs, loadMyDay, loadGuidance, loadAuraUpdates, loadUserDataAndLogs]
  );

  const handleMyDayOrGuidanceChanged = useCallback(() => {
    loadMyDay();
    loadGuidance();
  }, [loadMyDay, loadGuidance]);

  // HPG1 -- activityId is optional; pass it only when the caller already
  // resolved a genuine catalog id (never derive one here from `activity`'s
  // text). Every existing caller that doesn't have one keeps working
  // exactly as before -- the title-only path is entirely unchanged.
  const handleOpenPlan = useCallback((activity?: string, activityId?: string) => {
    const cleanActivity = activity?.trim();
    if (cleanActivity) {
      setPlanPrefill({ activity: cleanActivity, activityId, key: Date.now() });
    }
    setActiveTab('plan');
  }, []);

  // Daily Reflection & Tomorrow Preview V1 (brief section 5) -- "Plan
  // tomorrow" (generic, or from a "Make room for..." suggestion) never
  // creates a Plan directly. It routes into the exact same Plan/Timing
  // Search screen handleOpenPlan already uses, just with the horizon
  // preset to TOMORROW and, when a suggestion carried one, an activity
  // preselected -- the actual search/creation happens in Plan itself.
  const handlePlanTomorrow = useCallback((activityTitle?: string) => {
    const resolvedActivityId = activityTitle ? findActivityIntent(activityTitle)?.id : undefined;
    trackEvent('TOMORROW_PLAN_STARTED', resolvedActivityId ? { metadata: { activityId: resolvedActivityId } } : undefined);
    setPlanPrefill({ activity: activityTitle?.trim() ?? '', key: Date.now(), horizon: 'TOMORROW' });
    setActiveTab('plan');
  }, []);

  const handleViewFullPanchang = useCallback((dateStr: string) => {
    setPanchangDateJump({ date: dateStr, key: Date.now() });
    setActiveTab('panchang');
  }, []);

  // Bug fix: a plain "open Panchang" entry point (Explore's card, Muhurtham
  // Finder's "Open Panchang Calendar") used to just setActiveTab('panchang')
  // directly, leaving whatever panchangDateJump handleViewFullPanchang had
  // set earlier in the session still in place -- PanchangCalendarView's own
  // initialSelectedDate effect re-applies it on every fresh mount, so
  // clicking Explore's "Today · <date>" card could silently land on a stale
  // date from an unrelated earlier "View full Panchang" click instead of
  // today. Clearing the jump here (only handleViewFullPanchang above should
  // ever set a real one) fixes every plain entry point at once.
  const handleOpenPanchang = useCallback(() => {
    setPanchangDateJump(null);
    setActiveTab('panchang');
  }, []);

  // Explore's Quick Explore shortcuts -- identical pattern to
  // handleViewFullPanchang above, just for Muhurtham Finder's activity
  // instead of Panchang's date.
  const handleOpenMuhurthamWithActivity = useCallback((activityId: string) => {
    setMuhurthamActivityJump({ activityId, key: Date.now() });
    setActiveTab('muhurtham');
  }, []);

  const handleSubmitReflection = useCallback(async (
    outputLevel: 'LOW' | 'MODERATE' | 'PEAK_FLOW',
    followedGuidance: boolean
  ) => {
    const res = await fetch('/api/daily-assistant/reflection', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ outputLevel, followedGuidance }),
    });
    if (!res.ok) throw new Error('Unable to save reflection.');

    const insightRes = await fetch('/api/daily-assistant/insights');
    if (insightRes.ok) setAssistantInsight(await insightRes.json());
    setTodayReflection({ outputLevel, followedGuidance });
  }, []);

  if (user === undefined) {
    return (
      <main style={{ minHeight: '100vh', background: 'var(--as-bg, #020617)', color: 'var(--as-text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        Loading...
      </main>
    );
  }

  if (user === null) {
    return <LoginScreen onLoggedInCheck={loadUserDataAndLogs} />;
  }

  const userNameDisplay = formatDisplayName(user.email);

  // Onboarding V1 PR 2 -- the Welcome journey renders INSTEAD OF the normal
  // tab UI below, never alongside it, and never blocks it: every exit path
  // (Skip, Go to Home, Plan my day) calls handleExitOnboarding, after which
  // this condition is permanently false for the rest of this page load, and
  // the exact same Home/tabs tree below renders as it always has.
  if (onboardingActive) {
    return (
      <OnboardingJourney
        userName={userNameDisplay}
        cityName={user.cityName}
        latitude={user.latitude}
        longitude={user.longitude}
        timezone={user.timezone}
        locationConfirmed={user.locationConfirmedAt != null}
        onLocationChanged={handleLocationChanged}
        nextShift={mounted ? energyInsight.nextShift : undefined}
        hasRealRecommendation={mounted && windows.length > 0}
        onExit={handleExitOnboarding}
        onPlanMyDay={() => {
          handleExitOnboarding();
          window.location.href = '/plan-day';
        }}
      />
    );
  }

  return (
    <main
      style={{
        minHeight: '100vh',
        background: 'var(--as-bg, #020617)',
        color: 'var(--as-text, #f8fafc)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: 'calc(env(safe-area-inset-top, 16px) + 12px) 16px 90px',
        boxSizing: 'border-box',
      }}
    >
      {/* Real-Time Solar Phase Shift Toast Banner */}
      <WindowShiftToast activeWindowName={activeType} />

      {/* Onboarding V1 PR 1 -- Location Trust Foundation: the ONE
          centralized disclosure, visible on every tab (rendered once,
          above all per-tab content), never a per-feature reimplementation. */}
      <div style={{ width: '100%', maxWidth: 760 }}>
        <LocationTrustBanner
          locationConfirmed={user.locationConfirmedAt != null}
          cityName={user.cityName}
          onConfirmLocation={handleConfirmLocationFromBanner}
        />
      </div>

      {activeTab === 'chart' && (
        <header
          style={{
            width: '100%',
            maxWidth: 760,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 16,
            padding: '0 4px',
          }}
        >
          <div>
            <h1 style={{ fontSize: 20, margin: 0, lineHeight: 1.15 }}>Birth Chart</h1>
            <p style={{ fontSize: 12, color: '#b6c2d1', margin: '4px 0 0' }}>
              Personal timing map and daily transit context.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('you')}
            aria-label="Back to You"
            style={{
              fontSize: 11,
              color: '#4ade80',
              background: 'rgba(255,255,255,0.06)',
              border: '1px solid #4ade80',
              borderRadius: 14,
              padding: '6px 10px',
              cursor: 'pointer',
              minHeight: 32,
              flexShrink: 0,
            }}
          >
            Back to You
          </button>
        </header>
      )}

      {/* Aura UI Experience V2 (brief section 7/89) -- one shared content
       * max-width for every main screen. Was 760 for Home/Plan/Explore but
       * 420 for every other tab, a real "inconsistent screen widths" bug on
       * anything wider than a phone; harmless on mobile since the actual
       * rendered width is always min(100%, maxWidth). */}
      <div style={{ width: '100%', maxWidth: 760 }}>
        {activeTab === 'home' && (
          <HomeDashboard
            userId={user?.id}
            userName={userNameDisplay}
            energyScore={energyInsight.score}
            themeText={energyInsight.themeText}
            nextShift={safeNextShift}
            currentWindow={currentWindowInfo}
            activeWindowName={activeType}
            dayWindows={mappedTimelineWindows}
            loggedActivitiesToday={loggedActivitiesToday}
            dailyBriefing={dailyBriefing}
            personalContext={personalContext}
            todayReflection={todayReflection}
            onLogActivity={handleLogActivity}
            onSubmitReflection={handleSubmitReflection}
            onNextShiftClick={() => setActiveTab('timeline')}
            focusTimelineKey={homeTimelineFocusKey}
            onPlanClick={handleOpenPlan}
            onPlanDay={() => { window.location.href = '/plan-day'; }}
            onInsightsClick={() => setActiveTab('insights')}
            onNotificationsClick={handleOpenUpdates}
            unreadUpdatesCount={auraUpdates?.unreadCount}
            onPanchangClick={() => setActiveTab('explore')}
            onExploreClick={() => setActiveTab('explore')}
            // Only surface something that still needs the owner's attention --
            // updates[0] alone could be an already-resolved/seen entry that's
            // merely the most recent, which read as a stale "Find another
            // time" prompt after the owner had already handled it.
            topMomentUpdate={auraUpdates?.updates?.find((update) => update.requiresAction || (update.type === 'MOMENT_ACCEPTED' && update.unread))}
            onViewMomentUpdate={handleViewMomentUpdate}
            onViewMomentInvitation={handleViewMomentInvitation}
            onFindAnotherTimeForMoment={handleFindAnotherTimeForMoment}
            startingSoonReminders={auraUpdates?.upcoming}
            onOpenReminder={handleOpenReminder}
            myDayAgenda={myDay?.agenda}
            myDayStory={myDay?.story}
            myDayReflection={myDay?.reflection}
            myDayTomorrowPreview={myDay?.tomorrowPreview}
            myDayPendingActivities={myDayPendingActivities}
            logEntries={logEntries}
            timezone={userTz}
            currentMinuteOfDay={currentMinuteOfDay}
            onMyDayChanged={handleMyDayOrGuidanceChanged}
            onPlanCompleted={handleHomePlanCompleted}
            guidance={guidance}
            onOpenBirthProfile={() => setActiveTab('chart')}
            onOpenAgendaItem={handleOpenAgendaItem}
            onPlanTomorrow={handlePlanTomorrow}
            onMuteDayBuilderGroup={(groupId) =>
              handleDayBuilderPrefsChange({
                dayBuilderMutedGroups: Array.from(new Set([...user.dayBuilderMutedGroups, groupId])),
              })
            }
            dayBuilderEnabled={user.dayBuilderEnabled}
            dayBuilderPriorities={user.dayBuilderPriorities}
            dayBuilderPrioritiesPromptDismissed={user.dayBuilderPrioritiesPromptDismissed}
            onDayBuilderPrefsChange={handleDayBuilderPrefsChange}
            onTimingSearch={handleTimingSearch}
            assistantInsight={assistantInsight}
          />
        )}

        {activeTab === 'timeline' && (
          <TimelineView
            currentWindow={currentWindowInfo}
            currentMinuteOfDay={currentMinuteOfDay}
            windows={mappedTimelineWindows}
            logEntries={logEntries}
            loggedActivitiesToday={loggedActivitiesToday}
            onLogActivity={handleLogActivity}
            onPlanActivity={handleOpenPlan}
            onAskAuraClick={() => setActiveTab('ask')}
          />
        )}

        {activeTab === 'ask' && (
          <AskAuraView
            userName={userNameDisplay}
            activeWindow={activeType}
            cityName={user.cityName}
            onPlanLogged={handlePlanLogged}
            onViewTimeline={() => setActiveTab('timeline')}
            onViewHomeDay={() => { setHomeTimelineFocusKey(Date.now()); setActiveTab('home'); }}
            onOpenPlan={handleOpenPlan}
            onOpenPanchang={handleOpenPanchang}
            onOpenMuhurthamWithActivity={handleOpenMuhurthamWithActivity}
          />
        )}

        {activeTab === 'plan' && (
          <PlanWithAuraView
            onTimingSearch={handleTimingSearch}
            onViewDay={() => { setHomeTimelineFocusKey(Date.now()); setActiveTab('home'); }}
            onPlanLogged={handlePlanLogged}
            timezone={user.timezone}
            initialActivity={planPrefill?.activity}
            initialActivityId={planPrefill?.activityId}
            initialActivityKey={planPrefill?.key}
            initialHorizon={planPrefill?.horizon}
            onOpenPeople={() => { setPeopleReturnTo('plan'); setActiveTab('people'); }}
            focusMomentsKey={momentsFocusKey}
            focusMomentToken={momentsFocusToken}
            onMomentSeen={loadAuraUpdates}
            focusPlansKey={planFocusKey}
            focusPlanId={planFocusId}
            focusPlansFilter={planFocusFilter}
          />
        )}

        {activeTab === 'insights' && (
          <InsightsView
            userId={user?.id}
            onOpenBirthProfile={() => setActiveTab('chart')}
            timezone={user.timezone}
            logEntries={logEntries}
            assistantInsight={assistantInsight}
            goalReporting={goalReporting}
            goalReportingStatus={goalReportingStatus}
            onOpenPlanReview={(target) => {
              // Insights V1 PR7 (finding F-4) -- carry the clicked
              // suggestion's own plan identity (if any) into the Plan tab
              // instead of always landing on the generic composer.
              // planFocusKey increments every click so the destination
              // effect re-fires even when the SAME plan is requested twice
              // in a row (same pattern momentsFocusKey already uses).
              setPlanFocusId(target?.planId ?? null);
              setPlanFocusFilter(target?.planFilter ?? null);
              setPlanFocusKey((key) => key + 1);
              setActiveTab('plan');
            }}
          />
        )}

        {activeTab === 'you' && (
          <YouView
            userName={userNameDisplay}
            email={user.email}
            cityName={user.cityName}
            timezone={user.timezone}
            latitude={user.latitude}
            longitude={user.longitude}
            locationConfirmed={user.locationConfirmedAt != null}
            initialOpenPanel={youInitialPanel}
            notificationPrefs={notificationPrefs}
            onNotificationPrefsChange={(next) => {
              setNotificationPrefs(next);
              saveNotificationPrefs(next);
            }}
            onLocationChanged={handleLocationChanged}
            onOpenHome={() => setActiveTab('home')}
            onOpenChart={() => setActiveTab('chart')}
            onOpenActivityLog={() => setActiveTab('activity')}
            onOpenPeople={() => { setPeopleReturnTo('you'); setActiveTab('people'); }}
            onOpenSharedMoments={handleOpenMomentsFromYou}
            onSignOut={handleLogout}
            // Deliberately the MOMENT-only unread count, not the combined
            // Bell badge total (auraUpdates.unreadCount now also folds in
            // active reminders, brief section 18) -- this row is
            // specifically "Moments you've created and their responses", so
            // it should never show a count driven by an unrelated Plan
            // reminder.
            sharedMomentsUnreadCount={auraUpdates?.updates?.filter((update) => update.unread).length}
            remindersEnabled={user.remindersEnabled}
            onRemindersEnabledChange={handleRemindersEnabledChange}
            dayBuilderEnabled={user.dayBuilderEnabled}
            dayBuilderMutedGroups={user.dayBuilderMutedGroups}
            dayBuilderPriorities={user.dayBuilderPriorities}
            dayBuilderPriorityPersonIds={user.dayBuilderPriorityPersonIds}
            onDayBuilderPrefsChange={handleDayBuilderPrefsChange}
          />
        )}

        {activeTab === 'chart' && <BirthChartSection />}

        {activeTab === 'people' && <PeopleView onBack={() => setActiveTab(peopleReturnTo)} />}

        {activeTab === 'activity' && (
          <CalendarViewSection
            logEntries={logEntries}
            userLocation={{ latitude: user.latitude, longitude: user.longitude, timezone: user.timezone }}
            onLogActivity={handleLogActivity}
            onBack={() => setActiveTab('you')}
          />
        )}

        {activeTab === 'explore' && (
          <ExploreView
            timezone={user.timezone}
            onOpenPanchang={handleOpenPanchang}
            onOpenMuhurtham={() => setActiveTab('muhurtham')}
            onOpenMuhurthamWithActivity={handleOpenMuhurthamWithActivity}
            onOpenForwardPlanner={() => setActiveTab('planner')}
          />
        )}

        {activeTab === 'planner' && (
          <ForwardPlannerView timezone={user.timezone} onBack={() => setActiveTab('explore')} onOpenBirthProfile={() => setActiveTab('chart')} />
        )}

        {activeTab === 'panchang' && (
          <PanchangCalendarView
            timezone={user.timezone}
            onBack={() => setActiveTab('explore')}
            onViewTodayRhythm={() => setActiveTab('timeline')}
            onExploreActivities={() => setActiveTab('plan')}
            onOpenMuhurtham={() => setActiveTab('muhurtham')}
            initialSelectedDate={panchangDateJump?.date}
            initialSelectedDateKey={panchangDateJump?.key}
          />
        )}

        {activeTab === 'muhurtham' && (
          <MuhurthamFinderView
            timingLocation={{ cityName: user.cityName, latitude: user.latitude, longitude: user.longitude, timezone: user.timezone }}
            locationConfirmed={user.locationConfirmedAt != null}
            onBack={() => setActiveTab('explore')}
            onOpenPanchangCalendar={handleOpenPanchang}
            onViewFullPanchang={handleViewFullPanchang}
            onPlanLogged={handlePlanLogged}
            onOpenBirthProfile={() => setActiveTab('chart')}
            onOpenPeople={() => { setPeopleReturnTo('you'); setActiveTab('people'); }}
            initialActivityId={muhurthamActivityJump?.activityId}
            initialActivityIdKey={muhurthamActivityJump?.key}
          />
        )}

        {activeTab === 'updates' && (
          <UpdatesView
            updates={auraUpdates?.updates ?? []}
            upcoming={auraUpdates?.upcoming ?? []}
            onBack={() => setActiveTab('home')}
            onViewMomentUpdate={handleViewMomentUpdate}
            onViewMomentInvitation={handleViewMomentInvitation}
            onFindAnotherTimeForMoment={handleFindAnotherTimeForMoment}
            onOpenReminder={handleOpenReminder}
          />
        )}
      </div>

      {/* Navigation Dock */}
      <nav
        style={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          height: 60,
          background: 'rgba(15, 23, 42, 0.95)',
          backdropFilter: 'blur(16px)',
          borderTop: '1px solid rgba(255, 255, 255, 0.12)',
          display: 'grid',
          gridTemplateColumns: 'repeat(6, 1fr)',
          padding: '4px 8px calc(env(safe-area-inset-bottom, 0px) + 4px)',
          zIndex: 9999,
        }}
      >
        <NavButton label="Home" icon="🏠" active={activeTab === 'home' || (activeTab === 'people' && peopleReturnTo === 'home')} onClick={() => setActiveTab('home')} />
        <NavButton label="Plan" icon="✨" active={activeTab === 'plan' || (activeTab === 'people' && peopleReturnTo === 'plan')} onClick={() => setActiveTab('plan')} />
        <NavButton label="Explore" icon="🧭" active={activeTab === 'explore' || activeTab === 'panchang' || activeTab === 'muhurtham' || activeTab === 'planner'} onClick={() => setActiveTab('explore')} />
        <NavButton label="Ask Aura" icon="🤖" active={activeTab === 'ask'} onClick={() => setActiveTab('ask')} />
        <NavButton label="Insights" icon="📊" active={activeTab === 'insights'} onClick={() => setActiveTab('insights')} />
        <NavButton label="You" icon="👤" active={activeTab === 'you' || activeTab === 'chart' || activeTab === 'activity' || (activeTab === 'people' && peopleReturnTo === 'you')} onClick={() => setActiveTab('you')} />
      </nav>
    </main>
  );
}

const NavButton = React.memo(function NavButton({ label, icon, active, onClick }: any) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        background: 'none',
        border: 'none',
        color: active ? 'var(--as-abhijit, #4ade80)' : 'var(--as-text-muted, #94a3b8)',
        fontSize: 10,
        fontFamily: 'var(--as-font-mono, monospace)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 2,
        cursor: 'pointer',
      }}
    >
      <span style={{ fontSize: 16 }}>{icon}</span>
      <span style={{ fontWeight: active ? 600 : 400 }}>{label}</span>
    </button>
  );
});
