'use client';

import React, { useEffect, useState } from 'react';
import { colors, spacing, typography } from '../../../components/theme';
import { PageHeader, SurfaceCard, PrimaryButton, SecondaryButton, TextButton, DestructiveButton, StatusBadge, EmptyState, FieldLabel, TextInput, FieldError } from '../../../components/ui';
import { RhythmPicker, type RhythmPickerValue } from '../../../components/RhythmPicker';
import {
  formatGoalActivityCompletion,
  formatGoalActivityRhythmFrequencyLabel,
  formatGoalActivityRhythmWeeklyProgressLabel,
  formatGoalActivityRhythmRemainingCapacityLabel,
  formatGoalProgressLabel,
  formatGoalTargetDateLabel,
  presentGoalActivityRhythmAwareStateLabel,
  type GoalActivityView,
  type GoalDetailView,
} from '../../../lib/goalsPresentation';

/**
 * Goals -> Planning Integration V1 PR B -- Goal detail: "What does
 * progress toward this Goal look like?" (this ticket's own section 16).
 *
 * No scheduling occurs here (this ticket's own PRODUCT PRINCIPLE): every
 * activity row is either an uncommitted suggestion (Dismiss only -- no
 * selection controls, see the doc comment on SUGGESTED rows below for
 * why) or a read-only reflection of a REAL PlannedActivity/HabitLog
 * elsewhere in the app. Nothing here ever calls the Plan My Day/Day
 * Constructor/acceptance stack.
 */

type LoadState = { status: 'LOADING' } | { status: 'LOADED'; detail: GoalDetailView } | { status: 'NOT_FOUND' } | { status: 'ERROR' };

export function GoalDetailClient({ goalId, authenticated }: { goalId: string; authenticated: boolean }) {
  useEffect(() => {
    if (!authenticated) window.location.href = '/';
  }, [authenticated]);
  if (!authenticated) return null;

  return <GoalDetailView goalId={goalId} />;
}

function GoalDetailView({ goalId }: { goalId: string }) {
  const [state, setState] = useState<LoadState>({ status: 'LOADING' });

  const load = async () => {
    setState({ status: 'LOADING' });
    try {
      const res = await fetch(`/api/goals/${goalId}`);
      if (res.status === 404) {
        setState({ status: 'NOT_FOUND' });
        return;
      }
      if (!res.ok) throw new Error('failed');
      const detail = await res.json();
      if (!detail?.goal) throw new Error('failed');
      setState({ status: 'LOADED', detail });
    } catch {
      setState({ status: 'ERROR' });
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [goalId]);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--as-bg)', color: colors.textPrimary, fontFamily: 'var(--as-font-body)', display: 'flex', justifyContent: 'center', padding: `${spacing.xxxl}px ${spacing.lg}px` }}>
      <div style={{ width: '100%', maxWidth: 480 }}>
        <div style={{ marginBottom: spacing.lg }}>
          <TextButton onClick={() => { window.location.href = '/goals'; }} color={colors.textMuted}>
            ← Back to Goals
          </TextButton>
        </div>

        {state.status === 'LOADING' && <DetailSkeleton />}

        {state.status === 'NOT_FOUND' && (
          <SurfaceCard>
            {/* This ticket's own section 31 -- identical presentation for
                "doesn't exist" and "belongs to another user"; the API
                itself already returns the same 404 for both. */}
            <EmptyState title="This goal isn't available" description="It may have been removed, or the link may be incorrect." action={<SecondaryButton onClick={() => { window.location.href = '/goals'; }}>Back to Goals</SecondaryButton>} />
          </SurfaceCard>
        )}

        {state.status === 'ERROR' && (
          <SurfaceCard>
            <FieldError>Couldn&apos;t load this goal.</FieldError>
            <div style={{ marginTop: spacing.md }}>
              <SecondaryButton onClick={() => void load()}>Try again</SecondaryButton>
            </div>
          </SurfaceCard>
        )}

        {state.status === 'LOADED' && <GoalDetailBody detail={state.detail} onChanged={load} />}
      </div>
    </div>
  );
}

function DetailSkeleton() {
  return (
    <div aria-busy="true" aria-label="Loading goal">
      <SurfaceCard style={{ opacity: 0.5 }}>
        <div style={{ height: 18, width: '70%', background: colors.borderSubtle, borderRadius: 6 }} />
        <div style={{ height: 10, width: '40%', background: colors.borderSubtle, borderRadius: 6, marginTop: spacing.md }} />
      </SurfaceCard>
    </div>
  );
}

function GoalDetailBody({ detail, onChanged }: { detail: GoalDetailView; onChanged: () => void }) {
  const { goal, activities, progress } = detail;
  // This ticket's own section 20/23 -- dismissed activities are hidden
  // from the primary list entirely (no restore action exists, so a
  // collapsed "Dismissed" section would be dead weight -- absence is
  // preferable per this ticket's own section 19 principle, applied here
  // too).
  const primaryActivities = activities.filter((a) => a.derivedState !== 'DISMISSED');

  // Goals -> Planning Integration V1 PR C -- selection lives HERE (the
  // parent), not on each ActivityRow, because the primary CTA (below)
  // needs the complete selected set, and because eligibility can change
  // out from under a stale selection (e.g. `onChanged` refetches after a
  // Dismiss/Add elsewhere on this same page) -- `effectiveSelectedIds`
  // recomputes the intersection with CURRENTLY-SUGGESTED activities on
  // every render, so a row that became ineligible between selection and
  // render is silently dropped from the count/CTA rather than seeding a
  // stale id (this ticket's own section 8 applied client-side too, as a
  // first line of defense -- the real enforcement is server-side, at
  // /plan-day's own bootstrap).
  const [selectedIds, setSelectedIds] = useState<ReadonlySet<string>>(new Set());
  // Goals V2 Rhythm R3 -- selectable now means SUGGESTED (unchanged) OR a
  // COMPLETED or PLANNED activity whose own Rhythm policy still has
  // weekly capacity (server-derived; a finite/NONE COMPLETED or PLANNED
  // activity remains unselectable, same as always).
  // Rhythm R4 reads this same fact through the canonical `rhythm` shape
  // (`rhythm.eligibleForAnotherOccurrence`) instead of R3's own interim
  // flat `rhythmEligibleForAnotherOccurrence` field -- identical logic, one
  // canonical read model (see goalsPresentation.ts's own doc comment on
  // GoalActivityView.rhythm).
  //
  // Multi-Occurrence Rhythm PR 2 corrective fix -- PLANNED is now also
  // admitted (previously only COMPLETED was), matching
  // resolveGoalActivityHandoff's own parity fix: GoalActivity.plannedActivityId
  // now tracks "the most recently materialized occurrence," so a PLANNED
  // row can still have real remaining weekly capacity for another
  // occurrence, exactly like Plan My Day's automatic suggestions already
  // allow.
  const isSelectable = (a: GoalActivityView) => a.derivedState === 'SUGGESTED' || ((a.derivedState === 'COMPLETED' || a.derivedState === 'PLANNED') && a.rhythm.kind === 'N_PER_WEEK' && a.rhythm.eligibleForAnotherOccurrence);
  const selectableIds = new Set(primaryActivities.filter(isSelectable).map((a) => a.id));
  const effectiveSelectedIds = Array.from(selectedIds).filter((id) => selectableIds.has(id));

  const toggleSelected = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handlePlanWithAura = () => {
    if (effectiveSelectedIds.length === 0) return;
    // This ticket's own section 6 -- IDs only, never titles/activityIds.
    // Plan My Day's own bootstrap (planDayBootstrap.ts's
    // resolveGoalActivityHandoff) re-resolves everything server-side from
    // these ids alone.
    const params = new URLSearchParams({ fromGoal: goal.id, activities: effectiveSelectedIds.join(',') });
    window.location.href = `/plan-day?${params.toString()}`;
  };

  return (
    <div>
      <PageHeader title={goal.title} subtitle={goal.targetDate ? `Target ${formatGoalTargetDateLabel(goal.targetDate)}` : undefined} />

      {/* Goals V2 Rhythm R4 -- this ticket's own section 17-19: a finite
          "N of M completed" bar cannot honestly describe a Goal containing
          an ongoing N_PER_WEEK activity (it could show "1 of 1 completed"
          the moment a single ongoing session is logged, directly
          contradicting the fact that another occurrence is still eligible
          this week, or will be again next week). formatGoalProgressLabel
          returns null for exactly that case (server-computed
          hasOngoingRhythmActivity) -- the whole card, including the bar,
          is hidden rather than shown with misleading numbers. */}
      {formatGoalProgressLabel(progress) && (
        <div style={{ marginTop: spacing.lg }}>
          <SurfaceCard>
            <div style={{ ...typography.bodyStrong }}>{formatGoalProgressLabel(progress)}</div>
            {progress.total > 0 && (
              <div style={{ marginTop: spacing.sm, height: 6, borderRadius: 999, background: colors.borderSubtle, overflow: 'hidden' }} role="progressbar" aria-valuenow={progress.completed} aria-valuemin={0} aria-valuemax={progress.total} aria-label="Goal progress">
                <div style={{ height: '100%', width: `${Math.round((progress.completed / progress.total) * 100)}%`, background: colors.positive, borderRadius: 999 }} />
              </div>
            )}
          </SurfaceCard>
        </div>
      )}

      <div style={{ marginTop: spacing.xxl }}>
        <h2 style={typography.sectionEyebrow}>Activities</h2>
        {selectableIds.size > 0 && <p style={{ ...typography.meta, marginTop: spacing.xs }}>What would you like Aura to help you plan?</p>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.md, marginTop: spacing.md }}>
          {primaryActivities.length === 0 && (
            <SurfaceCard>
              <EmptyState title="No activities yet" description="Add an activity to get started." />
            </SurfaceCard>
          )}
          {primaryActivities.map((activity) => (
            <ActivityRow
              key={activity.id}
              activity={activity}
              onChanged={onChanged}
              selected={isSelectable(activity) ? selectedIds.has(activity.id) : undefined}
              onToggleSelect={isSelectable(activity) ? () => toggleSelected(activity.id) : undefined}
            />
          ))}
        </div>

        {/* This ticket's own section 5 -- appears only once at least one
            eligible activity is selected; "Plan with Aura" (existing
            product vocabulary), never "Schedule automatically" (Aura has
            committed nothing yet). */}
        {effectiveSelectedIds.length > 0 && (
          <div style={{ marginTop: spacing.md }}>
            <PrimaryButton onClick={handlePlanWithAura}>
              Plan with Aura{effectiveSelectedIds.length > 1 ? ` (${effectiveSelectedIds.length})` : ''}
            </PrimaryButton>
          </div>
        )}

        <div style={{ marginTop: spacing.md }}>
          <AddActivityControl goalId={goal.id} onAdded={onChanged} />
        </div>
      </div>

      <div style={{ marginTop: spacing.xxxl }}>
        <GoalLifecycleActions goal={goal} />
      </div>
    </div>
  );
}

// ============================================================
// ActivityRow (this ticket's own section 17/18/24/25/26)
// ============================================================

function ActivityRow({
  activity,
  onChanged,
  selected,
  onToggleSelect,
}: {
  activity: GoalActivityView;
  onChanged: () => void;
  /** Goals -> Planning Integration V1 PR C -- undefined for any
   * non-selectable activity (PLANNED/DISMISSED, and a finite/NONE
   * COMPLETED activity, render no checkbox at all, not a disabled one).
   * Goals V2 Rhythm R3 -- ALSO defined for a COMPLETED activity whose own
   * Rhythm policy still has weekly capacity (GoalDetailBody's own
   * `isSelectable`, this ticket's own section 37) -- the parent is the
   * single source of truth for eligibility; this component trusts
   * whichever of `selected`/`onToggleSelect` it is actually given, never
   * re-derives SUGGESTED-only itself. Selection is local UI state owned by
   * the parent; see GoalDetailBody's own doc comment for why it lives
   * there, not here. */
  selected?: boolean;
  onToggleSelect?: () => void;
}) {
  const [dismissing, setDismissing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Goals V2 Rhythm R4 -- Rhythm-aware: a permanent "Completed" badge is
  // misleading for an N_PER_WEEK activity (this ticket's own section
  // 14/15/23 -- it can become eligible again next week). NONE activities
  // pass straight through to the original presentGoalActivityStateLabel
  // unchanged (this ticket's own section 15 "preserve current derivedState
  // labels exactly").
  const stateLabel = presentGoalActivityRhythmAwareStateLabel(activity.derivedState, activity.rhythm);
  const isSelectable = onToggleSelect !== undefined;
  // Goals V2 Rhythm R4 -- an ongoing activity that is still eligible for
  // another occurrence this week should not read as "done and dimmed" the
  // way a truly finite COMPLETED activity does (this ticket's own section
  // 15 -- it remains actionable, not a closed-out row).
  const isDimmed = activity.derivedState === 'COMPLETED' && !(activity.rhythm.kind === 'N_PER_WEEK' && activity.rhythm.eligibleForAnotherOccurrence);
  // Goals V2 G3.2 -- "what counts as doing this, and what happened" (this
  // ticket's own section 5 hierarchy: title primary, this secondary,
  // lifecycle state tertiary). Deliberately independent of derivedState --
  // see formatGoalActivityCompletion's own doc comment for why numeric
  // progress never infers/overrides lifecycle truth. null for DONE (no
  // line at all, this ticket's own section 6).
  const completionDetail = formatGoalActivityCompletion(activity.completionRequirement, activity.currentValue);
  // Goals V2 Rhythm R4 -- frequency + this-week progress (this ticket's own
  // section 4/9/10/12). null for NONE -- a finite activity's row is
  // completely unaffected (this ticket's own section 42 DB test / section
  // 4 "behaviorally and visually equivalent to the existing finite
  // experience").
  const rhythmFrequencyLabel = activity.rhythm.kind === 'N_PER_WEEK' ? formatGoalActivityRhythmFrequencyLabel(activity.rhythm.targetPerWeek) : null;
  const rhythmWeeklyProgressLabel = formatGoalActivityRhythmWeeklyProgressLabel(activity.rhythm);
  // Multi-Occurrence Rhythm PR 2 -- remaining weekly capacity, shown as
  // its own line so a GoalActivity with more than one coexisting
  // UPCOMING occurrence still communicates how much room is left, never
  // merged into rhythmWeeklyProgressLabel's completed/planned sentence.
  const rhythmRemainingCapacityLabel = formatGoalActivityRhythmRemainingCapacityLabel(activity.rhythm);

  const handleDismiss = async () => {
    if (dismissing) return;
    setDismissing(true);
    setError(null);
    try {
      const res = await fetch(`/api/goals/${activity.goalId}/activities/${activity.id}/dismiss`, { method: 'POST' });
      if (!res.ok) throw new Error('failed');
      onChanged();
    } catch {
      setError('Could not dismiss this. Try again.');
      setDismissing(false);
    }
  };

  return (
    <SurfaceCard style={isDimmed ? { opacity: 0.7 } : selected ? { borderColor: colors.accentBorder } : undefined}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: spacing.md, flexWrap: 'wrap' }}>
        {/* Goals -> Planning Integration V1 PR C -- this ticket's own
            section 3/4: a real selection control now exists, answering
            "What would you like Aura to help you plan?" A checkbox
            renders ONLY for SUGGESTED (PLANNED/COMPLETED never show
            one, matching this ticket's own eligibility rule exactly).
            Selecting is pure local state -- it never mutates
            GoalActivity, never creates a PlannedActivity, never calls
            Day Constructor (this ticket's own section 4). */}
        <label style={{ display: 'flex', alignItems: 'center', gap: spacing.sm, minWidth: 0, cursor: isSelectable ? 'pointer' : 'default' }}>
          {isSelectable && (
            <input
              type="checkbox"
              checked={selected ?? false}
              onChange={onToggleSelect}
              aria-label={`Select "${activity.title}" to plan with Aura`}
              style={{ width: 18, height: 18, flexShrink: 0, accentColor: colors.positive }}
            />
          )}
          <span style={{ ...typography.bodyStrong, minWidth: 0 }}>{activity.title}</span>
        </label>
        {stateLabel && <StatusBadge label={stateLabel} tone={activity.derivedState === 'COMPLETED' ? 'positive' : 'info'} />}
      </div>

      {/* Goals V2 G3.2 -- one compact secondary line (this ticket's own
          section 24: never a per-activity progress bar, never a taller
          row). Readable text, not color/icon/width-only (section 23) --
          reuses the same typography.meta/textSecondary treatment the
          existing target-date line already uses elsewhere on this page. */}
      {completionDetail && <div style={{ ...typography.meta, color: colors.textSecondary, marginTop: 2 }}>{completionDetail}</div>}

      {/* Goals V2 Rhythm R4, extended by Multi-Occurrence Rhythm PR 2 --
          up to three additional secondary lines (frequency, this week's
          factual completed/planned progress, then remaining weekly
          capacity), visually/semantically separate from completionDetail
          above ("10 min" and "5 times a week" are different dimensions,
          never merged into one sentence). All null for NONE, so a finite
          activity's row is unchanged. */}
      {rhythmFrequencyLabel && <div style={{ ...typography.meta, color: colors.textSecondary, marginTop: 2 }}>{rhythmFrequencyLabel}</div>}
      {rhythmWeeklyProgressLabel && <div style={{ ...typography.meta, color: colors.textSecondary, marginTop: 2 }}>{rhythmWeeklyProgressLabel}</div>}
      {rhythmRemainingCapacityLabel && <div style={{ ...typography.meta, color: colors.textSecondary, marginTop: 2 }}>{rhythmRemainingCapacityLabel}</div>}

      {error && (
        <div role="alert" style={{ marginTop: spacing.sm }}>
          <FieldError>{error}</FieldError>
        </div>
      )}

      {/* Goals V2 Rhythm R5 -- this ticket's own section 20 decision: a
          small inline edit affordance, available on EVERY row regardless
          of derivedState (a policy change is independent of any specific
          occurrence's lifecycle -- this ticket's own section 21). This is
          also how a template-created activity (which always starts NONE,
          this ticket's own section 34) reaches an explicit weekly
          frequency -- the SAME control, never a separate creation-time
          wizard. */}
      <div style={{ marginTop: spacing.sm }}>
        <RhythmEditor activity={activity} onSaved={onChanged} />
      </div>

      {/* SUGGESTED is the only state with a Dismiss action. PLANNED/
          COMPLETED render as pure read-only status; there is no
          reschedule/cancel/mark-complete action anywhere on this page
          (this ticket's own section 24/25). */}
      {activity.derivedState === 'SUGGESTED' && (
        <div style={{ marginTop: spacing.sm }}>
          <TextButton onClick={handleDismiss} color={colors.textFaint}>
            {dismissing ? 'Dismissing…' : 'Dismiss'}
          </TextButton>
        </div>
      )}
    </SurfaceCard>
  );
}

// ============================================================
// Goals V2 Rhythm R5 -- RhythmPicker itself now lives in
// ../../../components/RhythmPicker.tsx (shared with CreateGoalModal's own
// template frequency step in GoalsListClient.tsx -- one mechanism, not two,
// this ticket's own section 9). RhythmEditor below is Goal-Detail-specific
// (it PATCHes the one allowed edit endpoint for an EXISTING row), so it
// stays here.
// ============================================================

/**
 * The per-row edit affordance (this ticket's own section 20). Collapsed by
 * default to a single TextButton -- available on every row, regardless of
 * derivedState, since a Rhythm policy change is independent of any
 * specific occurrence (section 21/22/23). Saving PATCHes the one allowed
 * edit endpoint; the server independently re-validates (section 19) --
 * this component's own RhythmPicker validation is client-side convenience
 * only.
 */
function RhythmEditor({ activity, onSaved }: { activity: GoalActivityView; onSaved: () => void }) {
  const [editing, setEditing] = useState(false);
  const initialValue: RhythmPickerValue = activity.rhythm.kind === 'N_PER_WEEK' ? { kind: 'N_PER_WEEK', targetPerWeek: activity.rhythm.targetPerWeek } : { kind: 'NONE' };
  const [value, setValue] = useState<RhythmPickerValue | null>(initialValue);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!editing) {
    return (
      <TextButton onClick={() => { setValue(initialValue); setEditing(true); }} color={colors.info}>
        {activity.rhythm.kind === 'N_PER_WEEK' ? 'Change frequency' : 'Set weekly frequency'}
      </TextButton>
    );
  }

  const handleSave = async () => {
    if (value === null || saving) return;
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`/api/goals/${activity.goalId}/activities/${activity.id}/rhythm`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rhythm: value }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        setError(data?.error ?? 'Could not save this. Try again.');
        setSaving(false);
        return;
      }
      setEditing(false);
      setSaving(false);
      onSaved();
    } catch {
      setError('Could not save this. Try again.');
      setSaving(false);
    }
  };

  return (
    <div>
      <RhythmPicker value={value ?? initialValue} onChange={setValue} idPrefix={`activity-${activity.id}`} />
      {error && (
        <div role="alert" style={{ marginTop: spacing.sm }}>
          <FieldError>{error}</FieldError>
        </div>
      )}
      <div style={{ display: 'flex', gap: spacing.sm, marginTop: spacing.md }}>
        <PrimaryButton onClick={handleSave} disabled={value === null || saving} loading={saving}>
          Save
        </PrimaryButton>
        <SecondaryButton onClick={() => setEditing(false)} disabled={saving}>
          Cancel
        </SecondaryButton>
      </div>
    </div>
  );
}

// ============================================================
// AddActivityControl (this ticket's own section 20/21) -- title-only,
// no catalog/activityId exposure.
// ============================================================

function AddActivityControl({ goalId, onAdded }: { goalId: string; onAdded: () => void }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  // Goals V2 Rhythm R5 -- this ticket's own section 16: default is Once
  // (NONE), so old behavior remains the default; Rhythm configuration is
  // never required to add an activity.
  const [rhythm, setRhythm] = useState<RhythmPickerValue | null>({ kind: 'NONE' });
  const [status, setStatus] = useState<'IDLE' | 'SAVING' | 'ERROR'>('IDLE');
  const [error, setError] = useState<string | null>(null);

  if (!open) {
    return (
      <TextButton onClick={() => setOpen(true)} color={colors.info}>
        + Add activity
      </TextButton>
    );
  }

  const trimmed = title.trim();

  const handleAdd = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!trimmed || rhythm === null || status === 'SAVING') return;
    setStatus('SAVING');
    setError(null);
    try {
      const res = await fetch(`/api/goals/${goalId}/activities`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: trimmed, rhythm }),
      });
      if (!res.ok) throw new Error('failed');
      setTitle('');
      setRhythm({ kind: 'NONE' });
      setOpen(false);
      setStatus('IDLE');
      onAdded();
    } catch {
      setError('Could not add this activity. Try again.');
      setStatus('ERROR');
    }
  };

  return (
    <SurfaceCard>
      <form onSubmit={handleAdd}>
        <FieldLabel htmlFor="add-activity-title" visuallyHidden>
          Activity title
        </FieldLabel>
        <TextInput id="add-activity-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Check final numbers" maxLength={200} disabled={status === 'SAVING'} autoFocus />
        <div style={{ marginTop: spacing.lg }}>
          <RhythmPicker value={rhythm ?? { kind: 'NONE' }} onChange={setRhythm} idPrefix="add-activity" />
        </div>
        {error && (
          <div role="alert" style={{ marginTop: spacing.sm }}>
            <FieldError>{error}</FieldError>
          </div>
        )}
        <div style={{ display: 'flex', gap: spacing.sm, marginTop: spacing.md }}>
          <PrimaryButton type="submit" disabled={!trimmed || rhythm === null} loading={status === 'SAVING'}>
            Add activity
          </PrimaryButton>
          <SecondaryButton onClick={() => { setOpen(false); setError(null); }} disabled={status === 'SAVING'}>
            Cancel
          </SecondaryButton>
        </div>
      </form>
    </SurfaceCard>
  );
}

// ============================================================
// GoalLifecycleActions (this ticket's own section 27/28) -- Archive /
// Delete. Delete relies on the server's own retained-linkage check
// (PR A's deleteGoal) rather than duplicating that logic client-side --
// a 409 is presented with truthful, specific guidance, never a generic
// failure.
// ============================================================

function GoalLifecycleActions({ goal }: { goal: GoalDetailView['goal'] }) {
  const [archiveStatus, setArchiveStatus] = useState<'IDLE' | 'SAVING' | 'ERROR'>('IDLE');
  const [deleteStatus, setDeleteStatus] = useState<'IDLE' | 'CONFIRM' | 'SAVING' | 'ERROR'>('IDLE');
  const [deleteMessage, setDeleteMessage] = useState<string | null>(null);
  const [offerArchiveInstead, setOfferArchiveInstead] = useState(false);

  const handleArchive = async () => {
    setArchiveStatus('SAVING');
    try {
      const res = await fetch(`/api/goals/${goal.id}/archive`, { method: 'POST' });
      if (!res.ok) throw new Error('failed');
      window.location.href = '/goals';
    } catch {
      setArchiveStatus('ERROR');
    }
  };

  const handleDelete = async () => {
    if (deleteStatus === 'IDLE') {
      setDeleteStatus('CONFIRM');
      return;
    }
    setDeleteStatus('SAVING');
    setDeleteMessage(null);
    setOfferArchiveInstead(false);
    try {
      const res = await fetch(`/api/goals/${goal.id}`, { method: 'DELETE' });
      if (res.status === 409) {
        // This ticket's own section 28 -- truthful, specific guidance,
        // never a generic failure message.
        setDeleteMessage('This goal has activities linked to your plan. Archive it instead.');
        setOfferArchiveInstead(true);
        setDeleteStatus('ERROR');
        return;
      }
      if (!res.ok) throw new Error('failed');
      window.location.href = '/goals';
    } catch {
      setDeleteMessage('Could not delete this goal. Try again.');
      setDeleteStatus('ERROR');
    }
  };

  if (goal.status === 'ARCHIVED') {
    // No unarchive endpoint exists in PR A (this ticket's own section
    // 29) -- an archived Goal's lifecycle is read-only here; inventing
    // one is explicitly out of scope.
    return <StatusBadge label="Archived" tone="neutral" />;
  }

  return (
    <div>
      <div style={{ display: 'flex', gap: spacing.sm, flexWrap: 'wrap' }}>
        <SecondaryButton onClick={handleArchive} disabled={archiveStatus === 'SAVING'}>
          {archiveStatus === 'SAVING' ? 'Archiving…' : 'Archive'}
        </SecondaryButton>
        <DestructiveButton onClick={handleDelete} disabled={deleteStatus === 'SAVING'}>
          {deleteStatus === 'CONFIRM' ? 'Confirm delete?' : deleteStatus === 'SAVING' ? 'Deleting…' : 'Delete'}
        </DestructiveButton>
      </div>
      {archiveStatus === 'ERROR' && (
        <div role="alert" style={{ marginTop: spacing.sm }}>
          <FieldError>Could not archive this goal. Try again.</FieldError>
        </div>
      )}
      {deleteMessage && (
        <div role="alert" style={{ marginTop: spacing.sm }}>
          <FieldError>{deleteMessage}</FieldError>
          {offerArchiveInstead && (
            <div style={{ marginTop: spacing.sm }}>
              <SecondaryButton onClick={handleArchive} disabled={archiveStatus === 'SAVING'}>
                {archiveStatus === 'SAVING' ? 'Archiving…' : 'Archive instead'}
              </SecondaryButton>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
