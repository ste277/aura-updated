'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  PageHeader,
  SurfaceCard,
  PrimaryButton,
  SecondaryButton,
  TextButton,
  IconButton,
  DurationChip,
  SegmentedControl,
  TextInput,
  FieldLabel,
  FieldError,
} from '../../components/ui';
import { colors, spacing, radius } from '../../components/theme';
import { DayPlanPreviewController } from '../../components/DayPlanPreviewController';
import { formatIsoClockTime } from '../../lib/dayPlanPreviewPresentation';
import type { ConstructDayPreview } from '../../lib/dayConstructorOrchestrator';
import type { PersistedPlanSummary } from '../../lib/acceptConstructedDay';
import { previewConstructedDay } from '../../lib/dayConstructorPreviewClient';
import type { ShadowReviewPayload } from '../../lib/shadowReviewDelta';
import type { PlanningHorizon } from '../../lib/planningHorizon';
import { PLAN_DAY_QUICK_PICKS, quickPickIcon, type PlanDayQuickPick } from '../../lib/planDayQuickPicks';
import {
  createEmptyIntentRow,
  createInitialIntentRow,
  createIntentRowFromQuickPick,
  createIntentRowFromGoalHandoffItem,
  createIntentRowFromCapture,
  createIntentRowFromAutoGoalSuggestion,
  deriveAvailableAutoGoalSuggestions,
  buildCaptureLinksForAccept,
  MAX_PLAN_DAY_INTENTS,
  isRowUntouched,
  formatIntentRowSummary,
  canSubmitPlanDay,
  canAddAnotherRow,
  buildRequestedIntentsForSubmission,
  buildGoalActivityLinksForAccept,
  presentPlanDayPreviewFailure,
  PLAN_DAY_DURATION_OPTIONS_MINUTES,
  NO_DEADLINE,
  type PlanDayIntentRow,
  type PlanDayDeadlineChoice,
  type PlanDayEntryErrorPresentation,
} from '../../lib/planDayEntry';
import type { GoalActivityHandoffItem, CaptureHandoffItem } from '../../lib/planDayBootstrap';
import type { GoalDemandCandidate } from '../../lib/goalDemandCandidates';
import { encodeGoalDemandIntentId } from '../../lib/goalDemandIntentId';

/**
 * Day Constructor V1 -- PR F2. The user-reachable "Plan my day" entry
 * experience (this ticket's own section 1): Home -> here -> a real
 * `ConstructDayPreview` (via F1's preview API) -> the already-built E3
 * `DayPlanPreviewController`/`DayPlanPreview` -> the already-built E2
 * accept endpoint -> back to Home.
 *
 * This file owns exactly the UI/state-machine glue this ticket's own
 * section 8 describes (ENTRY/SUBMITTING/PREVIEW/PREVIEW_ERROR) -- it never
 * makes a placement/scheduling decision of its own (all row->request
 * mapping, submittability, and FIXED-time date assembly are pure
 * functions in planDayEntry.ts), never calls `/api/plans` or the accept
 * endpoint directly (DayPlanPreviewController owns that entirely, this
 * ticket's own section 33), and never introduces a second preview UI
 * (DayPlanPreview, PR D, unmodified, this ticket's own section 32).
 *
 * Standalone route (`/plan-day`), not another Home `activeTab` (this
 * ticket's own section 5) -- mirrors `/find`'s own precedent of a
 * dedicated route outside the single-page tab system. Unlike `/find`
 * (public/guest), this route requires a real session -- an unauthenticated
 * visitor is sent to `/` (whose own LoginScreen already owns that
 * experience; this file does not duplicate it).
 *
 * Planning-date hardening -- `timezone`/`planningDate` are SERVER props
 * (page.tsx, a Server Component, via planDayBootstrap.ts's own
 * `resolvePlanDayServerProps`), never fetched or computed client-side.
 * `null` means the server itself found no valid session; this file's own
 * job in that case is only to redirect, matching this app's established
 * client-side-navigation convention -- never a second auth check, never
 * an authentication network call of its own (removed: the server already
 * performed the authoritative check before this component ever rendered).
 *
 * Planning Horizon V1 PR P2 -- `horizon`/`availabilityConfigured` are the
 * SAME kind of SERVER prop as `timezone`/`planningDate`: this component
 * reads no clock and performs no civil-date arithmetic of its own to
 * derive Tomorrow. Selecting Today/Tomorrow navigates to
 * `/plan-day?horizon=...`, which re-invokes page.tsx (a Server Component)
 * and re-derives every one of these props fresh -- this file only ever
 * renders whatever the server most recently issued.
 *
 * Plan My Day UX V2 PR U1 -- Quick Picks (planDayQuickPicks.ts) let a
 * user add a common intent without typing; typing remains fully
 * available (`+ Something else`, and every row's own title stays
 * editable regardless of collapsed/expanded state). `expandedRowIds` is
 * PRESENTATION-ONLY UI state -- never added to `PlanDayIntentRow` itself
 * (this ticket's own section 7: no field beyond `activityId` belongs on
 * the domain row model). A row collapses to a one-line summary
 * (`formatIntentRowSummary`, planDayEntry.ts) by default; "Edit"/"Done"
 * toggles disclosure without ever discarding values.
 *
 * Plan My Day UX V2 PR U2 -- `planRevealed` is likewise PRESENTATION-ONLY
 * UI state (this ticket's own section 5): the internal single untouched
 * blank row from U1 is deliberately RETAINED (smallest safe
 * implementation, this ticket's own section 5's own explicit
 * permission) -- U2 only stops RENDERING a plan card/CTA for it until
 * the user has actually taken an action (a Quick Pick or `+ Something
 * else`), both of which set this flag. `addPickerExpanded` toggles the
 * compact `+ Add another` affordance open/closed once a real plan
 * exists -- it reuses the EXACT SAME `QuickPicksAndSomethingElse` block
 * (same data, same handlers) the fresh state already renders, never a
 * second picker implementation (this ticket's own section 18).
 */

type Phase = 'REDIRECTING' | 'ENTRY' | 'SUBMITTING' | 'PREVIEW' | 'PREVIEW_ERROR' | 'SAVED';

export interface PlanDayClientProps {
  timezone: string | null;
  planningDate: string | null;
  horizon: PlanningHorizon | null;
  availabilityConfigured: boolean | null;
  /** Onboarding V1 PR 1 -- Location Trust Foundation. `false` (or `null`
   * for an unauthenticated render) means this plan's timing was computed
   * against a location the user has never explicitly confirmed -- shown
   * as a nonblocking qualifier, never a blocker (this ticket's own
   * explicit requirement). */
  locationConfirmed: boolean | null;
  /** The current (non-birth) city this plan's timing is computed
   * against, so the qualifier can name it. */
  cityName: string | null;
  /** Goals -> Planning Integration V1 PR C (this ticket's own section
   * 6/7/8) -- already ownership/eligibility-resolved server-side
   * (planDayBootstrap.ts's own `resolveGoalActivityHandoff`) from the
   * `?fromGoal=&activities=` URL, BEFORE this component ever mounts.
   * Empty for an ordinary `/plan-day` visit. */
  goalActivities: readonly GoalActivityHandoffItem[];
  /** Quick Capture V1 PR B -- already ownership/eligibility-resolved server-side (`resolveCaptureHandoff`) from `?captures=`. Empty for an ordinary visit. */
  captures: readonly CaptureHandoffItem[];
  /**
   * Goals V2 Candidate A3.2 -- server-produced, presentation-only,
   * immutable bootstrap input (`resolveAutomaticGoalDemand`,
   * planDayBootstrap.ts): the factual set of recurring GoalActivities
   * Aura COULD suggest for this planning date, already deduplicated
   * against the explicit/manual Goal handoff above.
   *
   * Candidate A3.3 -- now surfaced under "Aura suggests" and actionable
   * (see `AutoGoalSuggestionsSection`/`handleIncludeAutoGoalSuggestion`
   * below). Still never read by the `rows` initializer -- an eligible
   * suggestion only ever becomes a row through one explicit user action
   * (this ticket's own core invariant: SURFACED != INCLUDED). Still
   * never passed directly to `buildRequestedIntentsForSubmission`/
   * `buildGoalActivityLinksForAccept` -- only a row that was EXPLICITLY
   * included (and therefore lives in `rows`) ever reaches either.
   */
  autoGoalSuggestions: readonly GoalDemandCandidate[];
}

/**
 * O5 SHADOW ROLLOUT R3 -- the internal-only comparison panel. Rendered ONLY when the server already attached a
 * `shadowReview` (never a client decision -- see `PlanDayClient`'s own `submitPreview`). Deliberately plain and
 * clearly non-customer-facing (this ticket's own section 14): a labelled internal panel, the CHANGED placements
 * only (never a full second day), and one plain-language sentence for why -- no technical vocabulary, no buttons,
 * nothing persisted, nothing sent anywhere (section 15/17: "prefer less machinery").
 */
function ShadowReviewPanel({ review, timezone }: { review: ShadowReviewPayload; timezone: string }) {
  const reasonCopy: Record<ShadowReviewPayload['reason'], string> = {
    WOULD_OTHERWISE_BE_DEFERRED: 'This was the last known opportunity to fit this activity in the planning horizon.',
  };
  const time = (iso?: string) => (iso ? formatIsoClockTime(iso, timezone) : undefined);
  return (
    <SurfaceCard style={{ marginTop: spacing.lg, border: `1px dashed ${colors.borderSubtle}` }}>
      <p style={{ margin: 0, fontSize: 11, fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase', color: colors.textMuted }}>Shadow review — internal</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.md, marginTop: spacing.md }}>
        {review.changedItems.map((item) => (
          <div key={item.intentId}>
            <p style={{ margin: 0, fontSize: 11, fontWeight: 800, letterSpacing: 0.4, textTransform: 'uppercase', color: colors.textMuted }}>{item.kind === 'PROMOTED' ? 'Promoted' : 'Moved'}</p>
            <p style={{ margin: 0, fontSize: 14, fontWeight: 750, color: colors.textPrimary }}>{item.title}</p>
            <p style={{ margin: 0, fontSize: 12, color: colors.textMuted }}>Current plan: {item.baseline.status === 'DEFERRED' ? 'Not scheduled' : `${time(item.baseline.start)}–${time(item.baseline.end)}`}</p>
            <p style={{ margin: 0, fontSize: 12, color: colors.textSecondary }}>Shadow: {time(item.alternative.start)}–{time(item.alternative.end)}</p>
          </div>
        ))}
      </div>
      <p style={{ margin: `${spacing.md}px 0 0`, fontSize: 12, color: colors.textMuted }}>Why Aura considered this: {reasonCopy[review.reason] ?? 'A scheduling trade-off was available.'}</p>
    </SurfaceCard>
  );
}

export function PlanDayClient({ timezone, planningDate, horizon, availabilityConfigured, locationConfirmed, cityName, goalActivities, captures, autoGoalSuggestions }: PlanDayClientProps) {
  const router = useRouter();
  const authenticated = !!timezone && !!planningDate && !!horizon;
  const [phase, setPhase] = useState<Phase>(() => (authenticated ? 'ENTRY' : 'REDIRECTING'));
  // Goals -> Planning Integration V1 PR C -- a Goal handoff seeds one row
  // per resolved, still-eligible GoalActivity (this ticket's own section
  // 9/10); an ordinary visit (empty `goalActivities`) keeps the existing
  // single-blank-row default byte-for-byte. Resolved ONCE, from the
  // initial server-supplied props -- re-navigating within the same
  // session never re-seeds (this file reads no `goalActivities` value
  // again after this initializer).
  const [rows, setRows] = useState<PlanDayIntentRow[]>(() =>
    goalActivities.length + captures.length > 0
      ? [...goalActivities.map((item) => createIntentRowFromGoalHandoffItem(item, planningDate ? encodeGoalDemandIntentId(planningDate, item.id) : null)), ...captures.map(createIntentRowFromCapture)].slice(0, MAX_PLAN_DAY_INTENTS)
      : [createInitialIntentRow()]
  );
  // Plan My Day UX V2 PR U1 -- every row starts collapsed, including a
  // freshly-typed one (this ticket's own section 23: defaults already
  // require no configuration, so there is no product reason to force
  // Edit open merely because a row is new).
  const [expandedRowIds, setExpandedRowIds] = useState<ReadonlySet<string>>(new Set());
  // The one row id (if any) that should receive keyboard focus on the
  // NEXT render -- set by `+ Something else` reusing/creating a blank
  // row (this ticket's own section 16: "focus it"). Quick Picks never
  // set this -- they already fill the title themselves.
  const [pendingFocusRowId, setPendingFocusRowId] = useState<string | null>(null);
  // Plan My Day UX V2 PR U2 -- true once the user has taken a real
  // action (a Quick Pick or `+ Something else`), never derived from row
  // content alone: this is what lets `+ Something else` on a fresh page
  // reveal/focus the SAME still-untouched internal blank row (this
  // ticket's own section 8) without that row already having rendered as
  // a visible card the instant before.
  // Goals -> Planning Integration V1 PR C -- a Goal handoff already
  // seeded real, non-blank rows above; showing the Quick-Picks landing
  // screen on top of them would hide exactly what the user navigated
  // here to review (this ticket's own section 45's own manual flow:
  // "Plan My Day opens -> exactly 2 rows seeded", i.e. immediately
  // visible, not behind a picker).
  const [planRevealed, setPlanRevealed] = useState(goalActivities.length + captures.length > 0);
  // Whether the compact `+ Add another` affordance is currently showing
  // the full Quick Picks grid (this ticket's own section 15/19) -- only
  // meaningful once `planRevealed` is true.
  const [addPickerExpanded, setAddPickerExpanded] = useState(false);
  const [preview, setPreview] = useState<ConstructDayPreview | null>(null);
  // O5 SHADOW ROLLOUT R3 -- present ONLY when the server already decided this response is Preview-eligible AND the
  // real evidence reached APPLY/MATERIALIZABLE/READY/PASS for THIS request (shadowPolicyExecution.ts/shadowEvidence.ts).
  // Never set by anything client-side; a Production response never carries it, so this stays `undefined` there.
  // Ephemeral: never persisted, cleared on discard/refresh exactly like `preview` itself.
  const [shadowReview, setShadowReview] = useState<ShadowReviewPayload | undefined>(undefined);
  const [entryError, setEntryError] = useState<PlanDayEntryErrorPresentation | null>(null);
  // Planning Horizon V1 PR P2 -- true only when a Preview call returned
  // FUTURE_AVAILABILITY_REQUIRED despite bootstrap saying configured
  // (another tab/session reset Availability between page load and
  // Preview -- a real, reachable race, not hypothetical). Reset whenever
  // `horizon` itself changes (below) so switching back to Today never
  // leaves a stale Tomorrow-only block in place.
  const [availabilityRequiredStale, setAvailabilityRequiredStale] = useState(false);

  useEffect(() => {
    if (phase === 'REDIRECTING') window.location.href = '/';
  }, [phase]);

  // A horizon switch is a fresh server render (page.tsx) landing on the
  // SAME mounted component -- React preserves `rows` across it by default
  // (this ticket's own section 13, intentionally relied upon, never
  // reimplemented). Only per-request UI state that could otherwise
  // describe the WRONG day is reset here.
  useEffect(() => {
    setEntryError(null);
    setAvailabilityRequiredStale(false);
    setPhase((current) => (current === 'PREVIEW_ERROR' ? 'ENTRY' : current));
  }, [horizon]);

  // Plan My Day UX V2 PR U1 -- `+ Something else` focus handoff. Uses the
  // SAME deterministic `plan-day-title-${id}` element id every row's own
  // title input already carries (no new ref plumbing).
  useEffect(() => {
    if (!pendingFocusRowId) return;
    document.getElementById(`plan-day-title-${pendingFocusRowId}`)?.focus();
    setPendingFocusRowId(null);
  }, [pendingFocusRowId]);

  // Plan My Day UX V2 PR U2 Release Gate (section 12) -- editing a row's
  // title back to blank, or removing rows, can bring the plan back to
  // "no meaningful content at all" (every remaining row is itself
  // untouched). Left alone, the revealed-state UI (the plan heading,
  // Add-another, CTA) would keep showing with nothing real behind it -- this
  // collapses back to the fresh entry state instead, matching this
  // ticket's own explicit invariant. Depending only on `rows` (never on
  // `planRevealed`/`pendingFocusRowId` themselves) means this only ever
  // reconsiders when row CONTENT changes, and reads pendingFocusRowId as
  // of that same render -- so it never fires in the render pass
  // `handleSomethingElse` reveals a still-untouched row for the user to
  // type into (pendingFocusRowId is set in that exact same batch).
  useEffect(() => {
    if (planRevealed && pendingFocusRowId === null && rows.every(isRowUntouched)) {
      setPlanRevealed(false);
      setAddPickerExpanded(false);
    }
  }, [rows]);

  function updateRow(id: string, patch: Partial<PlanDayIntentRow>) {
    setRows((current) => current.map((row) => (row.id === id ? { ...row, ...patch } : row)));
  }

  function removeRow(id: string) {
    setRows((current) => (current.length > 1 ? current.filter((row) => row.id !== id) : current));
  }

  function toggleRowExpanded(id: string) {
    setExpandedRowIds((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  // Plan My Day UX V2 PR U1 -- Quick Pick tap (this ticket's own sections
  // 12/13/15). ACTIONS, never a toggle/multi-select: every tap adds one
  // intent, duplicates always allowed (section 13). The single existing
  // untouched blank row is reused in place rather than left alongside a
  // second, redundant row (section 15) -- `isRowUntouched` (planDayEntry.ts)
  // defines "blank" by full row state, never title alone. Never focuses
  // the title input -- the pick already supplied it.
  function handleQuickPick(pick: PlanDayQuickPick) {
    setPlanRevealed(true);
    // Plan My Day UX V2 PR U2 (this ticket's own section 19) -- a
    // successful pick always returns the Add-another picker to its
    // collapsed state, whether it was opened from the compact `+ Add
    // another` affordance or this was simply the very first pick on a
    // fresh page (where it is already false, a harmless no-op).
    setAddPickerExpanded(false);
    const newRow = createIntentRowFromQuickPick(pick);
    setRows((current) => {
      if (current.length === 1 && isRowUntouched(current[0])) {
        return [{ ...current[0], title: pick.label, activityId: pick.activityId }];
      }
      if (!canAddAnotherRow(current)) return current;
      return [...current, newRow];
    });
  }

  // "+ Something else" (this ticket's own section 16) -- the SAME
  // blank-row-reuse rule as a Quick Pick, but focuses the title input
  // afterward (typing is the whole point of this action) instead of
  // pre-filling it.
  function handleSomethingElse() {
    // Plan My Day UX V2 PR U2 (this ticket's own section 8/20) -- reveals
    // the plan (and, on a fresh page, the still-untouched internal blank
    // row this reuses) in the SAME render pass the focus is requested in,
    // so the title input already exists in the DOM by the time the
    // pending-focus effect below runs.
    setPlanRevealed(true);
    setAddPickerExpanded(false);
    // Created outside the updater so a double-invoked updater (React
    // StrictMode) can never produce a focus id that differs from the row
    // actually appended.
    const row = createEmptyIntentRow();
    setRows((current) => {
      if (current.length === 1 && isRowUntouched(current[0])) {
        setPendingFocusRowId(current[0].id);
        return current;
      }
      if (!canAddAnotherRow(current)) return current;
      setPendingFocusRowId(row.id);
      return [...current, row];
    });
  }

  // Goals V2 Candidate A3.3 -- "available" suggestions (this ticket's own
  // section 10) are DERIVED from `autoGoalSuggestions` minus whichever
  // GoalActivities already have a row in `rows` -- never a second,
  // separately-maintained "included" Set (deriveAvailableAutoGoalSuggestions,
  // planDayEntry.ts). This is what makes removal (`removeRow`, unmodified)
  // automatically return a suggestion to this list with zero extra code:
  // once a row is gone, its goalActivityId no longer appears in `rows`,
  // so the next render includes it again.
  const availableAutoGoalSuggestions = deriveAvailableAutoGoalSuggestions(autoGoalSuggestions, rows);

  // "Add" (this ticket's own section 5/6/8) -- the ONE moment a factual
  // suggestion becomes a real planning intent. Reuses the EXACT SAME
  // blank-row-reuse/12-row-cap pattern `handleQuickPick` already
  // establishes above -- never a second Preview path, never a
  // Goal-specific submission flow. The row's own `id` is the canonical
  // A2 automatic intent id (`encodeGoalDemandIntentId`, goalDemandIntentId.ts),
  // keyed off `planningDate` -- the SAME server-established civil date
  // this component already receives as a prop, never a client clock read
  // (this ticket's own section 7).
  function handleIncludeAutoGoalSuggestion(suggestion: GoalDemandCandidate) {
    if (!planningDate || !canAddAnotherRow(rows)) return;
    setPlanRevealed(true);
    setAddPickerExpanded(false);
    const intentId = encodeGoalDemandIntentId(planningDate, suggestion.goalActivityId);
    const row = createIntentRowFromAutoGoalSuggestion(suggestion, intentId);
    setRows((current) => {
      if (current.length === 1 && isRowUntouched(current[0])) return [row];
      if (!canAddAnotherRow(current)) return current;
      return [...current, row];
    });
  }

  function selectHorizon(next: PlanningHorizon) {
    if (next === horizon) return;
    router.push(next === 'TOMORROW' ? '/plan-day?horizon=tomorrow' : '/plan-day?horizon=today');
  }

  async function submitPreview() {
    if (!timezone || !planningDate || !horizon || phase === 'SUBMITTING') return;
    setPhase('SUBMITTING');
    setEntryError(null);
    // `buildRequestedIntentsForSubmission` throws only for a past-deadline
    // row that "somehow" bypassed the primary UI gate (`canSubmitPlanDay`'s
    // own `isRowComplete` check, plus each date input's own
    // `min={planningDate}`) -- this ticket's own section 8 fail-closed
    // requirement. This should never actually happen through the real UI;
    // caught defensively rather than left to crash the component.
    let intents;
    try {
      intents = buildRequestedIntentsForSubmission(rows, timezone, planningDate);
    } catch {
      setEntryError({ message: "Something about your day didn't come through correctly.", showEdit: true, actions: [] });
      setPhase('PREVIEW_ERROR');
      return;
    }
    const result = await previewConstructedDay(intents, planningDate);
    if (result.status === 'READY') {
      setPreview(result.preview);
      setShadowReview(result.shadowReview);
      setPhase('PREVIEW');
    } else if (result.status === 'FUTURE_AVAILABILITY_REQUIRED') {
      // Stale-availability race (this ticket's own section 17) -- route
      // to the SAME actionable prerequisite card the bootstrap-known case
      // renders, never a generic error.
      setAvailabilityRequiredStale(true);
      setPhase('ENTRY');
    } else {
      setEntryError(presentPlanDayPreviewFailure(result, horizon));
      setPhase('PREVIEW_ERROR');
    }
  }

  function handleDiscard() {
    // Never saves, never calls acceptance (this ticket's own section 34)
    // -- rows are retained exactly as the user left them.
    setPreview(null);
    setShadowReview(undefined);
    setPhase('ENTRY');
  }

  function handleRefreshRequested() {
    // "Review again": rerun the preview API against the CURRENT reviewed
    // inputs -- never reuse the stale preview, never save automatically
    // (this ticket's own section 35). A genuinely new preview naturally
    // gets its own identity inside DayPlanPreviewController (section 36).
    void submitPreview();
  }

  function handleSaved(_plans: PersistedPlanSummary[]) {
    // TODAY -- unchanged: return to Home; Home's own on-mount effects
    // (loadMyDay/loadGuidance, gated on activeTab==='home'/user?.id)
    // already refresh Plan-backed state on every fresh mount of `/` (this
    // ticket's own section 38, confirmed by direct audit of
    // apps/web/app/page.tsx).
    //
    // Planning Horizon V1 PR P2 -- TOMORROW: Home's own agenda queries are
    // Today-scoped, so a Tomorrow Plan would be silently invisible there.
    // Stay on this page and show an explicit confirmation instead of a
    // redirect that would read as though the save vanished (this ticket's
    // own section 28/29).
    if (horizon === 'TOMORROW') {
      setPhase('SAVED');
      return;
    }
    window.location.href = '/';
  }

  if (phase === 'REDIRECTING') return null;

  if (phase === 'SAVED') {
    return (
      <div style={{ minHeight: '100vh', background: 'var(--as-bg)', color: colors.textPrimary, fontFamily: 'var(--as-font-body)', display: 'flex', justifyContent: 'center', padding: `${spacing.xxxl}px ${spacing.lg}px` }}>
        <div style={{ width: '100%', maxWidth: 480 }}>
          <SurfaceCard>
            <p style={{ margin: 0, fontWeight: 700 }}>Tomorrow is planned.</p>
            <div style={{ marginTop: spacing.md }}>
              <PrimaryButton onClick={() => { window.location.href = '/'; }}>Back to Home</PrimaryButton>
            </div>
          </SurfaceCard>
        </div>
      </div>
    );
  }

  const showAvailabilityPrerequisite = (horizon === 'TOMORROW' && availabilityConfigured === false) || availabilityRequiredStale;
  const atIntentCap = !canAddAnotherRow(rows) && !(rows.length === 1 && isRowUntouched(rows[0]));

  return (
    <div style={{ minHeight: '100vh', background: 'var(--as-bg)', color: colors.textPrimary, fontFamily: 'var(--as-font-body)', display: 'flex', justifyContent: 'center', padding: `${spacing.xxxl}px ${spacing.lg}px` }}>
      <div style={{ width: '100%', maxWidth: 480 }}>
        {phase !== 'PREVIEW' && (
          <div style={{ marginBottom: spacing.lg }}>
            <TextButton onClick={() => { window.location.href = '/'; }} color={colors.textMuted}>
              ← Back to Home
            </TextButton>
          </div>
        )}

        {phase === 'PREVIEW' && preview ? (
          <>
            <DayPlanPreviewController
              preview={preview}
              onDiscard={handleDiscard}
              onSaved={handleSaved}
              onRefreshRequested={handleRefreshRequested}
              goalActivityLinks={buildGoalActivityLinksForAccept(rows, preview.constructedDay.proposedItems)}
              captureLinks={buildCaptureLinksForAccept(rows, preview.constructedDay.proposedItems)}
            />
            {shadowReview && timezone ? <ShadowReviewPanel review={shadowReview} timezone={timezone} /> : null}
          </>
        ) : (
          <>
            <PageHeader title="Plan my day" subtitle={horizon === 'TOMORROW' ? 'What do you want to get done tomorrow?' : 'What do you want to get done today?'} />

            {/* Onboarding V1 PR 1 -- Location Trust Foundation: a targeted,
                low-key qualifier (distinct from the global disclosure
                banner shown app-wide) naming exactly what this plan's
                timing is based on when it has never been explicitly
                confirmed. Nonblocking -- planning continues normally
                either way; this never claims the unconfirmed location is
                verified. */}
            {locationConfirmed === false && cityName && (
              <p style={{ margin: `${spacing.xs}px 0 0`, fontSize: 13, color: colors.textFaint }}>
                Timing based on {cityName} (unconfirmed) ·{' '}
                <TextButton onClick={() => { window.location.href = '/?tab=you'; }} color={colors.textFaint}>
                  Confirm location
                </TextButton>
              </p>
            )}

            <div style={{ marginTop: spacing.xl }}>
              <FieldLabel>When are you planning for?</FieldLabel>
              <SegmentedControl
                options={[
                  { value: 'TODAY', label: 'Today' },
                  { value: 'TOMORROW', label: 'Tomorrow' },
                ]}
                value={horizon ?? 'TODAY'}
                onChange={(value) => selectHorizon(value)}
              />
            </div>

            {showAvailabilityPrerequisite ? (
              <SurfaceCard style={{ marginTop: spacing.lg }}>
                <p style={{ margin: 0, fontWeight: 700 }}>Set your availability first</p>
                <p style={{ marginTop: spacing.xs, marginBottom: 0, color: colors.textSecondary }}>Aura needs to know when you're usually available before it can plan a future day.</p>
                <div style={{ marginTop: spacing.md }}>
                  <PrimaryButton onClick={() => { window.location.href = '/?tab=you'; }}>Set availability</PrimaryButton>
                </div>
              </SurfaceCard>
            ) : (
              <>
                {/* Goals V2 Candidate A3.3 -- "Aura suggests" (this
                    ticket's own section 3/4/19): rendered whenever a real
                    available suggestion exists, independent of
                    planRevealed -- a user with nothing else to plan yet
                    must still be able to see and act on it (this ticket's
                    own section 4: opening Plan My Day never itself
                    selects/includes anything, but it must not HIDE a
                    real suggestion behind an unrelated reveal gate
                    either). Absent entirely when the list is empty (this
                    ticket's own section 19: never an empty container
                    merely to announce nothing exists) -- which already
                    covers the LOAD_FAILED case, since A3.2 degrades that
                    to [] before this component ever sees it (section 20:
                    no new error message here). */}
                {availableAutoGoalSuggestions.length > 0 && (
                  <AutoGoalSuggestionsSection suggestions={availableAutoGoalSuggestions} disabled={phase === 'SUBMITTING' || atIntentCap} onAdd={handleIncludeAutoGoalSuggestion} />
                )}

                {!planRevealed && (
                  <div style={{ marginTop: spacing.lg }}>
                    <FieldLabel>What do you want to accomplish?</FieldLabel>
                    <QuickPicksAndSomethingElse
                      disabled={phase === 'SUBMITTING' || atIntentCap}
                      onQuickPick={handleQuickPick}
                      onSomethingElse={handleSomethingElse}
                    />
                  </div>
                )}

                {planRevealed && (
                  <>
                    <div style={{ marginTop: spacing.xl }}>
                      <FieldLabel>Your plan</FieldLabel>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.md, marginTop: spacing.sm }}>
                      {rows.map((row, index) => (
                        <IntentRowCard
                          key={row.id}
                          row={row}
                          index={index}
                          planningDate={planningDate}
                          horizon={horizon}
                          expanded={expandedRowIds.has(row.id)}
                          canRemove={rows.length > 1}
                          disabled={phase === 'SUBMITTING'}
                          onChange={(patch) => updateRow(row.id, patch)}
                          onRemove={() => removeRow(row.id)}
                          onToggleExpanded={() => toggleRowExpanded(row.id)}
                        />
                      ))}
                    </div>

                    <div style={{ marginTop: spacing.md }}>
                      {addPickerExpanded ? (
                        <QuickPicksAndSomethingElse
                          disabled={phase === 'SUBMITTING' || atIntentCap}
                          onQuickPick={handleQuickPick}
                          onSomethingElse={handleSomethingElse}
                        />
                      ) : (
                        <SecondaryButton onClick={() => setAddPickerExpanded(true)} disabled={phase === 'SUBMITTING' || atIntentCap}>
                          + Add another
                        </SecondaryButton>
                      )}
                    </div>

                    {phase === 'PREVIEW_ERROR' && entryError && (
                      // Plan My Day U3, this ticket's own section 17 --
                      // `role="alert"` so assistive technology announces
                      // the failure as soon as it renders, matching the
                      // standard ARIA live-region pattern for a message
                      // that just appeared (this repo has no prior
                      // convention for this exact case, confirmed by
                      // audit -- introduced here rather than left silent).
                      // Applied on a plain wrapping <div>, not SurfaceCard
                      // itself (no prop passthrough on that shared
                      // primitive, and this ticket does not modify it).
                      <div role="alert" style={{ marginTop: spacing.lg }}>
                        <SurfaceCard>
                          <FieldError>{entryError.message}</FieldError>
                          <div style={{ display: 'flex', gap: spacing.md, marginTop: spacing.md, flexWrap: 'wrap' }}>
                            {/* This ticket's own section 14: `showEdit` is
                                false only for an expired session (401) --
                                editing activity rows cannot fix that, so
                                offering it there would be a real dead end,
                                not merely a redundant one. */}
                            {entryError.showEdit && (
                              <SecondaryButton onClick={() => setPhase('ENTRY')} ariaLabel="Edit activities">
                                Edit activities
                              </SecondaryButton>
                            )}
                            {entryError.actions.includes('CONFIGURE_AVAILABILITY') && (
                              <PrimaryButton onClick={() => { window.location.href = '/?tab=you'; }}>Configure availability</PrimaryButton>
                            )}
                            {entryError.actions.includes('SIGN_IN') && (
                              // This ticket's own section 14 -- `/` is this
                              // app's real, only sign-in surface (its own
                              // LoginScreen, shown to any unauthenticated
                              // visitor), the SAME destination this file's
                              // own "Back to Home" link already uses --
                              // never a claim with no action behind it.
                              <PrimaryButton onClick={() => { window.location.href = '/'; }}>Sign in</PrimaryButton>
                            )}
                            {entryError.actions.includes('RETRY') && (
                              // This ticket's own section 13 -- the ONLY
                              // resubmit action ever rendered during
                              // PREVIEW_ERROR; the bottom "Plan my day" CTA
                              // is hidden below whenever this phase is
                              // active, so a retryable failure never shows
                              // two buttons that do the identical unchanged
                              // resubmission at once.
                              <PrimaryButton onClick={() => void submitPreview()}>Try again</PrimaryButton>
                            )}
                          </div>
                        </SurfaceCard>
                      </div>
                    )}

                    {phase !== 'PREVIEW_ERROR' && (
                      <div style={{ marginTop: spacing.xxl, display: 'flex', justifyContent: 'flex-end' }}>
                        <PrimaryButton onClick={() => void submitPreview()} disabled={!planningDate || !canSubmitPlanDay(rows, planningDate)} loading={phase === 'SUBMITTING'} ariaLabel="Plan my day">
                          Plan my day
                        </PrimaryButton>
                      </div>
                    )}
                  </>
                )}
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}

/**
 * Plan My Day UX V2 PR U1 -- a Quick Pick is an ACTION button (this
 * ticket's own section 12: "not radio buttons, toggles, multi-select
 * state"), deliberately NOT `DurationChip` (ui.tsx): that component
 * always sets `aria-pressed`/a persistent "selected" look, which is the
 * correct semantic for a genuine mutually-exclusive choice (Duration,
 * Flexible/Specific time, the Today/Tomorrow horizon) but would
 * misrepresent a button that can be tapped repeatedly to add several
 * independent intents. Visual language still matches this screen's own
 * existing chip styling for consistency -- only the semantics differ.
 */
function QuickPickButton({ pick, disabled, onClick }: { pick: PlanDayQuickPick; disabled: boolean; onClick: () => void }) {
  const icon = quickPickIcon(pick);
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={`Add ${pick.label}`}
      style={{
        minHeight: 40,
        padding: '0 14px',
        borderRadius: radius.md,
        border: `1px solid ${colors.borderSubtle}`,
        background: 'rgba(15, 23, 42, 0.6)',
        color: colors.textSecondary,
        fontSize: 13,
        fontWeight: 800,
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        flex: '1 1 auto',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
      }}
    >
      {icon && <span aria-hidden="true">{icon}</span>}
      {pick.label}
    </button>
  );
}

/**
 * Plan My Day UX V2 PR U2 -- the ONE picks-plus-Something-else
 * implementation (this ticket's own section 18: "Reuse the same
 * data/actions" -- never a second picker). Rendered from two places in
 * `PlanDayClient` below: the fresh, pre-`planRevealed` entry state, and
 * the expanded `+ Add another` affordance once a plan already exists.
 * Markup/handlers are byte-identical to U1's own original inline block --
 * only extracted, not changed.
 */
function QuickPicksAndSomethingElse({
  disabled,
  onQuickPick,
  onSomethingElse,
}: {
  disabled: boolean;
  onQuickPick: (pick: PlanDayQuickPick) => void;
  onSomethingElse: () => void;
}) {
  return (
    <>
      <p style={{ margin: `${spacing.xs}px 0 ${spacing.sm}px`, fontSize: 12, color: colors.textFaint, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase' }}>Quick picks</p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: spacing.xs }}>
        {PLAN_DAY_QUICK_PICKS.map((pick) => (
          <QuickPickButton key={pick.label} pick={pick} disabled={disabled} onClick={() => onQuickPick(pick)} />
        ))}
      </div>
      <div style={{ marginTop: spacing.sm }}>
        <TextButton onClick={onSomethingElse} color={colors.info} style={{ opacity: disabled ? 0.4 : 1, pointerEvents: disabled ? 'none' : 'auto' }}>
          + Something else
        </TextButton>
      </div>
    </>
  );
}

/**
 * Goals V2 Candidate A3.3 -- "Aura suggests" (this ticket's own section
 * 3/13/21/23). Deliberately lightweight: a label, a list, one action per
 * suggestion -- no progress bars, no weekly counters, no Goal
 * configuration (this ticket's own section 21's own explicit "avoid"
 * list). `suggestions` is rendered in the exact order the caller passes
 * it (A1's own stable, non-semantic order, survived unmodified through
 * A3.2's bootstrap and this component's own derivation) -- this file
 * never ranks/scores/sorts it by anything (this ticket's own section 13).
 */
function AutoGoalSuggestionsSection({ suggestions, disabled, onAdd }: { suggestions: readonly GoalDemandCandidate[]; disabled: boolean; onAdd: (suggestion: GoalDemandCandidate) => void }) {
  return (
    <div style={{ marginTop: spacing.lg }}>
      <FieldLabel>Aura suggests</FieldLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.sm, marginTop: spacing.sm }}>
        {suggestions.map((suggestion) => (
          <AutoGoalSuggestionCard key={suggestion.goalActivityId} suggestion={suggestion} disabled={disabled} onAdd={() => onAdd(suggestion)} />
        ))}
      </div>
    </div>
  );
}

/**
 * Shows activity title, Goal context, and one action. Multi-Occurrence
 * Rhythm PR 2 explicitly supersedes the prior "never remainingThisWeek"
 * instruction this card followed: that earlier decision avoided showing
 * eligibility data as presentation pressure, but this ticket's own
 * section 4 explicitly asks for exactly this weekly copy ("1 of 5
 * planned this week" / "4 sessions remaining"), distinguishing remaining
 * capacity from completed progress -- so a GoalActivity suggested here
 * after one occurrence is already planned reads honestly, rather than as
 * if nothing had been scheduled yet. Still never a streak/urgency/score
 * signal of any kind -- only the same factual completed/planned/
 * remaining counts Goal Detail already shows. Reuses
 * `SurfaceCard`/`SecondaryButton` (this screen's own existing
 * primitives) -- the same flexible `minWidth: 0` text-wrapping pattern
 * `IntentRowCard` already uses for its own title input, so a long
 * activity or Goal title wraps instead of overflowing at the existing
 * mobile breakpoint, and the Add button keeps a real accessible name
 * (never icon/color-only).
 */
function AutoGoalSuggestionCard({ suggestion, disabled, onAdd }: { suggestion: GoalDemandCandidate; disabled: boolean; onAdd: () => void }) {
  const { targetPerWeek, completedThisWeek, committedThisWeek } = suggestion.rhythm;
  const plannedThisWeek = completedThisWeek + committedThisWeek;
  const weeklyProgressLabel = `${plannedThisWeek} of ${targetPerWeek} planned this week`;
  const sessionWord = suggestion.remainingThisWeek === 1 ? 'session' : 'sessions';
  const remainingLabel = `${suggestion.remainingThisWeek} ${sessionWord} remaining`;
  return (
    <SurfaceCard>
      <div style={{ display: 'flex', alignItems: 'center', gap: spacing.sm }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ margin: 0, fontWeight: 700, overflowWrap: 'break-word' }}>{suggestion.title}</p>
          <p style={{ margin: 0, marginTop: 2, fontSize: 13, color: colors.textSecondary, overflowWrap: 'break-word' }}>For: {suggestion.goalTitle}</p>
          <p style={{ margin: 0, marginTop: 2, fontSize: 13, color: colors.textSecondary }}>
            {weeklyProgressLabel} · {remainingLabel}
          </p>
        </div>
        <SecondaryButton onClick={onAdd} disabled={disabled} ariaLabel={`Add ${suggestion.title} (for ${suggestion.goalTitle}) to today's plan`}>
          Add
        </SecondaryButton>
      </div>
    </SurfaceCard>
  );
}

function IntentRowCard({
  row,
  index,
  planningDate,
  horizon,
  expanded,
  canRemove,
  disabled,
  onChange,
  onRemove,
  onToggleExpanded,
}: {
  row: PlanDayIntentRow;
  index: number;
  planningDate: string | null;
  horizon: PlanningHorizon | null;
  expanded: boolean;
  canRemove: boolean;
  disabled: boolean;
  onChange: (patch: Partial<PlanDayIntentRow>) => void;
  onRemove: () => void;
  onToggleExpanded: () => void;
}) {
  const titleId = `plan-day-title-${row.id}`;
  const timeInputId = `plan-day-time-${row.id}`;
  const showIncompleteTimeError = row.title.trim().length > 0 && row.timeMode === 'FIXED' && !row.fixedTime;
  const showPastDeadlineError = row.title.trim().length > 0 && row.deadlineChoice.kind === 'CUSTOM' && !!planningDate && row.deadlineChoice.date < planningDate;

  return (
    <SurfaceCard>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: spacing.sm }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <FieldLabel htmlFor={titleId}>{`Task ${index + 1}`}</FieldLabel>
          <TextInput
            id={titleId}
            value={row.title}
            // Plan My Day UX V2 PR U1 -- any title edit clears a picker-
            // supplied activityId unconditionally (this ticket's own
            // section 6/21/55: visible text and hidden canonical identity
            // must never silently diverge). A no-op when the row never
            // had one. Never a dynamic client-side reclassification --
            // the existing server-side resolver re-classifies the edited
            // title exactly as it would for any typed row.
            onChange={(e) => onChange({ title: e.target.value, activityId: undefined })}
            placeholder="e.g. Finish investor deck"
            disabled={disabled}
            maxLength={200}
          />
        </div>
        {canRemove && (
          <IconButton ariaLabel={`Remove ${row.title.trim() || `task ${index + 1}`}`} onClick={onRemove} style={{ marginTop: 22, width: 36, height: 36 }}>
            ✕
          </IconButton>
        )}
      </div>

      {!expanded ? (
        <div style={{ marginTop: spacing.sm, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: spacing.sm }}>
          <span style={{ fontSize: 12, color: colors.textFaint }}>{formatIntentRowSummary(row, horizon)}</span>
          <SecondaryButton onClick={onToggleExpanded}>Edit</SecondaryButton>
        </div>
      ) : (
        <>
          <div style={{ marginTop: spacing.md }}>
            <FieldLabel>Duration</FieldLabel>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: spacing.xs }}>
              <DurationChip label="Automatic" selected={row.durationMinutes === null} onClick={() => onChange({ durationMinutes: null })} />
              {PLAN_DAY_DURATION_OPTIONS_MINUTES.map((minutes) => (
                <DurationChip key={minutes} label={`${minutes}m`} selected={row.durationMinutes === minutes} onClick={() => onChange({ durationMinutes: minutes })} />
              ))}
            </div>
          </div>

          <div style={{ marginTop: spacing.md }}>
            <FieldLabel>Time</FieldLabel>
            <SegmentedControl
              options={[
                { value: 'FLEXIBLE', label: 'Flexible' },
                { value: 'FIXED', label: 'At a specific time' },
              ]}
              value={row.timeMode}
              onChange={(value) => onChange({ timeMode: value })}
            />
            {row.timeMode === 'FIXED' && (
              <div style={{ marginTop: spacing.sm }}>
                <TextInput id={timeInputId} type="time" value={row.fixedTime ?? ''} onChange={(e) => onChange({ fixedTime: e.target.value || null })} disabled={disabled} hasError={showIncompleteTimeError} />
                {showIncompleteTimeError && <FieldError>Pick a time, or switch back to Flexible.</FieldError>}
              </div>
            )}
          </div>

          <div style={{ marginTop: spacing.md }}>
            <DurationChip label="Important" selected={row.important} onClick={() => onChange({ important: !row.important })} />
          </div>

          <div style={{ marginTop: spacing.md }}>
            <DeadlineControl
              rowId={row.id}
              deadlineChoice={row.deadlineChoice}
              planningDate={planningDate}
              horizon={horizon}
              disabled={disabled}
              hasError={showPastDeadlineError}
              onChange={(deadlineChoice) => onChange({ deadlineChoice })}
            />
            {showPastDeadlineError && <FieldError>Pick today or a later date.</FieldError>}
          </div>

          <div style={{ marginTop: spacing.md, display: 'flex', justifyContent: 'flex-end' }}>
            <SecondaryButton onClick={onToggleExpanded}>Done</SecondaryButton>
          </div>
        </>
      )}
    </SurfaceCard>
  );
}

/**
 * "Deadline" (this ticket's own section 28, renamed from "Due by" --
 * presentation only, `PlanDayDeadlineChoice`/`resolveDeadline` are
 * byte-unchanged) -- progressive disclosure, collapsed by default
 * (`NO_DEADLINE`), never a permanent full date picker per row.
 * Deliberately never worded as if it were a clock time (a row's
 * `important`/deadline facts are always rendered in a visually SEPARATE
 * control from "At a specific time" above, so the two intent facts
 * -- urgency vs. scheduling constraint -- are never presented as one
 * choice).
 *
 * Planning Horizon V1 PR P2 -- `resolveDeadline`'s own `'TODAY'` choice
 * (planDayEntry.ts) has always resolved to `planningDate` verbatim,
 * whatever `planningDate` currently is -- the domain never distinguished
 * "the real calendar today" from "the day being planned." That was
 * invisible while only Today existed; once Tomorrow is selectable, a
 * chip literally labeled "Today" would misleadingly describe a same-day
 * (Tomorrow-relative) deadline. This is a PRESENTATION-ONLY fix
 * (`firstChipLabel` below) -- `resolveDeadline`/`PlanDayDeadlineChoice`'s
 * own `kind: 'TODAY'` value, and the deadline it resolves to, are
 * unchanged.
 */
function DeadlineControl({
  rowId,
  deadlineChoice,
  planningDate,
  horizon,
  disabled,
  hasError,
  onChange,
}: {
  rowId: string;
  deadlineChoice: PlanDayDeadlineChoice;
  planningDate: string | null;
  horizon: PlanningHorizon | null;
  disabled: boolean;
  hasError: boolean;
  onChange: (choice: PlanDayDeadlineChoice) => void;
}) {
  const [expanded, setExpanded] = useState(deadlineChoice.kind !== 'NONE');
  const dateInputId = `plan-day-deadline-${rowId}`;
  const firstChipLabel = horizon === 'TOMORROW' ? 'Same day' : 'Today';

  if (!expanded) {
    return (
      <TextButton onClick={() => setExpanded(true)} color={colors.textMuted} style={{ opacity: disabled ? 0.4 : 1, pointerEvents: disabled ? 'none' : 'auto' }}>
        + Deadline
      </TextButton>
    );
  }

  return (
    <div>
      <FieldLabel>Deadline</FieldLabel>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: spacing.xs }}>
        <DurationChip label={firstChipLabel} selected={deadlineChoice.kind === 'TODAY'} onClick={() => onChange({ kind: 'TODAY' })} />
        <DurationChip label="Tomorrow" selected={deadlineChoice.kind === 'TOMORROW'} onClick={() => onChange({ kind: 'TOMORROW' })} />
        <DurationChip label="This week" selected={deadlineChoice.kind === 'THIS_WEEK'} onClick={() => onChange({ kind: 'THIS_WEEK' })} />
        <DurationChip label="Pick date" selected={deadlineChoice.kind === 'CUSTOM'} onClick={() => onChange({ kind: 'CUSTOM', date: planningDate ?? '' })} />
      </div>
      {deadlineChoice.kind === 'CUSTOM' && (
        <div style={{ marginTop: spacing.sm }}>
          <TextInput
            id={dateInputId}
            type="date"
            value={deadlineChoice.date}
            min={planningDate ?? undefined}
            onChange={(e) => onChange({ kind: 'CUSTOM', date: e.target.value })}
            disabled={disabled}
            hasError={hasError}
          />
        </div>
      )}
      {deadlineChoice.kind !== 'NONE' && (
        <div style={{ marginTop: spacing.xs }}>
          <TextButton
            onClick={() => {
              onChange(NO_DEADLINE);
              setExpanded(false);
            }}
            color={colors.textMuted}
            style={{ opacity: disabled ? 0.4 : 1, pointerEvents: disabled ? 'none' : 'auto' }}
          >
            Clear
          </TextButton>
        </div>
      )}
    </div>
  );
}
