/**
 * Day Constructor V1 -- PR D presentation adapters.
 *
 * PRESENTATION ONLY (this ticket's own section 1/5): every function here
 * turns a `ConstructDayPreview` (PR C's own stable contract) into plain
 * text/labels for the UI. Nothing here re-runs timing search, recomputes
 * capacity, re-ranks intents, re-evaluates blockers, or changes a
 * deferred reason -- the UI renders constructor truth verbatim; this
 * file only decides how to WORD that truth.
 *
 * Kept separate from `DayPlanPreview.tsx` so every mapping decision here
 * is a plain, directly-testable function, matching this repository's own
 * established convention (e.g. `dayConstructorOrchestrator.ts`'s own
 * `isActivePlanBlocker`/`mapTimingLabelToPlacementFit`) of keeping
 * presentation-adapter logic out of JSX.
 */

import type { CapacityState } from './dayCapacity';
import type { ConstructDayPreview, ConstructDayWarning, ResolvedIntentSummary } from './dayConstructorOrchestrator';
import type { PlacementDeferralReason, PlacementTimingFit, ProposedItem } from './dayConstructor';
import type { DayIntentFlexibility } from './dayIntent';
import type { MuhurtaActivityFamily } from '../../../packages/muhurta/src/muhurtaEngine';
import { addDaysToDateStr } from './timezone';

// ============================================================
// Capacity state (this ticket's own section 7/8). No independent capacity
// calculation -- every caller passes through `constructedDay.requestedCapacity.capacityState`
// (or `.proposedCapacity.capacityState`) verbatim; this function only
// supplies the copy for whichever `CapacityState` it is handed.
//
// PR D uses `requestedCapacity` (never `proposedCapacity`) for the
// header: `requestedCapacity` is "how full today would be if everything
// got placed" (dayConstructor.ts's own doc comment), which is the only
// one of the two snapshots that can ever read `OVERLOADED` -- exactly
// this ticket's own section 20 meaning ("not everything fits"). A day
// where everything already got placed can never be reported as
// overloaded by construction (`proposedCapacity` only ever sums minutes
// that were actually placed), so it would never surface this state at
// all.
// ============================================================

export interface CapacityPresentation {
  label: string;
  description: string;
}

export function presentCapacityState(state: CapacityState): CapacityPresentation {
  switch (state) {
    case 'OPEN':
      return { label: 'Open day', description: "There's still plenty of room in your day." };
    case 'BALANCED':
      return { label: 'Balanced day', description: 'Your priorities fit with some breathing room.' };
    case 'BUSY':
      return { label: 'Busy day', description: 'Most of your available time is accounted for.' };
    case 'OVERLOADED':
      return { label: 'Overloaded day', description: 'Not everything fits in the time available.' };
  }
}

// ============================================================
// Target date label (this ticket's own section 7: "Target date").
// Reproduces -- never imports, since it is a private, unexported helper
// -- `ForwardPlannerView.tsx`'s own `formatLocalDateLabel` formula
// verbatim: a `targetDate` dateStr (YYYY-MM-DD) is a local CALENDAR date,
// never an instant, so it is parsed as UTC noon-anchored to avoid any
// timezone-shift-induced off-by-one day.
// ============================================================

export function formatTargetDateLabel(targetDate: string): string {
  const [year, month, day] = targetDate.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'UTC' });
}

// ============================================================
// Item time formatting -- reproduces HomeTimeline.tsx's own private
// `formatItemTime` formula verbatim.
// ============================================================

export function formatItemClockTime(date: Date, timezone: string): string {
  return date.toLocaleTimeString('en-US', { timeZone: timezone, hour: 'numeric', minute: '2-digit' });
}

/** O5 SHADOW ROLLOUT R3 -- the SAME formula, over an already-explicit ISO instant (shadowReviewDelta.ts's own
 * `ShadowReviewSlot.start`/`.end`) rather than a `Date` the caller already holds. Exists so `PlanDayClient.tsx`
 * (planDayWiring.test.ts's own guard: no `new Date(` of its own) never needs to parse an instant itself. */
export function formatIsoClockTime(iso: string, timezone: string): string {
  return formatItemClockTime(new Date(iso), timezone);
}

// ============================================================
// Placement provenance (this ticket's own section 9/17/18) -- the
// critical FIXED-vs-Aura-selected distinction, in plain language, never
// "Fixed constraint" and never a superlative claim about either time
// (this ticket's own section 19).
// ============================================================

export function presentPlacementSource(source: ProposedItem['placementSource']): string {
  return source === 'FIXED_CONSTRAINT' ? 'You chose this time' : 'Aura selected this time';
}

// Neither string above claims a superlative -- PR B's placement is
// deterministic greedy, not a global optimizer, so copy anywhere in this
// file must never assert a placed time is the single best one achievable.

// ============================================================
// Timing fit (this ticket's own section 16). Reuses the app's OWN
// already-established terminology for this exact tier set --
// `homeTimelineComposer.ts`'s `mapTimingLabelToHomeStatus` /
// `HomeTimeline.tsx`'s own `statusTone` already render precisely
// 'Best'/'Good'/'Workable'/'Caution' via `StatusBadge` elsewhere in the
// product (Home's own timeline rows) -- reproduced here verbatim rather
// than inventing new wording ("Strong fit"/"Good fit"/etc.), since real
// existing product language already exists and applies one-to-one.
// ============================================================

export type TimingFitTone = 'positive' | 'info' | 'neutral' | 'caution';

export function presentTimingFit(fit: PlacementTimingFit): { label: string; tone: TimingFitTone } {
  switch (fit) {
    case 'BEST':
      return { label: 'Best', tone: 'positive' };
    case 'GOOD':
      return { label: 'Good', tone: 'info' };
    case 'WORKABLE':
      return { label: 'Workable', tone: 'neutral' };
    case 'CAUTION':
      return { label: 'Caution', tone: 'caution' };
  }
}

// ============================================================
// Deferred reason mapping (this ticket's own section 13; U3's own
// section 3 amendment below) -- ONE explicit adapter, covering every
// real `PlacementDeferralReason` value (not just the ticket's own
// illustrative subset), never exposing a raw enum string, never
// inventing causal detail the diagnostic doesn't state.
//
// FLEXIBLE VS FIXED (Plan My Day U3, this ticket's own section 3) --
// `OUTSIDE_CONSTRUCTION_WINDOW` is the ONLY `PlacementDeferralReason`
// value reachable by BOTH a FIXED and a FLEXIBLE intent (confirmed by
// direct audit of `placeFixedIntent`/`placeOneIntent`, dayConstructor.ts:
// every OTHER FIXED-only rejection maps to `FIXED_WINDOW_INVALID`/
// `FIXED_WINDOW_CONFLICT` instead, never the generic reasons a FLEXIBLE
// intent's own multi-candidate diagnosis uses). For a FIXED intent, "the
// requested time" is literally true -- the user typed/picked that exact
// clock time (`resolveFixedStart`, planDayEntry.ts). For a FLEXIBLE
// intent, NO time was ever requested -- `constructDay` generated and
// rejected candidate times of its own choosing (this file's own module
// doc comment: presentation renders constructor truth verbatim, and the
// truth here is that timing search, not the user, picked and lost every
// candidate it tried within the part of the day being planned). Saying
// "requested time" for a FLEXIBLE intent was therefore a genuine
// truthfulness bug, not a wording preference -- fixed here, never
// upstream (this file still never re-evaluates a deferred reason).
// ============================================================

export function presentDeferralReason(reason: PlacementDeferralReason, flexibility: DayIntentFlexibility): string {
  switch (reason) {
    case 'DURATION_UNKNOWN':
      return "Aura doesn't know how much time this needs yet.";
    case 'NO_CANDIDATES':
      return "Aura couldn't find a suitable time.";
    case 'NO_FEASIBLE_WINDOW':
      return "There isn't enough open time that fits this activity.";
    case 'OUTSIDE_CONSTRUCTION_WINDOW':
      return flexibility === 'FIXED'
        ? "The requested time is outside the part of the day you're planning."
        : "Aura couldn't find a suitable time for this activity within the part of the day being planned.";
    case 'FIXED_WINDOW_CONFLICT':
      return 'That time conflicts with something already in your day.';
    case 'FIXED_WINDOW_INVALID':
      return "The fixed time couldn't be used.";
    case 'BLOCKED_BY_COMMITMENT':
      return 'That time is already taken by something on your schedule.';
    case 'CONFLICTS_WITH_PROPOSED_ITEM':
      return 'That time conflicts with another activity Aura placed today.';
  }
}

// ============================================================
// Warnings (this ticket's own section 14) -- secondary, per-intent
// context, never a raw warning code, never duplicating the deferred
// explanation. `NO_TIMING_CANDIDATES_FOUND` is deliberately DROPPED
// here (not mapped to any text): a deferred `NO_CANDIDATES` item already
// carries this exact fact via `presentDeferralReason` above, so showing
// it again as a separate warning would be duplicate noise for the same
// event (this ticket's own explicit instruction).
// ============================================================

/**
 * DR4-A -- `kind` exists so a renderer can visually distinguish a Daily
 * Rhythm personal-fit explanation from every other kind of warning text
 * (a duration estimate, an activity-interpretation note) WITHOUT the
 * renderer re-deriving that distinction from a raw warning code itself
 * (this file's own module doc comment: presentation decisions belong
 * here, not in JSX). `'DAILY_RHYTHM'` covers exactly the three
 * DAILY_RHYTHM_* codes below; every other presented warning is
 * `'GENERAL'`. Purely a presentation tag -- does not change which
 * warnings are produced, their text, or their ordering.
 */
export type WarningPresentationKind = 'DAILY_RHYTHM' | 'GENERAL';

export interface WarningPresentation {
  intentId: string;
  text: string;
  kind: WarningPresentationKind;
}

function humanizeActivityFamily(family: MuhurtaActivityFamily): string {
  const lower = family.toLowerCase().replace(/_/g, ' ');
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}

/**
 * `resolvedIntents` is required so `ACTIVITY_RESOLVED_TO_COARSE_FAMILY`
 * can look up the actual resolved `activityFamily` (this ticket's own
 * section 14: "if family is available") -- `ConstructDayWarning` itself
 * carries only `{ intentId, code }`, never the family. When resolution
 * genuinely produced no family (should not happen for this specific
 * code in practice, since `dayConstructorOrchestrator.ts`'s own coarse-
 * family fallback always sets one, but this file never assumes an
 * upstream invariant it cannot verify), the warning is silently
 * dropped rather than shown with an invented/vague message.
 */
export function presentWarnings(warnings: readonly ConstructDayWarning[], resolvedIntents: readonly ResolvedIntentSummary[]): WarningPresentation[] {
  const familyByIntentId = new Map(resolvedIntents.map((resolved) => [resolved.requestedIntentId, resolved.dayIntent.activityFamily] as const));
  const presentations: WarningPresentation[] = [];
  for (const warning of warnings) {
    if (warning.code === 'NO_TIMING_CANDIDATES_FOUND') continue;
    if (warning.code === 'ACTIVITY_RESOLVED_TO_COARSE_FAMILY') {
      const family = familyByIntentId.get(warning.intentId);
      if (family) presentations.push({ intentId: warning.intentId, text: `Aura interpreted this as ${humanizeActivityFamily(family)}`, kind: 'GENERAL' });
      continue;
    }
    if (warning.code === 'DURATION_FROM_GENERIC_FALLBACK') {
      presentations.push({ intentId: warning.intentId, text: 'Estimated duration', kind: 'GENERAL' });
      continue;
    }
    // Daily Rhythm V1 PR DR2 -- plain, non-technical copy only; never
    // exposes internal scoring/ranking terminology, never claims a
    // window is astrologically favorable (that claim belongs solely to
    // the existing Panchang/Muhurta-derived text elsewhere in this
    // file, untouched by DR2).
    // Daily Rhythm V1 PR DR3 -- wording locked to this ticket's own
    // exact phrasing (section 3). The fallback text deliberately says
    // "was found" (past tense, scoped to the search actually run), never
    // "was available" / "exists" -- DR3's own explicit instruction: "Do
    // not claim that an outside-work option was unavailable unless the
    // bounded search has sufficient evidence to support that statement."
    // This text is generated only from explainDailyRhythmPlacement's own
    // result (dailyRhythmScheduling.ts), which is itself derived from
    // the exact candidate batch DR3's own expanded search returned --
    // never a claim about candidates the search never examined.
    if (warning.code === 'DAILY_RHYTHM_PERSONAL_OUTSIDE_WORK_HOURS') {
      presentations.push({ intentId: warning.intentId, text: 'Fits your preferred personal time.', kind: 'DAILY_RHYTHM' });
      continue;
    }
    if (warning.code === 'DAILY_RHYTHM_PERSONAL_DURING_WORK_HOURS_FALLBACK') {
      presentations.push({ intentId: warning.intentId, text: 'No suitable time outside your working hours was found.', kind: 'DAILY_RHYTHM' });
      continue;
    }
    if (warning.code === 'DAILY_RHYTHM_FLEXIBLE_BREAK_DURING_WORK_HOURS') {
      presentations.push({ intentId: warning.intentId, text: 'Short break that fits into your workday', kind: 'DAILY_RHYTHM' });
      continue;
    }
  }
  return presentations;
}

/** Groups whole warning presentations (text AND kind, DR4-A) by
 * `intentId` so a row can look up its own warnings by a single map
 * lookup instead of filtering the full list, and still tell a
 * `'DAILY_RHYTHM'` explanation apart from a `'GENERAL'` one once grouped. */
export function groupWarningsByIntentId(presentations: readonly WarningPresentation[]): Record<string, WarningPresentation[]> {
  const grouped: Record<string, WarningPresentation[]> = {};
  for (const presentation of presentations) {
    (grouped[presentation.intentId] ??= []).push(presentation);
  }
  return grouped;
}

// ============================================================
// Chronology (this ticket's own section 11) -- DISPLAY ordering only.
// Never mutates the input array; never implies this order is
// `constructDay`'s own priority/placement order.
// ============================================================

export function sortProposedItemsForDisplay(items: readonly ProposedItem[]): ProposedItem[] {
  return [...items].sort((a, b) => a.start.getTime() - b.start.getTime());
}

// ============================================================
// Deferred-item title lookup (this ticket's own section 10/12) --
// `DeferredItem` itself carries only `{ intentId, primaryReason,
// diagnostics }`, never a title; the title is recovered from
// `resolvedIntents`, which every requested intent (placed or deferred)
// always has an entry in.
// ============================================================

export function titleForIntentId(resolvedIntents: readonly ResolvedIntentSummary[], intentId: string): string {
  return resolvedIntents.find((resolved) => resolved.requestedIntentId === intentId)?.dayIntent.title ?? 'Untitled';
}

/** Plan My Day U3 -- the SAME lookup convention `titleForIntentId` above
 * already establishes, needed so `presentDeferralReason`'s own FLEXIBLE-
 * vs-FIXED branch (this file's own section above) can be driven by the
 * real resolved intent rather than a caller guessing. Defaults to
 * `'FLEXIBLE'` for an unknown intentId -- the SAME safe default
 * `buildDayIntent` itself uses (`DEFAULT_FLEXIBILITY`, dayIntent.ts) --
 * never `'FIXED'`, which would fabricate a "you requested this time"
 * claim for an intent this file cannot actually verify chose one. */
export function flexibilityForIntentId(resolvedIntents: readonly ResolvedIntentSummary[], intentId: string): DayIntentFlexibility {
  return resolvedIntents.find((resolved) => resolved.requestedIntentId === intentId)?.dayIntent.flexibility ?? 'FLEXIBLE';
}

// ============================================================
// Deferred-item provenance (Intent Fidelity V1 PR G3/G4, implementation
// ticket's own sections 24-29) -- MINIMAL, factual-only. Only two facts
// the user can actually supply through Plan My Day today: `important`
// (-> domain `importance: 'HIGH'`) and `deadline`. Never rendered for a
// PLACED item (this ticket's own section 29) -- callers must only ever
// invoke this for a deferred item's own row.
//
// `dayIntent.importance === 'HIGH'` is safe to present as "Important"
// WITHOUT a separate explicit/defaulted flag (this ticket's own section
// 27's own question) because `buildDayIntent`'s `DEFAULT_IMPORTANCE`
// (dayIntent.ts) is `'MEDIUM'`, never `'HIGH'` -- structurally, for
// EVERY caller, not merely by Plan My Day's own current convention --
// so `'HIGH'` can only ever mean a caller explicitly supplied it. No new
// domain/orchestrator plumbing is required (this ticket's own section
// 27's "if the preview currently drops the required facts, add the
// smallest necessary plumbing" -- it does not: `ResolvedIntentSummary.
// dayIntent.importance`/`.deadline` already carry both facts verbatim).
// Similarly, `deadline` itself is sufficient provenance (this ticket's
// own section 28) -- no new enum.
// ============================================================

function formatCompactDeadlineDateLabel(deadline: string): string {
  const [year, month, day] = deadline.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
}

/** Purely factual, never an urgency judgment (this ticket's own section
 * 26: "do not invent urgency language") -- a deadline before
 * `planningDate` (which Plan My Day's own client-mapping guard should
 * never actually produce) still renders as a plain compact date, never
 * as "Overdue" or similar invented language. */
function presentDeadlineProvenanceLabel(deadline: string, planningDate: string): string {
  if (deadline === planningDate) return 'Due today';
  if (deadline === addDaysToDateStr(planningDate, 1)) return 'Due tomorrow';
  return `Due ${formatCompactDeadlineDateLabel(deadline)}`;
}

/**
 * Looks up the ONE deferred item's own `DayIntent` (via `resolvedIntents`,
 * the same lookup convention `titleForIntentId` above already
 * establishes) and returns plain factual labels -- `[]` when neither
 * fact is present, so a default row (MEDIUM, no deadline) renders no
 * provenance at all (this ticket's own section 25/43: never present
 * "Normal"/"MEDIUM" as if it were a stated choice).
 */
export function presentDeferredProvenance(resolvedIntents: readonly ResolvedIntentSummary[], intentId: string, planningDate: string): string[] {
  const dayIntent = resolvedIntents.find((resolved) => resolved.requestedIntentId === intentId)?.dayIntent;
  if (!dayIntent) return [];
  const texts: string[] = [];
  if (dayIntent.importance === 'HIGH') texts.push('Important');
  if (dayIntent.deadline !== undefined) texts.push(presentDeadlineProvenanceLabel(dayIntent.deadline, planningDate));
  return texts;
}

// ============================================================
// Proposal summary state (this ticket's own section 29/30) -- a pure
// classification of the three shapes a `ConstructDayPreview` can take,
// so `DayPlanPreview.tsx` never has to re-derive this branching itself.
// ============================================================

export type ProposalSummaryState = 'NOTHING_REQUESTED' | 'ALL_DEFERRED' | 'HAS_ITEMS';

export function classifyProposalSummary(preview: Pick<ConstructDayPreview, 'resolvedIntents' | 'constructedDay'>): ProposalSummaryState {
  if (preview.resolvedIntents.length === 0) return 'NOTHING_REQUESTED';
  if (preview.constructedDay.proposedItems.length === 0) return 'ALL_DEFERRED';
  return 'HAS_ITEMS';
}
