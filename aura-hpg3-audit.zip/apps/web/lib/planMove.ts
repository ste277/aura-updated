/**
 * Daily Experience V1 PR D2 -- Move: "the user still intends to perform this
 * committed activity, but at a different time."
 *
 *   A (UPCOMING) --Move--> A (MOVED) ---> B (UPCOMING, rescheduledFromPlanId = A)
 *
 * A stays as history; B is a NEW commitment; a Capture/GoalActivity that was
 * linked to A is repointed to B in the SAME transaction so it never leaves
 * PLANNED. One domain operation for every UPCOMING plan regardless of how it is
 * presented in time (future, imminent, active, derived-MISSED): eligibility is
 * the persisted status only.
 *
 * Concurrency: the per-user advisory lock is the SAME key Day Constructor
 * acceptance takes (so conflict checks serialize against acceptance), then
 * `SELECT ... FOR UPDATE` on A (the row lock logPlannedActivity holds), then a
 * conditional UPCOMING -> MOVED update. UNIQUE("rescheduledFromPlanId") is the
 * database backstop against a forked successor.
 */
import { randomUUID } from 'crypto';
import { beginTransaction, type PlannedActivity } from './db';
import { isActivePlanBlocker } from './dayConstructorOrchestrator';
import { parseSchedulingMode } from './plannedActivitySchedulingMode';
import { buildGoogleCalendarUrl } from '../../../packages/recommendation/src/dailyAssistant';
import { normalizeGoalActivityRhythm, deriveGoalActivityRhythmContributionWithEvidence, localCalendarWeekStart, resolveOccurrenceLocalDateOrNull, type GoalActivityRhythmOccurrenceFact, type PlannedActivityStatusForRhythm } from './goalActivityRhythm';
import { evaluateNewOccurrenceEligibility } from './goalActivityOccurrenceCapacity';
import { getDatePartsInTimezone } from './timezone';

export type MovePlanErrorCode =
  | 'NOT_FOUND'
  | 'INVALID_STATE'
  | 'ALREADY_MOVED'
  | 'INVALID_DESTINATION'
  | 'CONFLICT'
  | 'HAS_LINKED_MOMENT'
  | 'CAPACITY_EXCEEDED';

export class MovePlanError extends Error {
  constructor(public readonly code: MovePlanErrorCode, message: string) {
    super(message);
    this.name = 'MovePlanError';
  }
}

export interface MovePlanInput {
  newStartAt: Date;
}

export interface MovePlanResult {
  from: PlannedActivity;
  to: PlannedActivity;
}

const MINUTE_MS = 60_000;

/** Pure destination rules. `now` is the authoritative server instant. */
export function validateMoveDestination(plan: Pick<PlannedActivity, 'plannedStartAt' | 'durationMinutes'>, newStartAt: Date, now: Date): { newStartAt: Date; newEndAt: Date } {
  if (!(newStartAt instanceof Date) || !Number.isFinite(newStartAt.getTime())) {
    throw new MovePlanError('INVALID_DESTINATION', 'newStartAt must be a valid instant.');
  }
  if (newStartAt.getTime() % MINUTE_MS !== 0) {
    throw new MovePlanError('INVALID_DESTINATION', 'newStartAt must be on a whole-minute boundary.');
  }
  if (newStartAt.getTime() <= now.getTime()) {
    throw new MovePlanError('INVALID_DESTINATION', 'newStartAt must be in the future.');
  }
  if (newStartAt.getTime() === new Date(plan.plannedStartAt).getTime()) {
    throw new MovePlanError('INVALID_DESTINATION', 'newStartAt must differ from the current start.');
  }
  return { newStartAt, newEndAt: new Date(newStartAt.getTime() + plan.durationMinutes * MINUTE_MS) };
}

/** Same [start, end) overlap test used throughout the Constructor and acceptance. */
function overlaps(aStart: Date, aEnd: Date, bStart: Date, bEnd: Date): boolean {
  return aStart.getTime() < bEnd.getTime() && bStart.getTime() < aEnd.getTime();
}

export async function movePlannedActivity(userId: string, planId: string, input: MovePlanInput): Promise<MovePlanResult> {
  const client = await beginTransaction();
  try {
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`day-constructor-accept:${userId}`]);

    const aRes = await client.query(`SELECT * FROM "PlannedActivity" WHERE id = $1 AND "userId" = $2 FOR UPDATE`, [planId, userId]);
    if (aRes.rows.length === 0) throw new MovePlanError('NOT_FOUND', 'Plan not found.');
    const a: PlannedActivity = aRes.rows[0];

    if (a.status === 'MOVED') {
      const succ = await client.query(`SELECT * FROM "PlannedActivity" WHERE "rescheduledFromPlanId" = $1 AND "userId" = $2`, [planId, userId]);
      const b: PlannedActivity | undefined = succ.rows[0];
      if (b && input.newStartAt instanceof Date && new Date(b.plannedStartAt).getTime() === input.newStartAt.getTime()) {
        await client.query('COMMIT');
        return { from: a, to: b };
      }
      throw new MovePlanError('ALREADY_MOVED', 'Plan was already moved.');
    }
    if (a.status !== 'UPCOMING') throw new MovePlanError('INVALID_STATE', 'Plan cannot be moved.');

    const moment = await client.query(
      `SELECT 1 FROM "AuraMoment" WHERE "plannedActivityId" = $1 AND status = 'ACTIVE' AND ("expiresAt" IS NULL OR "expiresAt" > now()) LIMIT 1`,
      [planId]
    );
    if (moment.rows.length > 0) throw new MovePlanError('HAS_LINKED_MOMENT', 'This plan has an active shared moment; reschedule it from the shared moment.');

    const now: Date = (await client.query('SELECT clock_timestamp() AS now')).rows[0].now;
    const { newStartAt, newEndAt } = validateMoveDestination(a, input.newStartAt, now);

    // Conflict: any OTHER plan whose [start, end) overlaps the destination and that the existing blocker rule says
    // still blocks. A itself is excluded. (Shared with recomposition acceptance.)
    const conflict = await findBlockingPlanForRange(client, userId, [planId], newStartAt, newEndAt, now);
    if (conflict) throw new MovePlanError('CONFLICT', 'That time overlaps another plan.');

    const result = await applyMoveWrites(client, userId, a, newStartAt, newEndAt);

    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

// ---------------------------------------------------------------------------
// Shared internals (used by movePlannedActivity above AND by recomposition acceptance, F3). Declared after the
// public operation so the single-plan flow reads top to bottom; hoisting makes the order irrelevant at runtime.
// ---------------------------------------------------------------------------

/**
 * SHARED with recomposition acceptance (F3): does any plan OTHER than `excludePlanIds` that the existing blocker rule
 * says still blocks overlap `[newStartAt, newEndAt)`? One definition of Move collision semantics -- `[start, end)`
 * (touching is allowed), `isActivePlanBlocker` lifecycle rules, every plan of the user regardless of day.
 */
export async function findBlockingPlanForRange(
  client: { query: (text: string, params?: unknown[]) => Promise<{ rows: any[] }> },
  userId: string,
  excludePlanIds: readonly string[],
  newStartAt: Date,
  newEndAt: Date,
  now: Date
): Promise<boolean> {
  const candidates = await client.query(
    `SELECT "plannedStartAt", "plannedEndAt", status FROM "PlannedActivity"
     WHERE "userId" = $1 AND id <> ALL($2::text[]) AND "plannedStartAt" < $4 AND "plannedEndAt" > $3`,
    [userId, [...excludePlanIds], newStartAt, newEndAt]
  );
  return candidates.rows.some(
    (row) =>
      isActivePlanBlocker({ start: new Date(row.plannedStartAt), end: new Date(row.plannedEndAt), status: row.status }, now) &&
      overlaps(newStartAt, newEndAt, new Date(row.plannedStartAt), new Date(row.plannedEndAt))
  );
}

/**
 * Multi-Occurrence Rhythm -- CROSS-WEEK CAPACITY ENFORCEMENT, shared by
 * BOTH Move paths (manual Move and Recomposition acceptance both call
 * `applyMoveWrites`, below, which calls this FIRST, inside the SAME
 * transaction and per-user advisory lock both callers already hold --
 * there is exactly one enforcement point, not two independently
 * maintained ones).
 *
 * A Move repoints an EXISTING occurrence's association; it never creates
 * a new one (the hard "no new occurrence on Move" invariant, unchanged).
 * But repointing to a new instant can move that occurrence into a
 * DIFFERENT local calendar week -- and until this fix, nothing ever
 * re-checked whether the DESTINATION week had room for it under the
 * GoalActivity's own N_PER_WEEK target. This function closes that gap:
 * if `a` (the plan being moved) is linked to an N_PER_WEEK GoalActivity
 * via the occurrence ledger, the destination week's existing committed
 * facts -- EXCLUDING this exact occurrence, which is leaving its old
 * week, not adding a duplicate -- are loaded fresh (same transaction
 * client, same read-your-own-writes guarantee every other capacity
 * check in this codebase relies on) and checked through
 * `evaluateNewOccurrenceEligibility` (PR 1's own pure capacity API --
 * no new/duplicated formula). A move that would push the destination
 * week over its target throws CAPACITY_EXCEEDED before any write runs,
 * so the caller's own ROLLBACK leaves the original plan and occurrence
 * completely unchanged (this function's caller wraps everything in its
 * own transaction).
 *
 * A plan with no occurrence row (every finite/NONE-rhythm GoalActivity's
 * plan, and every plan with no Goal link at all) is a pure no-op here --
 * zero rows match, nothing is checked, nothing changes about its Move
 * behavior. The weekly TARGET itself is never read as anything other
 * than the GoalActivity's own persisted `rhythmTargetPerWeek` -- this
 * function never changes it, only enforces it.
 *
 * Insights V1 PR2 -- also returns the occurrence's owner's timezone
 * whenever a linked occurrence genuinely exists (`{ occurrenceId,
 * timezone }`), regardless of which branch below returns early after
 * that point (GoalActivity not found, finite/NONE rhythm) -- so the
 * caller (`applyMoveWrites`) can always correctly re-stamp that
 * occurrence's scheduled-week snapshot to the destination, never leaving
 * a stale snapshot behind after a genuine repoint. `null` means no
 * occurrence is linked at all, the only case where no snapshot write is
 * needed. The timezone fetch is therefore unconditional on "does an
 * occurrence exist," not on "does N_PER_WEEK capacity enforcement
 * apply" -- two different concerns that happen to share this one
 * function, now kept correct independently of each other.
 */
async function enforceDestinationWeekCapacity(
  client: { query: (text: string, params?: unknown[]) => Promise<{ rows: any[] }> },
  userId: string,
  a: PlannedActivity,
  newStartAt: Date
): Promise<{ occurrenceId: string; timezone: string } | null> {
  const occRes = await client.query(`SELECT id, "goalActivityId" FROM "GoalActivityOccurrence" WHERE "plannedActivityId" = $1 AND "userId" = $2`, [a.id, userId]);
  if (occRes.rows.length !== 1) return null; // no occurrence linked -- NONE-rhythm / non-Goal plan, unaffected
  const { id: occurrenceId, goalActivityId } = occRes.rows[0];

  const userRes = await client.query(`SELECT timezone FROM "User" WHERE id = $1`, [userId]);
  const timezone: string = userRes.rows[0].timezone;

  const gaRes = await client.query(`SELECT "rhythmKind", "rhythmTargetPerWeek" FROM "GoalActivity" WHERE id = $1 AND "userId" = $2`, [goalActivityId, userId]);
  if (gaRes.rows.length === 0) return { occurrenceId, timezone };
  const rhythm = normalizeGoalActivityRhythm({ rhythmKind: gaRes.rows[0].rhythmKind, rhythmTargetPerWeek: gaRes.rows[0].rhythmTargetPerWeek });
  if (rhythm.kind !== 'N_PER_WEEK') return { occurrenceId, timezone }; // finite Goal Activity -- Rhythm capacity is not a concept here

  const destinationLocalDate = getDatePartsInTimezone(timezone, newStartAt).dateStr;

  // Every OTHER occurrence fact for this GoalActivity -- excluding the one being moved, which is leaving its
  // current week, not contributing a duplicate to the destination week it hasn't joined yet.
  // Insights V1 PR3 -- LEFT JOIN on PlannedActivity (a sibling's plan may
  // have been hard-deleted) plus a durable-evidence LEFT JOIN on
  // GoalActivityExecution (via goalActivityOccurrenceId) so a deleted
  // sibling's COMPLETED contribution still counts toward this capacity
  // check -- same fix as db.ts's loadGoalActivityRhythmFacts.
  const factsRes = await client.query(
    `SELECT pa."plannedStartAt", pa.status, gao."scheduledWeekStart", gao."scheduledWeekTimezone", (gae.id IS NOT NULL) AS "hasCompletedExecution"
     FROM "GoalActivityOccurrence" gao
     LEFT JOIN "PlannedActivity" pa ON pa.id = gao."plannedActivityId"
     LEFT JOIN "GoalActivityExecution" gae ON gae."goalActivityOccurrenceId" = gao.id
     WHERE gao."goalActivityId" = $1 AND gao.id <> $2`,
    [goalActivityId, occurrenceId]
  );
  const occurrences: GoalActivityRhythmOccurrenceFact[] = factsRes.rows
    .map((row): GoalActivityRhythmOccurrenceFact | null => {
      const localDate = resolveOccurrenceLocalDateOrNull(
        { scheduledWeekStart: row.scheduledWeekStart, scheduledWeekTimezone: row.scheduledWeekTimezone },
        row.plannedStartAt ? new Date(row.plannedStartAt) : null,
        timezone
      );
      if (localDate === null) return null; // unattributable: pre-PR2 legacy occurrence whose plan was later deleted -- never fabricate a week
      return {
        localDate,
        contribution: deriveGoalActivityRhythmContributionWithEvidence(row.hasCompletedExecution, row.status as PlannedActivityStatusForRhythm | null),
      };
    })
    .filter((fact): fact is GoalActivityRhythmOccurrenceFact => fact !== null);

  const eligibility = evaluateNewOccurrenceEligibility({ rhythm, planningLocalDate: destinationLocalDate, occurrences });
  if (!eligibility.eligible) {
    throw new MovePlanError('CAPACITY_EXCEEDED', 'Moving this would exceed the destination week\'s weekly target.');
  }
  return { occurrenceId, timezone };
}

/**
 * SHARED with recomposition acceptance (F3): the writes of ONE Move inside the caller's transaction -- successor B
 * inserted directly (never through createPlannedActivity, whose same-title/same-time dedupe could hand back someone
 * else's plan), A transitioned UPCOMING -> MOVED (conditional), and the source (Capture / GoalActivity) repointed to B.
 * Time-specific Aura evaluation is NOT carried over: it described A's time. The scheduling MODE is inherited exactly
 * (FIXED stays FIXED, FLEXIBLE stays FLEXIBLE, unknown stays unknown): Move neither grants nor removes recomposition
 * permission, and it is independent of whether the user may Move a plan. The caller owns validation, locking and the
 * transaction; a lost conditional update throws INVALID_STATE so the caller rolls back.
 */
export async function applyMoveWrites(
  client: { query: (text: string, params?: unknown[]) => Promise<{ rows: any[] }> },
  userId: string,
  a: PlannedActivity,
  newStartAt: Date,
  newEndAt: Date
): Promise<MovePlanResult> {
  const occurrenceContext = await enforceDestinationWeekCapacity(client, userId, a, newStartAt);

  const bId = randomUUID();
  const bRes = await client.query(
    `INSERT INTO "PlannedActivity"
       (id, "userId", title, "activityType", icon, status, "plannedStartAt", "plannedEndAt", "durationMinutes",
        "windowType", "windowLabel", "matchLabel", score, recommendation, "calendarUrl",
        "eventTimezone", "eventLocationName", "schedulingMode", "activityId", "rescheduledFromPlanId")
     VALUES ($1, $2, $3, $4, $5, 'UPCOMING', $6, $7, $8, 'NEUTRAL', NULL, NULL, NULL, NULL, $9, $10, $11, $12, $13, $14)
     RETURNING *`,
    [
      bId, userId, a.title, a.activityType, a.icon, newStartAt, newEndAt, a.durationMinutes,
      buildGoogleCalendarUrl(a.title, newStartAt.toISOString(), newEndAt.toISOString()),
      a.eventTimezone, a.eventLocationName, parseSchedulingMode(a.schedulingMode), a.activityId ?? null, a.id,
    ]
  );

  // Insights V1 PR 1 -- movedAt is stamped in this SAME conditional UPDATE,
  // using the database's own now(), so it is atomic with the status
  // transition itself: a lost conditional update (below) throws and the
  // caller rolls back the whole transaction, leaving no stamp; a replay
  // that reaches the ALREADY_MOVED/already-successful short-circuit above
  // never re-executes this statement, so it never re-stamps.
  const aMoved = await client.query(
    `UPDATE "PlannedActivity" SET status = 'MOVED', "movedAt" = now(), "updatedAt" = now()
     WHERE id = $1 AND "userId" = $2 AND status = 'UPCOMING' RETURNING *`,
    [a.id, userId]
  );
  if (aMoved.rows.length !== 1) throw new MovePlanError('INVALID_STATE', 'Plan cannot be moved.');

  // Continuity: the source follows the commitment. Zero rows for a source-less plan.
  await client.query(`UPDATE "Capture" SET "plannedActivityId" = $1, "updatedAt" = now() WHERE "plannedActivityId" = $2 AND "userId" = $3`, [bId, a.id, userId]);
  await client.query(`UPDATE "GoalActivity" SET "plannedActivityId" = $1, "updatedAt" = now() WHERE "plannedActivityId" = $2 AND "userId" = $3`, [bId, a.id, userId]);
  // Goals V2 G2.2.3 -- same continuity, for the SAME reason: GoalActivityExecution
  // (apps/web/lib/goalActivityExecution.ts) is durable EXECUTION identity, while
  // PlannedActivity is only current PLACEMENT identity (see this file's own header
  // comment). Move changes where an execution is associated, never what it is --
  // a pure pointer repoint. Nothing else about the row changes: id, goalActivityId,
  // the completion*Snapshot fields, currentValue, and source are untouched (they
  // aren't even referenced in this statement). Zero rows for a plan with no
  // execution -- the common case today, since no production path creates one
  // before completion (G2.2.2) -- this UPDATE is then simply a no-op, exactly like
  // the Capture line above for a source-less plan. If B were ever already claimed
  // by a different execution row (should be structurally impossible under correct
  // Move semantics), plannedActivityId's own UNIQUE constraint rejects the write
  // outright rather than silently overwriting/merging anything -- the same
  // transaction this statement runs in then rolls back entirely (this function's
  // caller wraps everything in BEGIN/COMMIT/ROLLBACK), never a partially-moved A
  // or a partially-repointed GoalActivity left behind.
  await client.query(`UPDATE "GoalActivityExecution" SET "plannedActivityId" = $1, "updatedAt" = now() WHERE "plannedActivityId" = $2 AND "userId" = $3`, [bId, a.id, userId]);
  // Goals V2 Rhythm R1/R3 -- same continuity, for the SAME reason:
  // GoalActivityOccurrence (apps/web/lib/db.ts's materializeGoalActivityRhythmOccurrence)
  // is durable OCCURRENCE identity, while PlannedActivity is only current
  // PLACEMENT identity. Move repoints which plan an occurrence is
  // associated with; it never creates a new occurrence (R3's own hard
  // invariant -- "no new occurrence on Move"). Zero rows for a plan with
  // no occurrence -- every pre-R3 Move, and every Move of a finite (NONE)
  // GoalActivity's plan, which never has an occurrence row at all -- this
  // UPDATE is then simply a no-op, exactly like the two lines above for a
  // source-less plan. "plannedActivityId"'s own UNIQUE constraint
  // (migration 0042) rejects the write outright rather than silently
  // double-claiming B, with the same whole-transaction-rollback guarantee
  // the GoalActivityExecution line above already relies on.
  //
  // Insights V1 PR2 -- the scheduled-week snapshot is re-stamped in this
  // SAME statement, atomically with the repoint, whenever a linked
  // occurrence actually exists (`occurrenceContext` non-null, set by
  // `enforceDestinationWeekCapacity` above, which already confirmed the
  // occurrence and fetched this exact timezone). This is what correctly
  // transfers attribution to the destination week on a cross-week Move,
  // and leaves it unchanged (recomputed to the SAME value) on a
  // same-week Move -- never a stale value left over from creation/an
  // earlier Move. `null`/`null` for a plan with no linked occurrence is
  // harmless: the WHERE clause already matches zero rows in that case.
  const scheduledWeekStart = occurrenceContext ? localCalendarWeekStart(getDatePartsInTimezone(occurrenceContext.timezone, newStartAt).dateStr) : null;
  const scheduledWeekTimezone = occurrenceContext ? occurrenceContext.timezone : null;
  await client.query(
    `UPDATE "GoalActivityOccurrence" SET "plannedActivityId" = $1, "scheduledWeekStart" = $2, "scheduledWeekTimezone" = $3 WHERE "plannedActivityId" = $4 AND "userId" = $5`,
    [bId, scheduledWeekStart, scheduledWeekTimezone, a.id, userId]
  );

  return { from: aMoved.rows[0], to: bRes.rows[0] };
}
