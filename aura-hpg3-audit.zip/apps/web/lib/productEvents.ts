// Product Instrumentation V1 -- a small, closed event taxonomy plus per-event
// metadata validation. This is the ONLY module in the app that knows what a
// "valid" product event looks like; every write path (server route handlers,
// and the client-tracking API route) must go through `validateProductEvent`
// here before anything reaches the database.
//
// Two things are deliberately enforced BEFORE any per-event allow-list is
// consulted:
//   1. The event name must be one of the closed set below (no free-form
//      event names).
//   2. No metadata key may appear in FORBIDDEN_METADATA_KEYS, regardless of
//      whether a per-event schema would otherwise accept it. This is
//      defense-in-depth: even a future mistake in an event's own schema
//      cannot leak one of these fields.
import { FULL_ACTIVITY_CATALOG } from '../../../packages/recommendation/src/personalizedTasks';
import { GOAL_TEMPLATE_CATEGORIES } from './goals';
import { createProductEvent } from './db';

export type ProductEventName =
  | 'AURA_HOME_VIEWED'
  | 'PLAN_STARTED'
  | 'PLAN_SEARCH_COMPLETED'
  | 'PLAN_RESULT_SELECTED'
  | 'PANCHANG_CALENDAR_VIEWED'
  | 'PANCHANG_DATE_VIEWED'
  | 'MUHURTHAM_SEARCH_STARTED'
  | 'MUHURTHAM_SCOPE_SELECTED'
  | 'MUHURTHAM_SEARCH_COMPLETED'
  | 'SAVED_PERSON_CREATED'
  | 'AURA_MOMENT_CREATED'
  | 'AURA_MOMENT_SHARE_INITIATED'
  | 'AURA_MOMENT_OPENED'
  | 'AURA_MOMENT_ACCEPTED'
  | 'AURA_MOMENT_ANOTHER_TIME'
  | 'AURA_MOMENT_ALTERNATIVE_CREATED'
  | 'AURA_MOMENT_FIND_YOUR_OWN_CLICKED'
  | 'REMINDER_OPENED'
  | 'ACTIVITY_LOGGED_NOW'
  | 'WEB_PUSH_ENABLED'
  | 'WEB_PUSH_DISABLED'
  | 'REMINDER_PUSH_SENT'
  | 'ASK_AURA_SUBMITTED'
  | 'ASK_AURA_INTENT_RESOLVED'
  | 'ASK_AURA_RESULT_ACTION'
  | 'GUEST_TIMING_SEARCH_STARTED'
  | 'GUEST_TIMING_RESULT_VIEWED'
  | 'GUEST_SIGNUP_STARTED'
  | 'GUEST_SIGNUP_COMPLETED'
  | 'GUEST_RESULT_SAVED'
  | 'MY_DAY_INTENTION_OPENED'
  | 'MY_DAY_INTENTION_SELECTED'
  | 'MY_DAY_ITEM_OPENED'
  | 'MY_DAY_ADD_STARTED'
  | 'GUEST_RESULT_RESTORED'
  | 'ONBOARDING_HANDOFF_VIEWED'
  | 'MY_DAY_OPENED_FROM_HANDOFF'
  | 'DAILY_REFLECTION_VIEWED'
  | 'TOMORROW_PREVIEW_VIEWED'
  | 'TOMORROW_PROMPT_SELECTED'
  | 'TOMORROW_PLAN_STARTED'
  | 'DAY_BUILDER_SUGGESTIONS_VIEWED'
  | 'DAY_BUILDER_SUGGESTION_ADDED'
  | 'DAY_BUILDER_INVITE_SENT'
  | 'DAY_BUILDER_ANOTHER_IDEA'
  | 'DAY_BUILDER_SUGGESTION_DISMISSED'
  | 'DAY_BUILDER_SLOT_SELECTED'
  | 'PERSONALIZATION_PROMPT_VIEWED'
  | 'PERSONALIZATION_PREFERENCES_SAVED'
  | 'PERSONALIZATION_PREFERENCES_UPDATED'
  | 'GOAL_DECOMPOSITION_SHOWN'
  | 'GOAL_DECOMPOSITION_CONFIRMED'
  | 'GOAL_DECOMPOSITION_CREATE_FAILED';

export const PRODUCT_EVENT_NAMES: ProductEventName[] = [
  'AURA_HOME_VIEWED',
  'PLAN_STARTED',
  'PLAN_SEARCH_COMPLETED',
  'PLAN_RESULT_SELECTED',
  'PANCHANG_CALENDAR_VIEWED',
  'PANCHANG_DATE_VIEWED',
  'MUHURTHAM_SEARCH_STARTED',
  'MUHURTHAM_SCOPE_SELECTED',
  'MUHURTHAM_SEARCH_COMPLETED',
  'SAVED_PERSON_CREATED',
  'AURA_MOMENT_CREATED',
  'AURA_MOMENT_SHARE_INITIATED',
  'AURA_MOMENT_OPENED',
  'AURA_MOMENT_ACCEPTED',
  'AURA_MOMENT_ANOTHER_TIME',
  'AURA_MOMENT_ALTERNATIVE_CREATED',
  'AURA_MOMENT_FIND_YOUR_OWN_CLICKED',
  'REMINDER_OPENED',
  'ACTIVITY_LOGGED_NOW',
  'WEB_PUSH_ENABLED',
  'WEB_PUSH_DISABLED',
  'REMINDER_PUSH_SENT',
  'ASK_AURA_SUBMITTED',
  'ASK_AURA_INTENT_RESOLVED',
  'ASK_AURA_RESULT_ACTION',
  'GUEST_TIMING_SEARCH_STARTED',
  'GUEST_TIMING_RESULT_VIEWED',
  'GUEST_SIGNUP_STARTED',
  'GUEST_SIGNUP_COMPLETED',
  'GUEST_RESULT_SAVED',
  'MY_DAY_INTENTION_OPENED',
  'MY_DAY_INTENTION_SELECTED',
  'MY_DAY_ITEM_OPENED',
  'MY_DAY_ADD_STARTED',
  'GUEST_RESULT_RESTORED',
  'ONBOARDING_HANDOFF_VIEWED',
  'MY_DAY_OPENED_FROM_HANDOFF',
  'DAILY_REFLECTION_VIEWED',
  'TOMORROW_PREVIEW_VIEWED',
  'TOMORROW_PROMPT_SELECTED',
  'TOMORROW_PLAN_STARTED',
  'DAY_BUILDER_SUGGESTIONS_VIEWED',
  'DAY_BUILDER_SUGGESTION_ADDED',
  'DAY_BUILDER_INVITE_SENT',
  'DAY_BUILDER_ANOTHER_IDEA',
  'DAY_BUILDER_SUGGESTION_DISMISSED',
  'DAY_BUILDER_SLOT_SELECTED',
  'PERSONALIZATION_PROMPT_VIEWED',
  'PERSONALIZATION_PREFERENCES_SAVED',
  'PERSONALIZATION_PREFERENCES_UPDATED',
  'GOAL_DECOMPOSITION_SHOWN',
  'GOAL_DECOMPOSITION_CONFIRMED',
  'GOAL_DECOMPOSITION_CREATE_FAILED',
];

export function isProductEventName(value: string): value is ProductEventName {
  return (PRODUCT_EVENT_NAMES as string[]).includes(value);
}

// Which events are tracked from the server (at the moment of DB success) vs.
// the client (a UI intent signal with no reliable server equivalent). This
// is documentation for call sites, not enforced by validation itself -- the
// client tracking API still validates SERVER-tracked event names the same
// way, but route handlers should never call it for a client-only event.
export const CLIENT_TRACKED_EVENTS: ReadonlySet<ProductEventName> = new Set<ProductEventName>([
  'AURA_HOME_VIEWED',
  'PLAN_STARTED',
  'PLAN_RESULT_SELECTED',
  'PANCHANG_CALENDAR_VIEWED',
  'PANCHANG_DATE_VIEWED',
  'MUHURTHAM_SEARCH_STARTED',
  'MUHURTHAM_SCOPE_SELECTED',
  'AURA_MOMENT_SHARE_INITIATED',
  'AURA_MOMENT_FIND_YOUR_OWN_CLICKED',
  // Aura Reminders V1 (brief section 29/30): a genuine user click, not a
  // recomputed-per-GET impression -- REMINDER_SURFACED (an impression
  // event) is deliberately NOT implemented (section 30 explicitly permits
  // deferring impression analytics when clean dedup isn't straightforward;
  // reminders are recomputed on every GET /api/aura-updates, so a naive
  // "surfaced" event would fire on every poll).
  'REMINDER_OPENED',
  // Good Right Now Actions V1 (brief section 19) -- handleLogActivity()
  // (page.tsx) is deliberately optimistic/offline-resilient and never
  // surfaces server DB success/failure to its caller (queues locally on
  // any failure instead of throwing), so there is no reliable point to
  // track this server-side at the moment of DB success the way
  // AURA_MOMENT_CREATED is. Tracked as a UI intent signal instead, the same
  // convention as every other CLIENT_TRACKED_EVENTS entry.
  'ACTIVITY_LOGGED_NOW',
  // Web Push V1 (brief section 30) -- both are user-initiated UI intent
  // (the "Enable notifications" / "Turn off" buttons), fired at click time,
  // not server-confirmed subscribe/unsubscribe outcomes.
  'WEB_PUSH_ENABLED',
  'WEB_PUSH_DISABLED',
  // Ask Aura Orchestration V1 (brief section 30) -- SUBMITTED/RESULT_ACTION
  // are UI intent signals (send button pressed / result action clicked),
  // mirroring PLAN_STARTED/PLAN_RESULT_SELECTED's own client-tracked
  // pattern. INTENT_RESOLVED is deliberately NOT here -- it's recorded
  // server-side by the route at the moment parsing actually happens
  // (mirrors PLAN_SEARCH_COMPLETED), never duplicated client-side.
  'ASK_AURA_SUBMITTED',
  'ASK_AURA_RESULT_ACTION',
  // Recipient Conversion V1 (brief section 22) -- every guest-funnel step is
  // a UI intent signal fired from the public, unauthenticated /find page
  // (there is no session to attach a server-side "at DB success" moment to
  // for most of these, and GUEST_SIGNUP_COMPLETED specifically must NOT
  // fire from the shared verify/verify-code routes, which also serve every
  // ordinary returning-user sign-in -- only /find itself knows this
  // particular session completion belongs to the guest conversion funnel).
  'GUEST_TIMING_SEARCH_STARTED',
  'GUEST_TIMING_RESULT_VIEWED',
  'GUEST_SIGNUP_STARTED',
  'GUEST_SIGNUP_COMPLETED',
  'GUEST_RESULT_SAVED',
  // My Day V1 (brief section 44) -- all four are UI intent signals from the
  // intention-discovery widget; none corresponds to a clean server-side "DB
  // write succeeded" moment worth a second event (the actual Add-to-my-day/
  // Invite-someone outcomes already fire PLAN_RESULT_SELECTED-equivalent/
  // AURA_MOMENT_CREATED via the existing reused APIs, not a My-Day-specific
  // completion event -- avoids duplicating that taxonomy).
  'MY_DAY_INTENTION_OPENED',
  'MY_DAY_INTENTION_SELECTED',
  'MY_DAY_ITEM_OPENED',
  'MY_DAY_ADD_STARTED',
  // Recipient Conversion V1 Hardening (brief section 16) -- three genuinely
  // new funnel steps with no existing equivalent (MOMENT_OPENED/
  // CONVERSION_CLICKED/GUEST_SEARCH_STARTED/GUEST_RESULT_VIEWED/
  // SIGNUP_STARTED/SIGNUP_COMPLETED already exist under other names --
  // reused as-is below in GuestFindClient.tsx, not duplicated here. brief's
  // FIRST_PLAN_SAVED is the same moment as the existing GUEST_RESULT_SAVED
  // above, also reused rather than duplicated).
  'GUEST_RESULT_RESTORED',
  'ONBOARDING_HANDOFF_VIEWED',
  'MY_DAY_OPENED_FROM_HANDOFF',
  // Daily Reflection & Tomorrow Preview V1 (brief section 15) -- all four
  // are UI intent/impression signals from the Home daily-story area; no
  // clean server-side "DB write succeeded" moment exists for any of them
  // (viewing a derived reflection/preview never writes anything, and the
  // actual "start planning tomorrow" handoff is a navigation, not a write
  // -- the real Plan/Moment creation that might follow still fires its own
  // existing PLAN_RESULT_SELECTED/AURA_MOMENT_CREATED, not duplicated here).
  'DAILY_REFLECTION_VIEWED',
  'TOMORROW_PREVIEW_VIEWED',
  'TOMORROW_PROMPT_SELECTED',
  'TOMORROW_PLAN_STARTED',
  // Intentional Day Builder V1 (brief section 36) -- ADDED/INVITE_SENT/
  // ANOTHER_IDEA are UI intent signals from Daily Story's own proactive
  // suggestion cards (DayBuilderCard.tsx), the same convention as MY_DAY_*
  // above. SUGGESTIONS_VIEWED is deliberately NOT here -- it's recorded
  // server-side by GET /api/my-day/suggestions at the moment suggestions
  // are actually computed (mirrors PLAN_SEARCH_COMPLETED), never duplicated
  // client-side, and only when at least one suggestion was produced (an
  // empty result is a successful, quiet outcome, not an impression to log).
  'DAY_BUILDER_SUGGESTION_ADDED',
  'DAY_BUILDER_INVITE_SENT',
  'DAY_BUILDER_ANOTHER_IDEA',
  'DAY_BUILDER_SUGGESTION_DISMISSED',
  // Home Compactness + Flexible Day Story V1 (brief section 49) -- a UI
  // intent signal (which already-resolved time chip the user tapped),
  // same convention as the other DAY_BUILDER_* events above. Never carries
  // a person's name or a raw timing reason (brief: "do not log exact
  // person name/raw timing reasons").
  'DAY_BUILDER_SLOT_SELECTED',
  // Personalization Foundation V1 (brief section 9) -- all three are UI
  // intent/impression signals from the "What matters most lately?" prompt
  // (PersonalizationPromptCard.tsx) and the You -> Day Builder priorities
  // editor (DayBuilderSettings.tsx). No server-side write moment exists to
  // hook these into (updateUserDayBuilderPrefs already fires from a single
  // shared route used by several unrelated preference changes too), same
  // reasoning as the DAY_BUILDER_* events above.
  'PERSONALIZATION_PROMPT_VIEWED',
  'PERSONALIZATION_PREFERENCES_SAVED',
  'PERSONALIZATION_PREFERENCES_UPDATED',
  // Goals V2 Candidate B4 -- all three are fired client-side from
  // GoalsListClient.tsx's own CreateGoalModal. SHOWN/CREATE_FAILED have
  // no server-side equivalent moment at all (same reasoning as every
  // other CLIENT_TRACKED_EVENTS entry above). CONFIRMED is a deliberate
  // departure from this codebase's usual "CREATED/COMPLETED fires
  // server-side, at the moment of DB success" convention (e.g.
  // AURA_MOMENT_CREATED, not listed here): the review-summary fields
  // (wasEdited/removedCount/renamedCount/...) exist ONLY as client-side
  // UI state and are never sent to the server (this ticket's own section
  // 42 explicitly expects no POST /api/goals contract change) -- there is
  // no server-side moment that could carry them. Fired exactly once per
  // successful response, from the same branch that already navigates
  // away on success -- structurally incapable of double-firing within one
  // mount (a second handleSubmit call can only happen after an ERROR,
  // never after this branch, which immediately navigates away) -- so a
  // B3.1 idempotent replay the client happens to observe is still exactly
  // one CONFIRMED event, never two (this ticket's own section 13).
  'GOAL_DECOMPOSITION_SHOWN',
  'GOAL_DECOMPOSITION_CONFIRMED',
  'GOAL_DECOMPOSITION_CREATE_FAILED',
]);

// Fields that must NEVER appear in ProductEvent.metadata, under any event,
// under any casing. This list is the direct enforcement of the brief's
// forbidden-metadata section (birth data, natal placements, raw reasons,
// names/emails, tokens, and free-text queries).
const FORBIDDEN_METADATA_KEYS = new Set<string>([
  'birthdate',
  'birthtime',
  'birthtimezone',
  'birthlatitude',
  'birthlongitude',
  'latitude',
  'longitude',
  'coordinates',
  'janmanakshatra',
  'janmarashi',
  'natalnakshatraindex',
  'tarabala',
  'reasons',
  'muhurtareasons',
  'name',
  'savedpersonname',
  'recipientname',
  'senderdisplayname',
  'shareddisplayname',
  'email',
  'publictoken',
  'token',
  'query',
  'message',
  'conversation',
]);

const SCOPE_VALUES = new Set(['GENERAL', 'PERSONAL', 'SHARED']);
const TIMING_MODE_VALUES = new Set(['FIND', 'CHECK', 'COMPARE']);
const PREFERENCE_VALUES = new Set(['EARLIER', 'LATER', 'DIFFERENT_DAY', 'NO_PREFERENCE']);
const SHARE_METHOD_VALUES = new Set(['native_share', 'copy_link']);
const RELATIONSHIP_VALUES = new Set(['PARTNER', 'SPOUSE', 'FAMILY', 'FRIEND', 'OTHER']);
// Product Structure V2 (brief section 31): "at minimum ensure we can
// distinguish... source = PLAN | MUHURTHAM, planningMode = EVERYDAY |
// IMPORTANT | CEREMONIAL" -- reusing the exact same closed vocabularies
// AuraMomentSource/PlanningMode already define, not a third copy.
const SOURCE_VALUES = new Set(['PLAN', 'MUHURTHAM']);
const PLANNING_MODE_VALUES = new Set(['EVERYDAY', 'IMPORTANT', 'CEREMONIAL']);
// Aura Reminders V1 (brief section 12): the only two reminder types -- lead
// time is data (leadTimeMinutes below), not a distinct type per lead time.
const SCHEDULED_ITEM_TYPE_VALUES = new Set(['PLANNED_ACTIVITY', 'AURA_MOMENT']);
// Good Right Now Actions V1 (brief section 19) -- deliberately its own
// vocabulary, not a reuse of SOURCE_VALUES above (PLAN | MUHURTHAM means
// "which search flow produced this AuraMoment", an unrelated concept to
// "which screen initiated this activity log").
const LOG_ORIGIN_VALUES = new Set(['HOME']);
const WINDOW_TYPE_VALUES = new Set(['BRAHMA', 'ABHIJIT', 'RAHU_KALAM', 'GULIKA', 'YAMA', 'NEUTRAL']);
const IMMEDIATE_ACTION_TYPE_VALUES = new Set(['LOG_NOW', 'START_NOW']);
// Good Right Now Action Semantics V1 (brief section 14) -- the same closed
// vocabulary ActivityDurationMode already defines, not a third copy.
const DURATION_MODE_VALUES = new Set(['INSTANT', 'FIXED', 'USER_SELECTED', 'SESSION']);
// Web Push V1 (brief section 31) -- ONE canonical REMINDER_OPENED event
// with a `source` distinguishing an in-app open (Home/Updates) from a push
// notification click, rather than a second REMINDER_PUSH_OPENED event
// representing the same user action ("this reminder was opened").
const REMINDER_OPEN_SOURCE_VALUES = new Set(['IN_APP', 'PUSH']);
// Ask Aura Orchestration V1 (brief section 30) -- the exact same closed
// enums askAuraIntent.ts's own AskAuraIntent/AskHorizonPhrase types define,
// not a third copy. Deliberately excludes activityId's own free-text
// fallback (taskTitle) and the raw prompt itself -- FORBIDDEN_METADATA_KEYS
// above already blocks 'query'/'message' outright as defense-in-depth.
const ASK_INTENT_VALUES = new Set([
  'GOOD_RIGHT_NOW', 'TIMING_FIND', 'TIMING_CHECK', 'TIMING_COMPARE',
  'PANCHANG_QUERY', 'PANCHANG_EXPLAIN', 'MUHURTHAM_SEARCH', 'PLAN_OPEN', 'UNKNOWN',
  // Ask Aura V1 -- TODAY_GUIDANCE/FORWARD_PLAN.
  'TODAY_GUIDANCE', 'FORWARD_PLAN',
]);
const ASK_HORIZON_VALUES = new Set([
  'NOW', 'TODAY', 'TOMORROW', 'THIS_WEEKEND', 'NEXT_WEEKEND', 'THIS_WEEK',
  'NEXT_7_DAYS', 'NEXT_MONTH', 'CUSTOM_DATE', 'UNSPECIFIED',
]);
const ASK_TIME_PREFERENCE_VALUES = new Set(['ANY', 'MORNING', 'AFTERNOON', 'EVENING', 'NIGHT']);
const ASK_RESULT_ACTION_VALUES = new Set(['PLAN_THIS', 'CREATE_MOMENT', 'OPEN_PLAN', 'OPEN_TIMELINE', 'OPEN_HOME_TIMELINE', 'OPEN_PANCHANG', 'OPEN_MUHURTHAM', 'SCHEDULE_FORWARD_PLAN']);
// Recipient Conversion V1 (brief section 22/23) -- GUEST_HORIZON_VALUES is
// the exact guest-facing horizon subset lib/guestTimingSearchRequest.ts
// validates against (not the full PlanningHorizon set, which also has
// NOW/CUSTOM that guest search never uses). timePreference reuses
// ASK_TIME_PREFERENCE_VALUES above verbatim -- same closed vocabulary as
// TimingTimePreference, not a third copy. GUEST_SOURCE_VALUES is a new,
// deliberately coarse product-level attribution vocabulary (brief section
// 11): AURA_MOMENT | DIRECT, never a sender/Moment identity.
const GUEST_HORIZON_VALUES = new Set(['TODAY', 'TOMORROW', 'WEEKEND', 'SEVEN_DAYS']);
const GUEST_SOURCE_VALUES = new Set(['AURA_MOMENT', 'DIRECT']);

type FieldSchema =
  | { type: 'enum'; values: Set<string> }
  | { type: 'activityId' }
  | { type: 'number'; min: number; max: number }
  | { type: 'boolean' };

const scopeField: FieldSchema = { type: 'enum', values: SCOPE_VALUES };
const activityIdField: FieldSchema = { type: 'activityId' };
const durationField: FieldSchema = { type: 'number', min: 0, max: 120_000 };
const sourceField: FieldSchema = { type: 'enum', values: SOURCE_VALUES };
const planningModeField: FieldSchema = { type: 'enum', values: PLANNING_MODE_VALUES };
const guestHorizonField: FieldSchema = { type: 'enum', values: GUEST_HORIZON_VALUES };
const guestTimePreferenceField: FieldSchema = { type: 'enum', values: ASK_TIME_PREFERENCE_VALUES };
const guestSourceField: FieldSchema = { type: 'enum', values: GUEST_SOURCE_VALUES };

// My Day V1 (brief section 44) -- the same closed vocabularies
// DailyIntentionGroupId/DailyAgendaItemType/DailyStoryPhase already define,
// not third copies. intentionCategory deliberately excludes the virtual
// PEOPLE broad choice (brief section 20's umbrella, never itself a real
// group) -- only the seven real DailyIntentionGroupId values.
const MY_DAY_INTENTION_CATEGORY_VALUES = new Set(['RELATIONSHIPS', 'FAMILY', 'SOCIAL', 'WORK', 'SELF', 'ENJOYMENT', 'LIFE']);
const MY_DAY_ITEM_TYPE_VALUES = new Set(['PLAN', 'MOMENT', 'COMPLETED_ACTIVITY']);
const MY_DAY_DAY_PHASE_VALUES = new Set(['MORNING', 'MIDDAY', 'AFTERNOON', 'EVENING', 'NIGHT']);
const myDayIntentionCategoryField: FieldSchema = { type: 'enum', values: MY_DAY_INTENTION_CATEGORY_VALUES };
const myDayItemTypeField: FieldSchema = { type: 'enum', values: MY_DAY_ITEM_TYPE_VALUES };
const myDayDayPhaseField: FieldSchema = { type: 'enum', values: MY_DAY_DAY_PHASE_VALUES };

// Goals V2 Candidate B4 -- GOAL_DECOMPOSITION_SHOWN only ever fires for an
// actual template-backed decomposition (AUTO_MATCH or an explicit manual
// template choice); SCRATCH/NO_MATCH are never "shown" moments (brief
// section 8). GOAL_MATCH_SOURCE_VALUES is the superset used by the
// confirmation/failure events, which DO need to represent all four
// outcomes (brief section 9: NO_MATCH visibility, captured only as part
// of the eventual confirm/fail funnel, never its own keystroke-driven
// event).
const GOAL_DECOMPOSITION_SOURCE_VALUES = new Set(['AUTO_MATCH', 'MANUAL_TEMPLATE']);
const GOAL_MATCH_SOURCE_VALUES = new Set(['AUTO_MATCH', 'MANUAL_TEMPLATE', 'SCRATCH', 'NO_MATCH']);
// Reuses GoalTemplateCategory's own exact closed vocabulary (lib/goals.ts),
// never a third copy.
const GOAL_TEMPLATE_CATEGORY_VALUES = new Set<string>(GOAL_TEMPLATE_CATEGORIES);
const GOAL_CREATE_ERROR_CATEGORY_VALUES = new Set(['VALIDATION', 'IDEMPOTENCY_CONFLICT', 'SERVER_ERROR', 'NETWORK_ERROR']);
const goalTemplateCategoryField: FieldSchema = { type: 'enum', values: GOAL_TEMPLATE_CATEGORY_VALUES };
// Mirrors POST /api/goals's own MAX_REVIEWED_ACTIVITIES bound (Candidate
// B3) -- every count field here is a count of reviewed activities, so
// the same ceiling applies.
const goalActivityCountField: FieldSchema = { type: 'number', min: 0, max: 20 };

const EVENT_METADATA_SCHEMAS: Record<ProductEventName, Record<string, FieldSchema>> = {
  AURA_HOME_VIEWED: {},
  PLAN_STARTED: {
    mode: { type: 'enum', values: TIMING_MODE_VALUES },
  },
  PLAN_SEARCH_COMPLETED: {
    mode: { type: 'enum', values: TIMING_MODE_VALUES },
    resultCount: { type: 'number', min: 0, max: 1000 },
    durationMs: durationField,
  },
  PLAN_RESULT_SELECTED: {
    mode: { type: 'enum', values: TIMING_MODE_VALUES },
  },
  PANCHANG_CALENDAR_VIEWED: {},
  PANCHANG_DATE_VIEWED: {},
  MUHURTHAM_SEARCH_STARTED: {
    scope: scopeField,
    activityId: activityIdField,
  },
  MUHURTHAM_SCOPE_SELECTED: {
    scope: scopeField,
  },
  MUHURTHAM_SEARCH_COMPLETED: {
    scope: scopeField,
    activityId: activityIdField,
    resultCount: { type: 'number', min: 0, max: 500 },
    durationMs: durationField,
  },
  SAVED_PERSON_CREATED: {
    relationshipType: { type: 'enum', values: RELATIONSHIP_VALUES },
  },
  AURA_MOMENT_CREATED: {
    scope: scopeField,
    activityId: activityIdField,
    source: sourceField,
    planningMode: planningModeField,
  },
  AURA_MOMENT_SHARE_INITIATED: {
    scope: scopeField,
    method: { type: 'enum', values: SHARE_METHOD_VALUES },
    planningMode: planningModeField,
  },
  AURA_MOMENT_OPENED: {
    scope: scopeField,
  },
  AURA_MOMENT_ACCEPTED: {
    scope: scopeField,
  },
  AURA_MOMENT_ANOTHER_TIME: {
    scope: scopeField,
    preference: { type: 'enum', values: PREFERENCE_VALUES },
  },
  AURA_MOMENT_ALTERNATIVE_CREATED: {
    scope: scopeField,
    activityId: activityIdField,
    source: sourceField,
    planningMode: planningModeField,
  },
  AURA_MOMENT_FIND_YOUR_OWN_CLICKED: {},
  REMINDER_OPENED: {
    scheduledItemType: { type: 'enum', values: SCHEDULED_ITEM_TYPE_VALUES },
    leadTimeMinutes: { type: 'number', min: 0, max: 120 },
    // Web Push V1 -- optional; existing in-app call sites are unaffected
    // by adding this (omitted keys are never validated), only the new
    // push-click path sets it to 'PUSH'.
    source: { type: 'enum', values: REMINDER_OPEN_SOURCE_VALUES },
  },
  ACTIVITY_LOGGED_NOW: {
    // Omitted for the two Good Right Now cards with no catalog counterpart
    // (see actionCards.ts's abhijit-meal/yama-lightmeal) -- validation only
    // runs on keys that are actually present.
    activityId: activityIdField,
    source: { type: 'enum', values: LOG_ORIGIN_VALUES },
    windowType: { type: 'enum', values: WINDOW_TYPE_VALUES },
    actionType: { type: 'enum', values: IMMEDIATE_ACTION_TYPE_VALUES },
    // Good Right Now Action Semantics V1 (brief section 14) -- safe,
    // non-identifying: which duration rule applied and the actual minutes
    // logged (0 for INSTANT, never a birth/natal/Panchang-detail payload).
    durationMode: { type: 'enum', values: DURATION_MODE_VALUES },
    durationMinutes: { type: 'number', min: 0, max: 180 },
  },
  WEB_PUSH_ENABLED: {},
  WEB_PUSH_DISABLED: {},
  REMINDER_PUSH_SENT: {
    scheduledItemType: { type: 'enum', values: SCHEDULED_ITEM_TYPE_VALUES },
    leadTimeMinutes: { type: 'number', min: 0, max: 120 },
  },
  ASK_AURA_SUBMITTED: {},
  ASK_AURA_INTENT_RESOLVED: {
    intent: { type: 'enum', values: ASK_INTENT_VALUES },
    activityId: activityIdField,
    scope: scopeField,
    horizon: { type: 'enum', values: ASK_HORIZON_VALUES },
    timePreference: { type: 'enum', values: ASK_TIME_PREFERENCE_VALUES },
  },
  ASK_AURA_RESULT_ACTION: {
    intent: { type: 'enum', values: ASK_INTENT_VALUES },
    action: { type: 'enum', values: ASK_RESULT_ACTION_VALUES },
  },
  // Recipient Conversion V1 (brief section 22/23) -- activityId/horizon/
  // timePreference/durationMinutes bucket/source only. Never free text,
  // email, person name, public token, location coordinates, or birth
  // information (brief section 23) -- FORBIDDEN_METADATA_KEYS already
  // structurally blocks the sensitive ones even if a mistake were made here.
  GUEST_TIMING_SEARCH_STARTED: {
    activityId: activityIdField,
    horizon: guestHorizonField,
    timePreference: guestTimePreferenceField,
    source: guestSourceField,
  },
  GUEST_TIMING_RESULT_VIEWED: {
    activityId: activityIdField,
    resultCount: { type: 'number', min: 0, max: 3 },
    source: guestSourceField,
  },
  GUEST_SIGNUP_STARTED: {
    source: guestSourceField,
  },
  GUEST_SIGNUP_COMPLETED: {
    source: guestSourceField,
  },
  GUEST_RESULT_SAVED: {
    activityId: activityIdField,
    source: guestSourceField,
  },
  // My Day V1 (brief section 44/45) -- intentionCategory/activityId/
  // itemType/dayPhase only. Never person name, raw narrative, raw prompt,
  // birth details, or coordinates (brief section 44) -- all already
  // structurally blocked by FORBIDDEN_METADATA_KEYS as defense-in-depth.
  MY_DAY_INTENTION_OPENED: {
    dayPhase: myDayDayPhaseField,
  },
  MY_DAY_INTENTION_SELECTED: {
    intentionCategory: myDayIntentionCategoryField,
    activityId: activityIdField,
    dayPhase: myDayDayPhaseField,
  },
  MY_DAY_ITEM_OPENED: {
    itemType: myDayItemTypeField,
    dayPhase: myDayDayPhaseField,
  },
  MY_DAY_ADD_STARTED: {
    intentionCategory: myDayIntentionCategoryField,
    activityId: activityIdField,
    dayPhase: myDayDayPhaseField,
  },
  // Recipient Conversion V1 Hardening (brief section 16) -- activityId/
  // source only, same restrained shape as the other GUEST_* events.
  GUEST_RESULT_RESTORED: {
    activityId: activityIdField,
    source: guestSourceField,
  },
  ONBOARDING_HANDOFF_VIEWED: {
    activityId: activityIdField,
    source: guestSourceField,
  },
  MY_DAY_OPENED_FROM_HANDOFF: {
    source: guestSourceField,
  },
  // Daily Reflection & Tomorrow Preview V1 (brief section 15) -- aggregate
  // counts and closed enums only. Never raw journal/reflection text, person
  // names, birth data, or a Moment token (brief's own explicit forbidden
  // list) -- FORBIDDEN_METADATA_KEYS already structurally blocks the
  // sensitive ones (name/email/token/etc) as defense-in-depth, and there is
  // no free-text field here to forbid in the first place (brief section 12:
  // no free-text journal storage in V1).
  DAILY_REFLECTION_VIEWED: {
    completedCount: { type: 'number', min: 0, max: 100 },
    missedCount: { type: 'number', min: 0, max: 100 },
  },
  TOMORROW_PREVIEW_VIEWED: {
    hasScheduledItems: { type: 'boolean' },
    goodForCategoryCount: { type: 'number', min: 0, max: 10 },
  },
  TOMORROW_PROMPT_SELECTED: {
    intentionCategory: myDayIntentionCategoryField,
    activityId: activityIdField,
  },
  TOMORROW_PLAN_STARTED: {
    // Omitted when the handoff started from the generic "Plan tomorrow"
    // link rather than a specific "Make room for..." suggestion.
    activityId: activityIdField,
  },
  // Intentional Day Builder V1 (brief section 36) -- intentionCategory/
  // activityId/dayPhase reuse the exact same closed vocabularies My Day V1
  // already defined (myDayIntentionCategoryField/activityIdField/
  // myDayDayPhaseField), not third copies. Never a resolved time, a
  // person's name, or reason text (all already excluded by
  // FORBIDDEN_METADATA_KEYS as defense-in-depth, and there's no free-text
  // field here to forbid in the first place).
  DAY_BUILDER_SUGGESTIONS_VIEWED: {
    suggestionCount: { type: 'number', min: 0, max: 3 },
  },
  DAY_BUILDER_SUGGESTION_ADDED: {
    intentionCategory: myDayIntentionCategoryField,
    activityId: activityIdField,
    dayPhase: myDayDayPhaseField,
  },
  DAY_BUILDER_INVITE_SENT: {
    intentionCategory: myDayIntentionCategoryField,
    activityId: activityIdField,
    dayPhase: myDayDayPhaseField,
  },
  DAY_BUILDER_ANOTHER_IDEA: {
    intentionCategory: myDayIntentionCategoryField,
    dayPhase: myDayDayPhaseField,
  },
  // "Not today" (Day Builder dismiss support) -- hasPerson is a boolean
  // only (was this a people-oriented/SHARED suggestion), never the actual
  // person id or name -- FORBIDDEN_METADATA_KEYS already blocks a raw
  // 'name' key as defense-in-depth, but there's no such field offered here
  // to begin with.
  DAY_BUILDER_SUGGESTION_DISMISSED: {
    activityId: activityIdField,
    intentionCategory: myDayIntentionCategoryField,
    hasPerson: { type: 'boolean' },
    dayPhase: myDayDayPhaseField,
  },
  // Home Compactness + Flexible Day Story V1 (brief section 49) --
  // candidateRank is the tapped chip's own index into the already-resolved
  // candidate list (0 = the engine's own top-ranked slot), never a score or
  // a resolved time. hasPerson mirrors DAY_BUILDER_SUGGESTION_DISMISSED's
  // own boolean-only convention above -- never the actual person id/name.
  DAY_BUILDER_SLOT_SELECTED: {
    activityId: activityIdField,
    candidateRank: { type: 'number', min: 0, max: 2 },
    dayPhase: myDayDayPhaseField,
    hasPerson: { type: 'boolean' },
  },
  // Personalization Foundation V1 (brief section 9) -- counts only, never
  // the actual selected priority ids/labels, never a SavedPerson id/name,
  // never birth data or location (all already excluded by
  // FORBIDDEN_METADATA_KEYS as defense-in-depth, and there's no such field
  // offered here to begin with -- the schema's own FieldSchema union has
  // no array type, so "which priorities" is structurally impossible to
  // pass even by mistake, only a count is representable).
  PERSONALIZATION_PROMPT_VIEWED: {},
  PERSONALIZATION_PREFERENCES_SAVED: {
    priorityCount: { type: 'number', min: 0, max: 3 },
    hasPriorityPerson: { type: 'boolean' },
  },
  PERSONALIZATION_PREFERENCES_UPDATED: {
    priorityCount: { type: 'number', min: 0, max: 3 },
    hasPriorityPerson: { type: 'boolean' },
  },
  // Goals V2 Candidate B4 (brief section 3/4) -- bounded categorical/count
  // data only, never a Goal title, activity title, freeform text, or
  // clientRequestId (all already excluded by this file's own FieldSchema
  // union having no free-text field type at all -- structurally
  // impossible to pass even by mistake -- plus FORBIDDEN_METADATA_KEYS as
  // defense-in-depth). templateCategory reuses GoalTemplateCategory's own
  // exact closed vocabulary, not a third copy.
  GOAL_DECOMPOSITION_SHOWN: {
    source: { type: 'enum', values: GOAL_DECOMPOSITION_SOURCE_VALUES },
    templateCategory: goalTemplateCategoryField,
    activityCount: goalActivityCountField,
  },
  GOAL_DECOMPOSITION_CONFIRMED: {
    matchSource: { type: 'enum', values: GOAL_MATCH_SOURCE_VALUES },
    templateCategory: goalTemplateCategoryField,
    initialActivityCount: goalActivityCountField,
    finalActivityCount: goalActivityCountField,
    templateBackedCount: goalActivityCountField,
    freeformCount: goalActivityCountField,
    wasEdited: { type: 'boolean' },
    removedCount: goalActivityCountField,
    renamedCount: goalActivityCountField,
    addedCount: goalActivityCountField,
    rhythmChanged: { type: 'boolean' },
    manualOverrideUsed: { type: 'boolean' },
    scratchUsed: { type: 'boolean' },
    refreshUsed: { type: 'boolean' },
  },
  GOAL_DECOMPOSITION_CREATE_FAILED: {
    errorCategory: { type: 'enum', values: GOAL_CREATE_ERROR_CATEGORY_VALUES },
    matchSource: { type: 'enum', values: GOAL_MATCH_SOURCE_VALUES },
  },
};

export type ProductEventMetadataValue = string | number | boolean;
export type ProductEventMetadata = Record<string, ProductEventMetadataValue>;

export type ProductEventValidationResult =
  | { ok: true; eventName: ProductEventName; metadata: ProductEventMetadata }
  | { ok: false; error: string };

export function validateProductEvent(eventName: string, rawMetadata: unknown): ProductEventValidationResult {
  if (!isProductEventName(eventName)) {
    return { ok: false, error: `Unknown product event name: "${eventName}"` };
  }

  const source =
    rawMetadata && typeof rawMetadata === 'object' && !Array.isArray(rawMetadata)
      ? (rawMetadata as Record<string, unknown>)
      : {};

  const schema = EVENT_METADATA_SCHEMAS[eventName];
  const metadata: ProductEventMetadata = {};

  for (const [key, value] of Object.entries(source)) {
    if (value === undefined) continue;

    if (FORBIDDEN_METADATA_KEYS.has(key.toLowerCase())) {
      return { ok: false, error: `metadata key "${key}" is not allowed on any product event` };
    }

    const fieldSchema = schema[key];
    if (!fieldSchema) {
      return { ok: false, error: `metadata key "${key}" is not allowed on event "${eventName}"` };
    }

    if (fieldSchema.type === 'enum') {
      if (typeof value !== 'string' || !fieldSchema.values.has(value)) {
        return { ok: false, error: `metadata.${key} must be one of: ${Array.from(fieldSchema.values).join(', ')}` };
      }
      metadata[key] = value;
    } else if (fieldSchema.type === 'activityId') {
      // Everyday Moment Rescheduling V1 fix: this used to check
      // isSupportedMuhurthamActivity(), which silently rejected (and
      // dropped) every event carrying an everyday, non-Muhurtham-eligible
      // activityId -- AURA_MOMENT_CREATED/AURA_MOMENT_ALTERNATIVE_CREATED
      // for any Plan-sourced moment (Date Night, Coffee, ...) never
      // actually persisted since Product Structure V2 shipped. Any real
      // catalog activity id is valid metadata here; the events that are
      // genuinely Muhurtham-Finder-only (MUHURTHAM_SEARCH_STARTED/
      // MUHURTHAM_SEARCH_COMPLETED) only ever receive a Muhurtham-eligible
      // id from their own call sites anyway, so this loosening does not
      // weaken validation for those.
      if (typeof value !== 'string' || !FULL_ACTIVITY_CATALOG.some((activity) => activity.id === value)) {
        return { ok: false, error: `metadata.${key} must be a known catalog activity id` };
      }
      metadata[key] = value;
    } else if (fieldSchema.type === 'number') {
      if (typeof value !== 'number' || !Number.isFinite(value) || value < fieldSchema.min || value > fieldSchema.max) {
        return { ok: false, error: `metadata.${key} must be a number between ${fieldSchema.min} and ${fieldSchema.max}` };
      }
      metadata[key] = value;
    } else if (fieldSchema.type === 'boolean') {
      if (typeof value !== 'boolean') {
        return { ok: false, error: `metadata.${key} must be a boolean` };
      }
      metadata[key] = value;
    }
  }

  return { ok: true, eventName, metadata };
}

export interface RecordProductEventInput {
  eventName: string;
  userId?: string | null;
  auraMomentId?: string | null;
  metadata?: unknown;
}

/** The ONLY function server/client tracking code should call to persist a
 * product event -- it validates first, then writes. Deliberately never
 * throws: instrumentation must never break the user-facing action it is
 * attached to (an owner creating an Aura Moment must succeed even if a bug
 * in this file's own schema rejects the tracking call for it). Callers that
 * need to distinguish "bad input" from "recorded" (the client-facing
 * tracking API route, so it can return a 400 during development) should
 * inspect the returned `ok` field themselves rather than relying on a throw. */
export async function recordProductEvent(input: RecordProductEventInput): Promise<ProductEventValidationResult> {
  const validation = validateProductEvent(input.eventName, input.metadata ?? {});
  if (!validation.ok) {
    console.warn(`[productEvents] dropped invalid event: ${validation.error}`);
    return validation;
  }
  try {
    await createProductEvent({
      eventName: validation.eventName,
      userId: input.userId ?? null,
      auraMomentId: input.auraMomentId ?? null,
      metadata: validation.metadata,
    });
  } catch (err) {
    console.warn(`[productEvents] failed to persist event "${validation.eventName}":`, err);
  }
  return validation;
}
