import { Pool, type PoolClient } from 'pg';
import { randomUUID } from 'crypto';
import { derivePlanCompletionHistory } from './planCompletionHistory';
import { validateCaptureTitle } from './captures';
import { parseSchedulingMode, type PlannedActivitySchedulingMode } from './plannedActivitySchedulingMode';
import { toPersistedCompletionRequirement, normalizeGoalActivityCompletionRequirement, type CompletionRequirement } from './goalCompletion';
import {
  normalizeGoalActivityRhythm,
  toPersistedGoalActivityRhythm,
  NONE_GOAL_ACTIVITY_RHYTHM,
  localCalendarWeekStart,
  resolveOccurrenceLocalDate,
  resolveOccurrenceLocalDateOrNull,
  deriveGoalActivityRhythmContributionWithEvidence,
  type GoalActivityRhythmOccurrenceFact,
  type PlannedActivityStatusForRhythm,
  type GoalActivityRhythm,
} from './goalActivityRhythm';
import { evaluateNewOccurrenceEligibility } from './goalActivityOccurrenceCapacity';
import { getDatePartsInTimezone } from './timezone';
import { canonicalizeCivilBirthDate } from './birthDate';
import { toPersistedGoalActivityExecutionSnapshot, fromPersistedGoalActivityExecutionSnapshot, resolveCompletionActualValue } from './goalActivityExecution';

// Sandbox-only substitute for @prisma/client (its engine binary can't be downloaded
// here — see README). Same schema, same Postgres instance, plain SQL. Swap API
// routes back to `prisma.*` calls once you run `npx prisma generate` in an
// environment with normal internet access.

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

/**
 * Day Constructor V1 PR E2 -- the one minimal primitive a caller needs to
 * drive its OWN multi-statement atomic transaction (the same
 * `pool.connect()` + `BEGIN` idiom `logPlannedActivity` below already
 * uses inline), without this module exposing `pool` itself. The caller
 * owns `COMMIT`/`ROLLBACK`/`client.release()` -- both already plain
 * methods on the returned client, needing no further wrapping here.
 */
export async function beginTransaction(): Promise<PoolClient> {
  const client = await pool.connect();
  await client.query('BEGIN');
  return client;
}

/**
 * O5 P2d -- the NARROWEST thing a read needs from the database: a `query` that returns rows. A `Pool`, a `PoolClient` and
 * the snapshot executor below all satisfy it structurally, which is how the SAME read function runs unchanged against the
 * global pool (every existing caller) or inside one coherent snapshot (the decision scheduling context loader). It exposes
 * no `release`, `connect`, `end`, transaction control or event API.
 */
export interface ReadQueryExecutor {
  query(text: string, params?: unknown[]): Promise<{ rows: any[] }>;
}

/**
 * O5 P2d -- runs `read` inside ONE PostgreSQL `REPEATABLE READ` transaction and returns whatever it returns.
 *
 * SNAPSHOT: PostgreSQL takes a REPEATABLE READ transaction's snapshot at its FIRST non-transaction-control statement (the
 * first query `read` issues), not at `BEGIN`; every later statement in the transaction sees exactly the data committed
 * before that first statement and never a concurrent commit.
 *
 * READ-ONLY BY CONSTRUCTION AT THE APPLICATION LEVEL: the executor handed to `read` accepts SELECT / WITH statements only
 * (anything else throws before it reaches the driver), takes no lock beyond what a plain SELECT takes, and stops working
 * the moment `read` settles -- the transaction client never escapes this function, so nothing can be queried against a
 * finished snapshot or against a live transaction from outside. The transaction is committed (it wrote nothing) or rolled
 * back on error, and the connection is always released. Nothing but database reads belongs inside `read`: no CPU-heavy
 * projection, no timing search, no Constructor, no network call (the connection is held for the duration).
 */
export async function withRepeatableReadSnapshot<T>(read: (executor: ReadQueryExecutor) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  let open = true;
  try {
    await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ');
    const executor: ReadQueryExecutor = {
      query: (text, params) => {
        if (!open) throw new Error('snapshot executor used after the snapshot ended');
        if (!/^\s*(SELECT|WITH)\b/i.test(text) || /;\s*\S/.test(text)) throw new Error('the snapshot executor is read-only: a single SELECT / WITH statement only');
        return client.query(text, params as unknown[] | undefined);
      },
    };
    let result: T;
    try {
      result = await read(executor);
    } finally {
      open = false;
    }
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

export interface User {
  id: string;
  email: string;
  cityName: string;
  latitude: number;
  longitude: number;
  timezone: string; // IANA name, e.g. 'Asia/Kolkata'
  createdAt: Date;
  birthDate: Date | null;
  birthTime: string | null;
  birthCityName: string | null;
  birthLatitude: number | null;
  birthLongitude: number | null;
  birthTimezone: string | null;
  remindersEnabled: boolean;
  reminderLeadMinutes: number;
  dayBuilderEnabled: boolean;
  dayBuilderMutedGroups: string[];
  dayBuilderPriorities: string[];
  dayBuilderPriorityPersonIds: string[];
  dayBuilderPrioritiesPromptDismissed: boolean;
  /** Availability Context V1 PR H1 -- `true` only once the user has
   * explicitly saved an availability schedule (even an empty one is a
   * real, deliberate CONFIGURED state -- see availabilityContext.ts's
   * own `AvailabilityConfiguration.configured` doc comment for the exact
   * UNCONFIGURED-vs-CONFIGURED_EMPTY distinction this field exists to
   * carry). Every existing user is `false` by migration default -- never
   * inferred true, never backfilled. Optional here (unlike every other
   * required `User` field) so existing in-memory `User`-shaped test
   * fixtures elsewhere don't need updating for a concept they don't
   * touch -- the SAME convention `PlannedActivity.activityId?` (below)
   * already established for exactly this reason; a real database row
   * always has a concrete `boolean` (`NOT NULL DEFAULT false`), so
   * `undefined` here only ever appears in a fixture that never set it,
   * and is treated identically to `false`. */
  availabilityConfigured?: boolean;
  /** Onboarding V1 PR 1 -- Location Trust Foundation. `null` means this
   * (current, non-birth) location has never been explicitly confirmed --
   * see updateUserLocation's own doc comment for the one place this is
   * ever stamped. Optional here (unlike every other required `User`
   * field) for the same reason `availabilityConfigured` is above: a real
   * database row always has a concrete `Date | null` (nullable column,
   * no NOT NULL), so `undefined` only appears in an existing in-memory
   * fixture that predates this column, and is treated identically to
   * `null` (never confirmed) everywhere this field is read. */
  locationConfirmedAt?: Date | null;
  /** Onboarding V1 PR 2 -- First-Run Reliability Correction. `null` means
   * the Welcome/Confirm Location/Recommendation journey has never been
   * resolved -- see markOnboardingResolved's own doc comment for the one
   * place this is ever stamped. Optional here for the same reason
   * `locationConfirmedAt` is above. */
  onboardingResolvedAt?: Date | null;
  /** Daily Rhythm V1 PR DR1 -- Preferences Foundation. Both null is the
   * ONLY unconfigured state, the default for every row -- see
   * setDailyWorkPreferences/clearDailyWorkPreferences below for the
   * one place these are ever written, always together. Optional here for
   * the same reason `availabilityConfigured`/`locationConfirmedAt` are
   * above. NOT read by any scheduling/recommendation code in this PR. */
  dailyRhythmWorkStart?: string | null;
  dailyRhythmWorkEnd?: string | null;
  /** Weekday set, 0=Sunday..6=Saturday (same convention as
   * UserAvailabilityPeriod.weekday). Empty array by default; a real
   * database row always has a concrete `number[]` (NOT NULL DEFAULT
   * '{}'), so `undefined` here only appears in a fixture that predates
   * this column and is treated identically to an empty array. */
  dailyRhythmWorkDays?: number[];
}

export interface CustomCity {
  id: string;
  userId: string;
  cityName: string;
  latitude: number;
  longitude: number;
  timezone: string;
  createdAt: Date;
}

export async function getCustomCitiesForUser(userId: string): Promise<CustomCity[]> {
  const result = await pool.query(
    `SELECT id, "userId", "cityName", latitude, longitude, timezone, "createdAt"
     FROM "CustomCity"
     WHERE "userId" = $1
     ORDER BY "createdAt" DESC`,
    [userId]
  );
  return result.rows;
}

export async function saveCustomCityForUser(
  userId: string,
  city: { cityName: string; latitude: number; longitude: number; timezone: string }
): Promise<CustomCity> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "CustomCity" (id, "userId", "cityName", latitude, longitude, timezone)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT ("userId", "cityName")
     DO UPDATE SET latitude = EXCLUDED.latitude, longitude = EXCLUDED.longitude, timezone = EXCLUDED.timezone
     RETURNING id, "userId", "cityName", latitude, longitude, timezone, "createdAt"`,
    [id, userId, city.cityName, city.latitude, city.longitude, city.timezone]
  );
  return result.rows[0];
}

export async function updateBirthProfile(
  userId: string,
  input: {
    birthDate: string; // 'YYYY-MM-DD'
    birthTime: string; // 'HH:MM'
    birthCityName: string;
    birthLatitude: number;
    birthLongitude: number;
    birthTimezone: string;
  }
): Promise<User> {
  const result = await pool.query(
    `UPDATE "User" SET "birthDate" = $2, "birthTime" = $3, "birthCityName" = $4,
       "birthLatitude" = $5, "birthLongitude" = $6, "birthTimezone" = $7
     WHERE id = $1 RETURNING *`,
    // B2: the civil date is stored as an EXPLICIT UTC-midnight surrogate (see birthDate.ts) -- never as a bare date string that PostgreSQL would resolve in its session TimeZone.
    [userId, canonicalizeCivilBirthDate(input.birthDate), input.birthTime, input.birthCityName, input.birthLatitude, input.birthLongitude, input.birthTimezone]
  );
  return result.rows[0];
}

export type SavedPersonRelationshipType = 'PARTNER' | 'SPOUSE' | 'FAMILY' | 'FRIEND' | 'OTHER';

export interface SavedPerson {
  id: string;
  ownerUserId: string;
  name: string;
  relationshipType: SavedPersonRelationshipType;
  birthDate: Date;
  birthTime: string;
  birthTimezone: string;
  birthCityName: string | null;
  birthLatitude: number | null;
  birthLongitude: number | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface SavedPersonInput {
  name: string;
  relationshipType: SavedPersonRelationshipType;
  birthDate: string; // 'YYYY-MM-DD'
  birthTime: string; // 'HH:MM'
  birthTimezone: string;
  birthCityName?: string;
  birthLatitude?: number;
  birthLongitude?: number;
}

/** All CRUD below is scoped by ownerUserId on every query -- never by id
 * alone -- so a user can never read, update, or delete another user's
 * SavedPerson (brief section 3: ownership is enforced here, at the data
 * layer, not just in the route). Mirrors cancelPlannedActivity()'s
 * `WHERE id = $1 AND "userId" = $2` pattern below. */
export async function listSavedPeople(ownerUserId: string): Promise<SavedPerson[]> {
  const result = await pool.query(
    `SELECT * FROM "SavedPerson" WHERE "ownerUserId" = $1 ORDER BY name ASC`,
    [ownerUserId]
  );
  return result.rows;
}

export async function getSavedPersonForOwner(ownerUserId: string, personId: string): Promise<SavedPerson | null> {
  const result = await pool.query(
    `SELECT * FROM "SavedPerson" WHERE id = $1 AND "ownerUserId" = $2`,
    [personId, ownerUserId]
  );
  return result.rows[0] ?? null;
}

export async function createSavedPerson(ownerUserId: string, input: SavedPersonInput): Promise<SavedPerson> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "SavedPerson"
       (id, "ownerUserId", name, "relationshipType", "birthDate", "birthTime", "birthTimezone", "birthCityName", "birthLatitude", "birthLongitude")
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
     RETURNING *`,
    [
      id,
      ownerUserId,
      input.name,
      input.relationshipType,
      canonicalizeCivilBirthDate(input.birthDate), // B2: explicit UTC-midnight surrogate, never a bare date string
      input.birthTime,
      input.birthTimezone,
      input.birthCityName ?? null,
      input.birthLatitude ?? null,
      input.birthLongitude ?? null,
    ]
  );
  return result.rows[0];
}

export async function updateSavedPerson(ownerUserId: string, personId: string, input: SavedPersonInput): Promise<SavedPerson> {
  const result = await pool.query(
    `UPDATE "SavedPerson"
     SET name = $3, "relationshipType" = $4, "birthDate" = $5, "birthTime" = $6,
         "birthTimezone" = $7, "birthCityName" = $8, "birthLatitude" = $9, "birthLongitude" = $10,
         "updatedAt" = now()
     WHERE id = $1 AND "ownerUserId" = $2
     RETURNING *`,
    [
      personId,
      ownerUserId,
      input.name,
      input.relationshipType,
      canonicalizeCivilBirthDate(input.birthDate), // B2: explicit UTC-midnight surrogate, never a bare date string
      input.birthTime,
      input.birthTimezone,
      input.birthCityName ?? null,
      input.birthLatitude ?? null,
      input.birthLongitude ?? null,
    ]
  );
  if (result.rows.length === 0) throw new Error('Person not found.');
  return result.rows[0];
}

export async function deleteSavedPerson(ownerUserId: string, personId: string): Promise<void> {
  const result = await pool.query(
    `DELETE FROM "SavedPerson" WHERE id = $1 AND "ownerUserId" = $2`,
    [personId, ownerUserId]
  );
  if (result.rowCount === 0) throw new Error('Person not found.');
}

export type AuraMomentScope = 'GENERAL' | 'PERSONAL' | 'SHARED';
/** Product Structure V2 -- where the selected timing came from. Every
 * pre-V2 row is backfilled to 'MUHURTHAM' (see migration 0020's doc
 * comment) since that was the only creation path until this PR. */
export type AuraMomentSource = 'PLAN' | 'MUHURTHAM';
export type AuraMomentStatus = 'ACTIVE' | 'REVOKED';
export type AuraMomentResponseState = 'ACCEPTED' | 'ANOTHER_TIME';
/** Structured recipient preference (Aura Moment Rescheduling), only ever
 * meaningful alongside responseState = 'ANOTHER_TIME'. Deliberately small
 * and closed -- no free text in V1 (brief section 2). */
export type AuraMomentAlternativePreference = 'EARLIER' | 'LATER' | 'DIFFERENT_DAY' | 'NO_PREFERENCE';

export interface AuraMoment {
  id: string;
  ownerUserId: string;
  publicToken: string;
  scope: AuraMomentScope;
  source: AuraMomentSource;
  activityId: string;
  activityTitle: string;
  activityIcon: string | null;
  startAt: Date;
  endAt: Date;
  timezone: string;
  /** Event Location AuraMoment Persistence V1 -- the human-readable name of
   * the Event Location that produced this moment's timing, or null when the
   * owner's Timing Location was used (see the schema's own doc comment). */
  locationName: string | null;
  savedPersonId: string | null;
  sharedPersonDisplayName: string | null;
  senderDisplayName: string | null;
  ratingLabel: string | null;
  explanationSnapshot: string | null;
  status: AuraMomentStatus;
  responseState: AuraMomentResponseState | null;
  responsePreference: AuraMomentAlternativePreference | null;
  respondedAt: Date | null;
  /** Lineage: set when this moment was created via "Suggest this" on an
   * earlier moment -- see revokeAuraMoment/createAuraMoment's doc comments.
   * The referenced moment is never mutated; this is a one-way pointer. */
  previousMomentId: string | null;
  /** Aura Reminders V1 dedup linkage (brief section 7) -- set only when the
   * client already knows this Moment represents the same real-world event
   * as an existing PlannedActivity (see PlanWithAuraView's handleMakeMoment).
   * When set, deriveAuraReminders() skips the linked Plan's own reminder. */
  plannedActivityId: string | null;
  /** Aura Updates V1 -- when the OWNER last saw this moment's response.
   * "Unread" is ALWAYS derived by comparing this to respondedAt (see
   * lib/auraUpdates.ts), never read as a bare boolean. */
  ownerSeenResponseAt: Date | null;
  /** Product Instrumentation V1 -- set once, on the first successful PUBLIC
   * open of this moment (see markAuraMomentFirstOpened below). Never reset,
   * never touched by refreshes after the first. Exists purely so
   * AURA_MOMENT_OPENED can be recorded exactly once per moment without
   * fingerprinting the anonymous recipient. */
  firstOpenedAt: Date | null;
  createdAt: Date;
  expiresAt: Date | null;
}

export interface CreateAuraMomentInput {
  ownerUserId: string;
  publicToken: string;
  scope: AuraMomentScope;
  source: AuraMomentSource;
  activityId: string;
  activityTitle: string;
  activityIcon: string | null;
  startAt: Date;
  endAt: Date;
  timezone: string;
  /** Event Location AuraMoment Persistence V1 -- see AuraMoment's own field
   * doc comment. The route is responsible for deriving this (and timezone)
   * together from a validated eventLocation snapshot, or both fall back to
   * null/user.timezone together; this function persists whatever it's
   * given verbatim. Optional (defaults to null) so every pre-existing
   * caller that doesn't yet know about Event Location keeps compiling
   * unchanged -- same convention as previousMomentId/plannedActivityId
   * below. */
  locationName?: string | null;
  savedPersonId: string | null;
  sharedPersonDisplayName: string | null;
  senderDisplayName: string | null;
  ratingLabel: string | null;
  explanationSnapshot: string | null;
  expiresAt: Date | null;
  previousMomentId?: string | null;
  /** Aura Reminders V1 dedup linkage (brief section 7) -- see AuraMoment's
   * own field doc comment. Omitted/null for the overwhelming majority of
   * moments, which have no known linked Plan. */
  plannedActivityId?: string | null;
}

/** Every write/read below that's scoped to an owner filters by ownerUserId,
 * never by id/token alone -- same ownership discipline as SavedPerson above.
 * getAuraMomentByToken() is the one deliberate exception: it's the PUBLIC
 * bearer-access lookup (anyone holding the token can read the row), used by
 * the public page and the public response endpoint, never by owner-scoped
 * routes. */
export async function createAuraMoment(input: CreateAuraMomentInput): Promise<AuraMoment> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "AuraMoment"
       (id, "ownerUserId", "publicToken", scope, source, "activityId", "activityTitle", "activityIcon",
        "startAt", "endAt", timezone, "locationName", "savedPersonId", "sharedPersonDisplayName", "senderDisplayName",
        "ratingLabel", "explanationSnapshot", "expiresAt", "previousMomentId", "plannedActivityId")
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
     RETURNING *`,
    [
      id,
      input.ownerUserId,
      input.publicToken,
      input.scope,
      input.source,
      input.activityId,
      input.activityTitle,
      input.activityIcon,
      input.startAt,
      input.endAt,
      input.timezone,
      input.locationName ?? null,
      input.savedPersonId,
      input.sharedPersonDisplayName,
      input.senderDisplayName,
      input.ratingLabel,
      input.explanationSnapshot,
      input.expiresAt,
      input.previousMomentId ?? null,
      input.plannedActivityId ?? null,
    ]
  );
  return result.rows[0];
}

export async function listAuraMomentsForOwner(ownerUserId: string): Promise<AuraMoment[]> {
  const result = await pool.query(
    `SELECT * FROM "AuraMoment" WHERE "ownerUserId" = $1 ORDER BY "createdAt" DESC`,
    [ownerUserId]
  );
  return result.rows;
}

/** PUBLIC lookup -- by publicToken only, no ownership filter. This is the
 * bearer-access read every recipient (and the public response endpoint)
 * uses; it deliberately does not care who owns the row. */
export async function getAuraMomentByToken(publicToken: string): Promise<AuraMoment | null> {
  const result = await pool.query(
    `SELECT * FROM "AuraMoment" WHERE "publicToken" = $1`,
    [publicToken]
  );
  return result.rows[0] ?? null;
}

export async function getAuraMomentForOwner(ownerUserId: string, publicToken: string): Promise<AuraMoment | null> {
  const result = await pool.query(
    `SELECT * FROM "AuraMoment" WHERE "publicToken" = $1 AND "ownerUserId" = $2`,
    [publicToken, ownerUserId]
  );
  return result.rows[0] ?? null;
}

/** Notification Delivery Readiness V1 -- ownership-scoped lookup by
 * INTERNAL id (not publicToken). Needed because AuraReminder.scheduledItemId
 * for a MOMENT_APPROACHING reminder is the moment's internal id (see
 * lib/auraReminders.ts), and POST /api/reminders/seen must verify that id
 * belongs to the requesting owner before ever writing a ReminderAttention
 * row -- never trust a client-supplied id where it can be resolved and
 * checked (same discipline as getPlannedActivityForOwner). */
export async function getAuraMomentByIdForOwner(ownerUserId: string, momentId: string): Promise<AuraMoment | null> {
  const result = await pool.query(
    `SELECT * FROM "AuraMoment" WHERE id = $1 AND "ownerUserId" = $2`,
    [momentId, ownerUserId]
  );
  return result.rows[0] ?? null;
}

export async function revokeAuraMoment(ownerUserId: string, publicToken: string): Promise<AuraMoment> {
  const result = await pool.query(
    `UPDATE "AuraMoment" SET status = 'REVOKED' WHERE "publicToken" = $1 AND "ownerUserId" = $2 RETURNING *`,
    [publicToken, ownerUserId]
  );
  if (result.rows.length === 0) throw new Error('Moment not found.');
  return result.rows[0];
}

/** Permanently removes a moment from the list -- scoped to REVOKED only, so
 * a moment is always revoked first (the deliberate, visible "this link no
 * longer works" step) before it can be cleared away. Safe to hard-delete:
 * previousMomentId/ProductEvent.auraMomentId both reference AuraMoment with
 * ON DELETE SET NULL, so this never breaks lineage or analytics rows. */
export async function deleteAuraMoment(ownerUserId: string, publicToken: string): Promise<void> {
  const result = await pool.query(
    `DELETE FROM "AuraMoment" WHERE "publicToken" = $1 AND "ownerUserId" = $2 AND status = 'REVOKED'`,
    [publicToken, ownerUserId]
  );
  if (result.rowCount === 0) throw new Error('Moment not found or cannot be removed.');
}

/** PUBLIC write -- by publicToken only. Guarded entirely in SQL (status must
 * still be ACTIVE and, if set, expiresAt must not have passed) so the
 * check-then-act window can't race a concurrent revoke/expiry -- the caller
 * (resolvePublicAuraMoment in lib/auraMoments.ts) separately determines the
 * exact reason for a rejection (not found / revoked / expired) for the HTTP
 * response, but this function's own guard is the actual source of truth. */
export async function respondToAuraMoment(publicToken: string, response: AuraMomentResponseState, preference: AuraMomentAlternativePreference | null = null): Promise<AuraMoment | null> {
  const result = await pool.query(
    `UPDATE "AuraMoment"
     SET "responseState" = $2, "responsePreference" = $3, "respondedAt" = now()
     WHERE "publicToken" = $1 AND status = 'ACTIVE' AND ("expiresAt" IS NULL OR "expiresAt" > now())
     RETURNING *`,
    [publicToken, response, preference]
  );
  return result.rows[0] ?? null;
}

/** PUBLIC-safe existence check -- "has ANY moment been created via 'Suggest
 * this' with this one as its previousMomentId", never the successor's own
 * token/id (brief section 15: "only if that can be done without leaking the
 * new token publicly"). Used by resolvePublicAuraMoment() so the ORIGINAL
 * link can say "a new time was suggested" without exposing where. */
export async function hasSuccessorMoment(momentId: string): Promise<boolean> {
  const result = await pool.query(
    `SELECT 1 FROM "AuraMoment" WHERE "previousMomentId" = $1 LIMIT 1`,
    [momentId]
  );
  return result.rows.length > 0;
}

/** Bulk counterpart to hasSuccessorMoment() -- one query for "which of this
 * owner's moments already have a successor", used by the Aura Updates
 * summary so it never does one query per moment. */
export async function listMomentIdsWithSuccessorForOwner(ownerUserId: string): Promise<Set<string>> {
  const result = await pool.query(
    `SELECT DISTINCT "previousMomentId" FROM "AuraMoment" WHERE "ownerUserId" = $1 AND "previousMomentId" IS NOT NULL`,
    [ownerUserId]
  );
  return new Set(result.rows.map((row) => row.previousMomentId as string));
}

/** The ONLY moments Aura Updates cares about: this owner's, still ACTIVE
 * (a revoked moment is a closed matter, not an update -- see
 * lib/auraUpdates.ts), with an actual response, most-recently-responded
 * first, capped at `limit`. Scoped in SQL rather than filtering
 * listAuraMomentsForOwner()'s full history in application code -- cheap,
 * ordinary retrieval (brief section 17), backed by migration 0018's partial
 * index on exactly this shape. */
export async function listRecentRespondedAuraMomentsForOwner(ownerUserId: string, limit: number): Promise<AuraMoment[]> {
  const result = await pool.query(
    `SELECT * FROM "AuraMoment"
     WHERE "ownerUserId" = $1 AND status = 'ACTIVE' AND "responseState" IS NOT NULL
     ORDER BY "respondedAt" DESC
     LIMIT $2`,
    [ownerUserId, limit]
  );
  return result.rows;
}

/** Owner-authenticated only (brief section 6: "Do not use the public
 * bearer-link response endpoint"). Ownership-scoped like revokeAuraMoment --
 * a token that doesn't belong to this owner silently updates nothing. */
export async function markAuraMomentResponseSeen(ownerUserId: string, publicToken: string): Promise<AuraMoment | null> {
  const result = await pool.query(
    `UPDATE "AuraMoment" SET "ownerSeenResponseAt" = now() WHERE "publicToken" = $1 AND "ownerUserId" = $2 RETURNING *`,
    [publicToken, ownerUserId]
  );
  return result.rows[0] ?? null;
}

/** PUBLIC write -- by publicToken only, same bearer-access shape as
 * respondToAuraMoment. Idempotent: only ever sets firstOpenedAt when it was
 * previously NULL, so `result.rows.length > 0` tells the caller whether this
 * was genuinely the FIRST open (the caller uses that to decide whether to
 * record an AURA_MOMENT_OPENED product event -- see app/moment/[token]/page.tsx). */
export async function markAuraMomentFirstOpened(publicToken: string): Promise<AuraMoment | null> {
  const result = await pool.query(
    `UPDATE "AuraMoment" SET "firstOpenedAt" = now() WHERE "publicToken" = $1 AND "firstOpenedAt" IS NULL RETURNING *`,
    [publicToken]
  );
  return result.rows[0] ?? null;
}

export interface HabitLogRow {
  id: string;
  userId: string;
  activityTitle: string;
  // Prospective Canonical Activity Identity V1 -- the canonical
  // packages/recommendation ActivityProfile.id this log was explicitly
  // associated with at log time, or null/undefined when no canonical
  // identity was known (manual/free-text logs, and every row created
  // before this field existed). Optional (matching notes/logSource/
  // activitySignificance's own convention on this interface) so existing
  // in-memory HabitLogRow-shaped fixtures elsewhere in the codebase don't
  // need updating for a concept they don't touch. Never inferred/
  // backfilled -- see the column's own migration comment
  // (apps/web/prisma/migrations/0030_habit_log_activity_id).
  activityId?: string | null;
  activeWindow: string;
  logTimestamp: Date;
  logMinuteOfDay: number;
  durationMinutes: number;
  notes?: string | null;
  logSource?: 'AURA_PLANNED' | 'AURA_DO_NOW' | 'MANUAL' | 'OVERRIDE_CAUTION';
  activitySignificance?: 'LOW' | 'MEDIUM' | 'HIGH';
  // Good Right Now / Log Activity Failure State Correctness V1 -- see the
  // column's own migration comment (0032). Optional for the same reason
  // as activityId above: existing fixtures/callers that don't touch this
  // concept need no changes.
  clientRequestId?: string | null;
}

export interface Habit {
  id: string;
  userId: string;
  title: string;
  category: string;
  targetWindowType: string;
  currentStreak: number;
  longestStreak: number;
  createdAt: Date;
  archivedAt: Date | null;
}

export interface DailyReflection {
  id: string;
  userId: string;
  reflectionDate: Date;
  outputLevel: 'LOW' | 'MODERATE' | 'PEAK_FLOW';
  followedGuidance: boolean;
  notes?: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface PlannedActivity {
  id: string;
  userId: string;
  title: string;
  activityType: string | null;
  icon: string | null;
  // Planned Activity Canonical Identity Propagation V1 -- the canonical
  // packages/recommendation/src/personalizedTasks.ts ActivityProfile.id
  // this Plan was explicitly created from, or null when no canonical
  // identity was known. Never inferred/backfilled -- see the column's own
  // migration comment (apps/web/prisma/migrations/0031). Optional (matching
  // HabitLogRow.activityId's own convention) so existing in-memory
  // PlannedActivity-shaped fixtures elsewhere don't need updating for a
  // concept they don't touch.
  activityId?: string | null;
  status: 'UPCOMING' | 'LOGGED' | 'CANCELLED' | 'SKIPPED' | 'MOVED';
  plannedStartAt: Date;
  plannedEndAt: Date;
  durationMinutes: number;
  windowType: string;
  windowLabel: string | null;
  matchLabel: string | null;
  score: number | null;
  recommendation: string | null;
  calendarUrl: string | null;
  loggedAt: Date | null;
  skippedAt?: Date | null;
  /** Set only on a Move successor: the (now MOVED) plan this one replaces. */
  rescheduledFromPlanId?: string | null;
  /** Insights V1 PR 1 -- set only on THIS row, at the instant its own
   * status transitions UPCOMING -> MOVED (planMove.ts's applyMoveWrites).
   * NULL = never moved, or moved before this column existed (never
   * backfilled). Never re-stamped by a replayed Move. */
  movedAt?: Date | null;
  /** F1: the persisted scheduling constraint (see plannedActivitySchedulingMode.ts). null/absent = legacy/unknown = protected. */
  schedulingMode?: PlannedActivitySchedulingMode | null;
  habitLogId: string | null;
  /** Event Location Plan Persistence V1 -- immutable snapshot of the Event
   * Location that produced this plan's timing, or both null when the
   * Timing Location was used (see the schema's own doc comment). */
  eventTimezone: string | null;
  eventLocationName: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreatePlannedActivityInput {
  userId: string;
  title: string;
  activityType?: string | null;
  icon?: string | null;
  // Planned Activity Canonical Identity Propagation V1 -- an
  // already-validated canonical activity id, or omitted/null when none is
  // known. This function performs NO catalog lookup/validation itself --
  // that belongs at the API/service boundary (apps/web/app/api/plans/route.ts),
  // the same layer that already validates title/windowType/etc. before
  // calling this DB helper. Persisted exactly as given.
  activityId?: string | null;
  plannedStartAt: Date;
  plannedEndAt: Date;
  durationMinutes: number;
  windowType: string;
  windowLabel?: string | null;
  matchLabel?: string | null;
  score?: number | null;
  recommendation?: string | null;
  calendarUrl?: string | null;
  /** Both present together, or both absent -- the caller (route.ts) is
   * responsible for that pairing; this function persists whatever it's
   * given verbatim. */
  eventTimezone?: string | null;
  eventLocationName?: string | null;
  /** F1: persisted after `parseSchedulingMode` (anything unrecognised becomes null = protected). Omitted = null: this helper never grants FLEXIBLE by default; each creation path states its own mode. */
  schedulingMode?: PlannedActivitySchedulingMode | null;
}

export async function createHabit(input: {
  userId: string;
  title: string;
  category: string;
  targetWindowType: string;
}): Promise<Habit> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "Habit" (id, "userId", title, category, "targetWindowType")
     VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [id, input.userId, input.title, input.category, input.targetWindowType]
  );
  return result.rows[0];
}

export async function listHabits(userId: string): Promise<Habit[]> {
  const result = await pool.query(
    `SELECT * FROM "Habit" WHERE "userId" = $1 AND "archivedAt" IS NULL ORDER BY "createdAt"`,
    [userId]
  );
  return result.rows;
}

export async function archiveHabit(userId: string, habitId: string): Promise<void> {
  await pool.query(`UPDATE "Habit" SET "archivedAt" = now() WHERE id = $1 AND "userId" = $2`, [habitId, userId]);
}

/**
 * Logs a completion for a specific recurring habit and updates its streak.
 * Distinct from createHabitLog (the fixed 3-card flow) — this one tracks
 * per-habit consecutive-day streaks, not just a flat activity log. Idempotent
 * per calendar day: logging the same habit twice today doesn't double-count
 * or re-bump the streak.
 */
export async function logHabitCompletion(
  userId: string,
  habitId: string,
  activeWindow: string,
  logMinuteOfDay: number
): Promise<Habit> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const habitRes = await client.query(`SELECT * FROM "Habit" WHERE id = $1 AND "userId" = $2 FOR UPDATE`, [
      habitId,
      userId,
    ]);
    if (habitRes.rows.length === 0) throw new Error('Habit not found.');
    const habit: Habit = habitRes.rows[0];

    const todayLog = await client.query(
      `SELECT 1 FROM "HabitLog" WHERE "habitId" = $1 AND "logTimestamp"::date = CURRENT_DATE LIMIT 1`,
      [habitId]
    );
    if (todayLog.rows.length > 0) {
      await client.query('COMMIT');
      return habit; // already logged today — no-op, don't double-bump the streak
    }

    const yesterdayLog = await client.query(
      `SELECT 1 FROM "HabitLog" WHERE "habitId" = $1 AND "logTimestamp"::date = CURRENT_DATE - INTERVAL '1 day' LIMIT 1`,
      [habitId]
    );
    const newStreak = yesterdayLog.rows.length > 0 ? habit.currentStreak + 1 : 1;
    const newLongest = Math.max(habit.longestStreak, newStreak);

    await client.query(
      `INSERT INTO "HabitLog" (id, "userId", "habitId", "activityTitle", "activeWindow", "logMinuteOfDay", "logSource", "activitySignificance")
       VALUES ($1, $2, $3, $4, $5, $6, 'MANUAL', 'MEDIUM')`,
      [randomUUID(), userId, habitId, habit.title, activeWindow, logMinuteOfDay]
    );

    const updated = await client.query(
      `UPDATE "Habit" SET "currentStreak" = $2, "longestStreak" = $3 WHERE id = $1 RETURNING *`,
      [habitId, newStreak, newLongest]
    );

    await client.query('COMMIT');
    return updated.rows[0];
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

export async function listPlannedActivities(userId: string): Promise<PlannedActivity[]> {
  const result = await pool.query(
    `SELECT *
     FROM "PlannedActivity"
     WHERE "userId" = $1 AND status NOT IN ('CANCELLED', 'SKIPPED', 'MOVED')
     ORDER BY
       CASE WHEN status = 'UPCOMING' THEN 0 ELSE 1 END,
       "plannedStartAt" ASC,
       "createdAt" DESC`,
    [userId]
  );
  return result.rows;
}

/**
 * Remaining-Day Recomposition V1 PR F2 -- READ-ONLY. Which of the given plans currently have an ACTIVE, unexpired
 * shared AuraMoment linked -- the exact restriction `movePlannedActivity` enforces (`HAS_LINKED_MOMENT`), evaluated
 * against a caller-supplied instant so a proposal is reproducible. Such a plan cannot be moved, so recomposition
 * must not reconsider it.
 */
export async function listPlanIdsWithActiveMoment(planIds: readonly string[], now: Date, executor: QueryExecutor = pool): Promise<Set<string>> {
  if (planIds.length === 0) return new Set();
  const result = await executor.query(
    `SELECT DISTINCT "plannedActivityId" FROM "AuraMoment"
     WHERE "plannedActivityId" = ANY($1::text[]) AND status = 'ACTIVE' AND ("expiresAt" IS NULL OR "expiresAt" > $2)`,
    [planIds, now]
  );
  return new Set(result.rows.map((row) => row.plannedActivityId as string));
}

export async function listAllPlannedActivitiesForExport(userId: string): Promise<PlannedActivity[]> {
  const result = await pool.query(
    `SELECT *
     FROM "PlannedActivity"
     WHERE "userId" = $1
     ORDER BY "plannedStartAt" DESC, "createdAt" DESC`,
    [userId]
  );
  return result.rows;
}

/** Ownership-scoped single-row lookup -- used by POST /api/aura-moments to
 * validate a client-supplied plannedActivityId (Aura Reminders V1 dedup
 * linkage, brief section 7) actually belongs to the requesting owner before
 * ever writing it onto an AuraMoment row. */
export async function getPlannedActivityForOwner(userId: string, planId: string, executor: QueryExecutor = pool): Promise<PlannedActivity | null> {
  const result = await executor.query(`SELECT * FROM "PlannedActivity" WHERE id = $1 AND "userId" = $2`, [planId, userId]);
  return result.rows[0] ?? null;
}

// ── Plan creation idempotency (Intentional Day Builder V1, brief section
// 20) ──────────────────────────────────────────────────────────────────
// Same "claim, then fill" design as GuestConversionRedemption below, keyed
// by (userId, clientRequestId) rather than a globally-unique token hash --
// see migration 0025's own doc comment for why.

export interface PlanCreationClaim {
  userId: string;
  clientRequestId: string;
  plannedActivityId: string | null;
  createdAt: Date;
}

/**
 * `executor` (pre-commit review addition, Day Constructor V1 PR E2) --
 * OPTIONAL, defaults to `pool`, so every existing call site (all of which
 * omit it) keeps its exact current pool-based behavior unchanged. Passing
 * a `PoolClient` (from `pool.connect()`, mid-transaction) lets a caller
 * that needs this claim check/write to participate in ITS OWN atomic
 * transaction do so -- `Pool` and `PoolClient` share the identical
 * `query(text, params)` signature, so no branching is needed here.
 */
type QueryExecutor = Pool | PoolClient;

export async function getPlanCreationClaim(userId: string, clientRequestId: string, executor: QueryExecutor = pool): Promise<PlanCreationClaim | null> {
  const result = await executor.query(
    `SELECT * FROM "PlanCreationIdempotency" WHERE "userId" = $1 AND "clientRequestId" = $2`,
    [userId, clientRequestId]
  );
  return result.rows[0] ?? null;
}

/**
 * Day Constructor V1 PR E2 (pre-commit review fix) -- discovers EVERY
 * `PlanCreationIdempotency` row for `userId` whose own `clientRequestId`
 * column value starts with `prefix`, exactly. Built for one caller: Day
 * Constructor acceptance derives one composite `clientRequestId` value
 * PER accepted item (`day-constructor:<len>:<clientRequestId>:<intentId>`,
 * see `deriveAcceptanceIdempotencyKey`), all sharing one common,
 * deterministic prefix -- this is the read-side counterpart that lets a
 * caller discover the COMPLETE stored set for one acceptance, not just
 * whichever keys it already knows to ask about.
 *
 * DELIBERATELY uses `left("clientRequestId", length($2)) = $2` -- exact
 * substring EQUALITY, never `LIKE`/`ILIKE`. This is the reason `%`/`_`
 * (SQL `LIKE` wildcard characters), literal `:`, unicode, or an
 * arbitrarily long `clientRequestId` can never cause a wildcard-ambiguity
 * false match: `left()`/`=` perform plain byte-for-byte comparison of a
 * fixed-length prefix, with no pattern-matching semantics at all. Both
 * `prefix` and its own length are passed as ordinary, fully-parameterized
 * query arguments -- never interpolated into the query text.
 */
export async function findPlanCreationClaimsByPrefix(userId: string, prefix: string, executor: QueryExecutor = pool): Promise<PlanCreationClaim[]> {
  const result = await executor.query(
    `SELECT * FROM "PlanCreationIdempotency" WHERE "userId" = $1 AND left("clientRequestId", length($2)) = $2`,
    [userId, prefix]
  );
  return result.rows;
}

/** Returns true if THIS call won the claim (caller should proceed to create
 * the Plan, then call fillPlanCreationClaim); false if another request
 * already holds an unfilled claim. Same semantics as
 * claimGuestConversionToken below. */
export async function claimPlanCreation(userId: string, clientRequestId: string, executor: QueryExecutor = pool): Promise<boolean> {
  const result = await executor.query(
    `INSERT INTO "PlanCreationIdempotency" ("userId", "clientRequestId") VALUES ($1, $2) ON CONFLICT ("userId", "clientRequestId") DO NOTHING RETURNING *`,
    [userId, clientRequestId]
  );
  return result.rows.length > 0;
}

export async function fillPlanCreationClaim(userId: string, clientRequestId: string, plannedActivityId: string, executor: QueryExecutor = pool): Promise<void> {
  await executor.query(
    `UPDATE "PlanCreationIdempotency" SET "plannedActivityId" = $1 WHERE "userId" = $2 AND "clientRequestId" = $3`,
    [plannedActivityId, userId, clientRequestId]
  );
}

// ── Day Builder dismissals ("Not today", migration 0026) ─────────────────
// See that migration's own doc comment for why personId is a '' sentinel
// rather than nullable.

export interface DayBuilderDismissal {
  userId: string;
  localDate: string;
  activityId: string;
  personId: string;
  createdAt: Date;
}

/** Idempotent by design (ON CONFLICT DO NOTHING on the composite primary
 * key) -- a double-tap on "Not today" is a no-op, not an error. */
export async function createDayBuilderDismissal(userId: string, localDate: string, activityId: string, personId: string | null): Promise<void> {
  await pool.query(
    `INSERT INTO "DayBuilderDismissal" ("userId", "localDate", "activityId", "personId") VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`,
    [userId, localDate, activityId, personId ?? '']
  );
}

/** Bounded to one local day, same discipline as every other Day Builder
 * read (brief section 42's "bounded reads only") -- never a full history
 * scan. */
export async function listDayBuilderDismissals(userId: string, localDate: string): Promise<DayBuilderDismissal[]> {
  const result = await pool.query(`SELECT * FROM "DayBuilderDismissal" WHERE "userId" = $1 AND "localDate" = $2`, [userId, localDate]);
  return result.rows;
}

/** No route currently calls this -- a dismissal is meant to expire via
 * real local-day rollover, never deleted in normal product use. Exists so
 * tests using a fixed fake "today" (dayBuilderDb.test.ts) can clean up
 * after themselves rather than leaving a permanent dismissal for that
 * fixed date that would silently affect the next test run. */
export async function deleteDayBuilderDismissalsForDate(userId: string, localDate: string): Promise<void> {
  await pool.query(`DELETE FROM "DayBuilderDismissal" WHERE "userId" = $1 AND "localDate" = $2`, [userId, localDate]);
}

// ── Guest conversion idempotency (Recipient Conversion V1 Hardening, brief
// section 10) ──────────────────────────────────────────────────────────
// See migration 0024's own doc comment for the "claim, then fill" design.

export interface GuestConversionRedemption {
  tokenHash: string;
  userId: string;
  plannedActivityId: string | null;
  createdAt: Date;
}

export async function getGuestConversionRedemption(tokenHash: string): Promise<GuestConversionRedemption | null> {
  const result = await pool.query(`SELECT * FROM "GuestConversionRedemption" WHERE "tokenHash" = $1`, [tokenHash]);
  return result.rows[0] ?? null;
}

/** Atomically claims this token hash. Returns true if THIS call won the
 * claim (caller should proceed to create the Plan, then call
 * fillGuestConversionRedemption); false if another request already holds
 * an unfilled claim (a genuine, sub-second concurrent race -- the caller
 * should re-check getGuestConversionRedemption rather than create a second
 * Plan). A row that already exists WITH a filled plannedActivityId is
 * handled by the caller before this is ever reached (that's the normal
 * "already saved, replay the existing Plan" idempotent-retry path). */
export async function claimGuestConversionToken(tokenHash: string, userId: string): Promise<boolean> {
  const result = await pool.query(
    `INSERT INTO "GuestConversionRedemption" ("tokenHash", "userId") VALUES ($1, $2) ON CONFLICT ("tokenHash") DO NOTHING RETURNING *`,
    [tokenHash, userId]
  );
  return result.rows.length > 0;
}

export async function fillGuestConversionRedemption(tokenHash: string, plannedActivityId: string): Promise<void> {
  await pool.query(`UPDATE "GuestConversionRedemption" SET "plannedActivityId" = $1 WHERE "tokenHash" = $2`, [plannedActivityId, tokenHash]);
}

/** Aura Reminders V1 (brief section 25): a BOUNDED query, not full history
 * -- only plans whose plannedStartAt could plausibly produce an active
 * reminder right now (see lib/auraReminders.ts's REMINDER_GRACE_PERIOD_MINUTES/
 * MAX_REMINDER_LEAD_MINUTES, which the caller uses to compute [from, to]).
 * Only UPCOMING (never LOGGED/CANCELLED -- brief section 8's lifecycle
 * rule applied to Plans). */
export async function listPlannedActivitiesForReminders(userId: string, from: Date, to: Date): Promise<PlannedActivity[]> {
  const result = await pool.query(
    `SELECT * FROM "PlannedActivity"
     WHERE "userId" = $1 AND status = 'UPCOMING' AND "plannedStartAt" BETWEEN $2 AND $3
     ORDER BY "plannedStartAt" ASC`,
    [userId, from, to]
  );
  return result.rows;
}

/** My Day V1 -- the bounded-by-local-day counterpart to
 * listPlannedActivitiesForReminders above. That query exists for a
 * different purpose (only UPCOMING plans that could plausibly produce an
 * active reminder right now) and deliberately excludes LOGGED ones; the
 * daily agenda needs BOTH UPCOMING and LOGGED plans for today (brief
 * section 4), just never CANCELLED. */
export async function listPlannedActivitiesForDay(userId: string, from: Date, to: Date, executor: QueryExecutor = pool): Promise<PlannedActivity[]> {
  const result = await executor.query(
    `SELECT * FROM "PlannedActivity"
     WHERE "userId" = $1 AND status <> 'CANCELLED' AND "plannedStartAt" BETWEEN $2 AND $3
     ORDER BY "plannedStartAt" ASC`,
    [userId, from, to]
  );
  return result.rows;
}

/**
 * Opportunity Scarcity V1 -- O2. Every non-cancelled Plan of this user whose
 * interval OVERLAPS `[from, to)`, regardless of where it starts. Unlike
 * `listPlannedActivitiesForDay` (which selects by `plannedStartAt` only, so a
 * Plan that starts before `from` and ends inside the range is missed), this
 * uses half-open interval overlap: `plannedStartAt < to AND plannedEndAt >
 * from`. Same `status <> 'CANCELLED'` SQL filter; lifecycle (which statuses
 * actually block) is applied by the caller via `isActivePlanBlocker`. READ-ONLY,
 * scoped to `userId`, one query for any range length.
 */
export async function listPlannedActivitiesOverlappingRange(userId: string, from: Date, to: Date, executor: ReadQueryExecutor = pool): Promise<PlannedActivity[]> {
  const result = await executor.query(
    `SELECT * FROM "PlannedActivity"
     WHERE "userId" = $1 AND status <> 'CANCELLED' AND "plannedStartAt" < $3 AND "plannedEndAt" > $2
     ORDER BY "plannedStartAt" ASC`,
    [userId, from, to]
  );
  return result.rows;
}

/** Aura Reminders V1 (brief section 25) -- the AuraMoment counterpart to
 * listPlannedActivitiesForReminders above. Only ACTIVE, unexpired moments
 * (mirrors resolveAuraMomentByToken's own ACTIVE + expiry check) within the
 * bounded [from, to] window; response-state/lineage lifecycle rules (brief
 * section 8/9) are applied by deriveAuraReminders(), not here -- this stays
 * ordinary, cheap retrieval, backed by migration 0021's
 * (ownerUserId, startAt) index. */
export async function listAuraMomentsForReminders(ownerUserId: string, from: Date, to: Date): Promise<AuraMoment[]> {
  const result = await pool.query(
    `SELECT * FROM "AuraMoment"
     WHERE "ownerUserId" = $1 AND status = 'ACTIVE' AND ("expiresAt" IS NULL OR "expiresAt" > now())
       AND "startAt" BETWEEN $2 AND $3
     ORDER BY "startAt" ASC`,
    [ownerUserId, from, to]
  );
  return result.rows;
}

export async function updateUserReminderPrefs(
  userId: string,
  prefs: { remindersEnabled: boolean; reminderLeadMinutes: number }
): Promise<User> {
  const result = await pool.query(
    `UPDATE "User" SET "remindersEnabled" = $2, "reminderLeadMinutes" = $3 WHERE id = $1 RETURNING *`,
    [userId, prefs.remindersEnabled, prefs.reminderLeadMinutes]
  );
  return result.rows[0];
}

/** Intentional Day Builder V1 (brief section 6/35), extended by
 * Personalization Foundation V1 -- same minimal-surface pattern as
 * updateUserReminderPrefs above. mutedGroups/priorities are validated by
 * the caller (route) against their real enum sets before this is ever
 * reached -- this function trusts its input, same discipline as
 * updateUserReminderPrefs. Always the full preference object (same
 * "client sends full merged state" convention already established for
 * enabled+mutedGroups) -- never a partial/COALESCE update. */
export async function updateUserDayBuilderPrefs(
  userId: string,
  prefs: {
    dayBuilderEnabled: boolean;
    dayBuilderMutedGroups: string[];
    dayBuilderPriorities: string[];
    dayBuilderPriorityPersonIds: string[];
    dayBuilderPrioritiesPromptDismissed: boolean;
  }
): Promise<User> {
  const result = await pool.query(
    `UPDATE "User" SET "dayBuilderEnabled" = $2, "dayBuilderMutedGroups" = $3, "dayBuilderPriorities" = $4, "dayBuilderPriorityPersonIds" = $5, "dayBuilderPrioritiesPromptDismissed" = $6 WHERE id = $1 RETURNING *`,
    [userId, prefs.dayBuilderEnabled, prefs.dayBuilderMutedGroups, prefs.dayBuilderPriorities, prefs.dayBuilderPriorityPersonIds, prefs.dayBuilderPrioritiesPromptDismissed]
  );
  return result.rows[0];
}

// ============================================================
// Notification Delivery Readiness V1 -- ReminderAttention (seen state) and
// ReminderDelivery (future Web Push idempotency). See
// lib/reminderAttention.ts / lib/reminderDelivery.ts for the domain logic
// built on top of these; this section is pure persistence.
// ============================================================

export type ReminderScheduledItemType = 'PLANNED_ACTIVITY' | 'AURA_MOMENT';

export interface ReminderAttention {
  id: string;
  userId: string;
  scheduledItemType: ReminderScheduledItemType;
  scheduledItemId: string;
  reminderAt: Date;
  seenAt: Date;
}

/** Idempotent upsert, keyed by the occurrence identity (userId,
 * scheduledItemType, scheduledItemId, reminderAt) -- brief section 3/4:
 * never a bare boolean, so a rescheduled item's NEW occurrence has no
 * matching row and is unread again automatically. Re-marking the SAME
 * occurrence seen just refreshes seenAt (harmless, idempotent). */
export async function markReminderSeen(
  userId: string,
  scheduledItemType: ReminderScheduledItemType,
  scheduledItemId: string,
  reminderAt: Date
): Promise<ReminderAttention> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "ReminderAttention" (id, "userId", "scheduledItemType", "scheduledItemId", "reminderAt")
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT ("userId", "scheduledItemType", "scheduledItemId", "reminderAt")
     DO UPDATE SET "seenAt" = now()
     RETURNING *`,
    [id, userId, scheduledItemType, scheduledItemId, reminderAt]
  );
  return result.rows[0];
}

/** Bounded query mirroring listPlannedActivitiesForReminders/
 * listAuraMomentsForReminders' own [from, to] window (brief section 25) --
 * only attention rows that could plausibly matter for a currently-relevant
 * reminder, never full history. */
export async function listReminderAttentionForOwner(userId: string, from: Date, to: Date): Promise<ReminderAttention[]> {
  const result = await pool.query(
    `SELECT * FROM "ReminderAttention" WHERE "userId" = $1 AND "reminderAt" BETWEEN $2 AND $3`,
    [userId, from, to]
  );
  return result.rows;
}

export type ReminderDeliveryChannel = 'WEB_PUSH';
// Web Push V1 (brief section 22/24): PROCESSING is the real claim
// transition (see claimReminderDeliveryForSending below) -- the row's
// creation-time uniqueness alone stops duplicate CREATION, not duplicate
// SENDING. SKIPPED means the occurrence was re-validated against
// deriveAuraReminders() immediately before sending and was no longer
// eligible (rescheduled/revoked/superseded) -- never sent.
export type ReminderDeliveryStatus = 'PENDING' | 'PROCESSING' | 'SENT' | 'FAILED' | 'SKIPPED';

export interface ReminderDelivery {
  id: string;
  userId: string;
  scheduledItemType: ReminderScheduledItemType;
  scheduledItemId: string;
  reminderAt: Date;
  channel: ReminderDeliveryChannel;
  status: ReminderDeliveryStatus;
  createdAt: Date;
  sentAt: Date | null;
  failedAt: Date | null;
  failureReason: string | null;
  attemptCount: number;
  lastAttemptAt: Date | null;
}

/** Idempotent claim (brief section 11/15): INSERT ... ON CONFLICT DO
 * NOTHING against the (userId, scheduledItemType, scheduledItemId,
 * reminderAt, channel) unique constraint, so two concurrent workers
 * calling this for the SAME occurrence can never both create a row -- the
 * DB constraint is the source of truth, not an in-memory check. Always
 * returns a real, persisted row: on conflict, re-reads and returns the
 * EXISTING one, so callers get idempotent read-or-create semantics without
 * needing to branch on which happened. */
export async function ensureReminderDelivery(
  userId: string,
  scheduledItemType: ReminderScheduledItemType,
  scheduledItemId: string,
  reminderAt: Date,
  channel: ReminderDeliveryChannel
): Promise<ReminderDelivery> {
  const id = randomUUID();
  const inserted = await pool.query(
    `INSERT INTO "ReminderDelivery" (id, "userId", "scheduledItemType", "scheduledItemId", "reminderAt", channel)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT ("userId", "scheduledItemType", "scheduledItemId", "reminderAt", channel) DO NOTHING
     RETURNING *`,
    [id, userId, scheduledItemType, scheduledItemId, reminderAt, channel]
  );
  if (inserted.rows.length > 0) return inserted.rows[0];

  const existing = await pool.query(
    `SELECT * FROM "ReminderDelivery"
     WHERE "userId" = $1 AND "scheduledItemType" = $2 AND "scheduledItemId" = $3 AND "reminderAt" = $4 AND channel = $5`,
    [userId, scheduledItemType, scheduledItemId, reminderAt, channel]
  );
  return existing.rows[0];
}

/** Owner-scoped delivery status update -- the ONLY writer of status/sentAt/
 * failedAt/failureReason (brief section 19: allow FAILED with a safe
 * reason, never a huge provider payload -- callers must pass a short,
 * app-generated string, not raw provider response bodies). Not called by
 * anything in this PR (no worker exists yet); exists so the future Web
 * Push worker has a real function to call instead of hand-writing SQL. */
export async function markReminderDeliveryStatus(
  deliveryId: string,
  status: 'SENT' | 'FAILED' | 'SKIPPED',
  failureReason?: string
): Promise<ReminderDelivery | null> {
  const result = await pool.query(
    status === 'SENT'
      ? `UPDATE "ReminderDelivery" SET status = 'SENT', "sentAt" = now() WHERE id = $1 RETURNING *`
      : status === 'FAILED'
        ? `UPDATE "ReminderDelivery" SET status = 'FAILED', "failedAt" = now(), "failureReason" = $2 WHERE id = $1 RETURNING *`
        : `UPDATE "ReminderDelivery" SET status = 'SKIPPED', "failureReason" = $2 WHERE id = $1 RETURNING *`,
    status === 'SENT' ? [deliveryId] : [deliveryId, (failureReason ?? '').slice(0, 500)]
  );
  return result.rows[0] ?? null;
}

/** Web Push V1 (brief section 22) -- the actual concurrency-safety
 * primitive: an atomic conditional UPDATE that only succeeds if the row is
 * STILL 'PENDING' at the moment it runs. Two workers racing on the same
 * delivery row: exactly one UPDATE matches the WHERE clause and returns a
 * row; the other affects 0 rows and gets null back. This is what stops two
 * workers from both sending the same occurrence -- the delivery row's own
 * creation-time uniqueness (ensureReminderDelivery) only stops duplicate
 * CREATION, which is a different race. */
export async function claimReminderDeliveryForSending(deliveryId: string): Promise<ReminderDelivery | null> {
  const result = await pool.query(
    `UPDATE "ReminderDelivery"
     SET status = 'PROCESSING', "attemptCount" = "attemptCount" + 1, "lastAttemptAt" = now()
     WHERE id = $1 AND status = 'PENDING'
     RETURNING *`,
    [deliveryId]
  );
  return result.rows[0] ?? null;
}

/** Web Push V1 (brief section 21) -- bounded due-user discovery: which
 * owners have a PlannedActivity/AuraMoment whose startAt falls inside the
 * SAME reminder-plausible window listPlannedActivitiesForReminders/
 * listAuraMomentsForReminders already use, so the dispatch worker never
 * loads every User row and never re-derives its own time bounds. Returns
 * bare userIds only -- ensureDueReminderDeliveries still does its own
 * per-user eligibility work (this is discovery, not eligibility). */
export async function listUserIdsWithPotentialReminders(from: Date, to: Date): Promise<string[]> {
  const result = await pool.query(
    `SELECT "userId" FROM "PlannedActivity" WHERE status = 'UPCOMING' AND "plannedStartAt" BETWEEN $1 AND $2
     UNION
     SELECT "ownerUserId" AS "userId" FROM "AuraMoment" WHERE status = 'ACTIVE' AND "startAt" BETWEEN $1 AND $2 AND ("expiresAt" IS NULL OR "expiresAt" > now())`,
    [from, to]
  );
  return result.rows.map((row) => row.userId as string);
}

// ============================================================
// Web Push V1 -- PushSubscription persistence. Ownership-scoped
// everywhere: a subscription belongs to exactly one authenticated user,
// never exposed to another (brief section 3).
// ============================================================

export interface PushSubscriptionRow {
  id: string;
  userId: string;
  endpoint: string;
  p256dh: string;
  auth: string;
  userAgent: string | null;
  createdAt: Date;
  updatedAt: Date;
  lastSuccessfulAt: Date | null;
  disabledAt: Date | null;
}

/** Upsert keyed on `endpoint` (globally unique -- brief section 4): the
 * same browser re-registering (e.g. after a service worker update) updates
 * the existing row in place -- including re-ENABLING a previously-disabled
 * one (a stale/expired subscription re-subscribing is, by definition, live
 * again) -- rather than accumulating duplicates. Re-registering under a
 * DIFFERENT userId reassigns ownership to the new user (the only way that
 * can legitimately happen is the same browser signing into a different
 * Aura account and re-subscribing, which SHOULD hand this endpoint to the
 * new owner). */
export async function upsertPushSubscription(input: {
  userId: string;
  endpoint: string;
  p256dh: string;
  auth: string;
  userAgent?: string | null;
}): Promise<PushSubscriptionRow> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "PushSubscription" (id, "userId", endpoint, p256dh, auth, "userAgent")
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (endpoint) DO UPDATE SET
       "userId" = EXCLUDED."userId",
       p256dh = EXCLUDED.p256dh,
       auth = EXCLUDED.auth,
       "userAgent" = EXCLUDED."userAgent",
       "updatedAt" = now(),
       "disabledAt" = NULL
     RETURNING *`,
    [id, input.userId, input.endpoint, input.p256dh, input.auth, input.userAgent ?? null]
  );
  return result.rows[0];
}

/** Owner-scoped disable -- used both by the user's own "Turn off" action
 * and (with a different caller) by stale-subscription cleanup after a
 * provider 404/410 (brief section 18). Never a hard delete (brief: "don't
 * delete state that's cheap to keep"). No-ops silently if the endpoint
 * doesn't belong to this owner (same discipline as revokeAuraMoment). */
export async function disablePushSubscriptionForOwner(userId: string, endpoint: string): Promise<void> {
  await pool.query(`UPDATE "PushSubscription" SET "disabledAt" = now() WHERE "userId" = $1 AND endpoint = $2`, [userId, endpoint]);
}

/** Endpoint-only disable, no ownership check -- used by the delivery
 * service when the PROVIDER (not the user) reports the endpoint is gone.
 * The delivery service already resolved this subscription via its owner's
 * own subscription list, so this is trusted, internal-only usage, never
 * exposed to a client-facing route. */
export async function disablePushSubscriptionByEndpoint(endpoint: string, reason: string): Promise<void> {
  await pool.query(`UPDATE "PushSubscription" SET "disabledAt" = now() WHERE endpoint = $1`, [endpoint]);
  void reason; // Reserved for future structured logging; never persisted (brief section 18: no raw provider payloads).
}

export async function markPushSubscriptionSuccessful(endpoint: string): Promise<void> {
  await pool.query(`UPDATE "PushSubscription" SET "lastSuccessfulAt" = now() WHERE endpoint = $1`, [endpoint]);
}

/** Only ACTIVE (never-disabled) subscriptions -- the delivery service's
 * one and only read path for "who do we send this owner's push to". */
export async function listActivePushSubscriptionsForOwner(userId: string): Promise<PushSubscriptionRow[]> {
  const result = await pool.query(`SELECT * FROM "PushSubscription" WHERE "userId" = $1 AND "disabledAt" IS NULL`, [userId]);
  return result.rows;
}

/** The owner's OWN view of their device notification state (brief section
 * 7/27): "is there at least one active subscription right now" is the
 * entire V1 "device notifications enabled" signal -- no separate boolean
 * preference column (see the completion report for why this was judged
 * sufficient for V1). */
export async function hasActivePushSubscription(userId: string): Promise<boolean> {
  const result = await pool.query(`SELECT 1 FROM "PushSubscription" WHERE "userId" = $1 AND "disabledAt" IS NULL LIMIT 1`, [userId]);
  return result.rows.length > 0;
}

/**
 * `executor` defaults to the pool (every existing caller is unchanged). The
 * ordinary `POST /api/plans` writer passes its transaction client so the insert
 * runs inside the same transaction that holds the per-user schedule lock; the
 * soft-dedup SELECT then runs on that client too.
 */
export async function createPlannedActivity(input: CreatePlannedActivityInput, executor: QueryExecutor = pool): Promise<PlannedActivity> {
  const existing = await executor.query(
    `SELECT *
     FROM "PlannedActivity"
     WHERE "userId" = $1
       AND status = 'UPCOMING'
       AND lower(title) = lower($2)
       AND "plannedStartAt" = $3
       AND "plannedEndAt" = $4
     ORDER BY "createdAt" DESC
     LIMIT 1`,
    [input.userId, input.title, input.plannedStartAt, input.plannedEndAt]
  );
  if (existing.rows.length > 0) return existing.rows[0];

  const id = randomUUID();
  const result = await executor.query(
    `INSERT INTO "PlannedActivity"
       (id, "userId", title, "activityType", icon, "plannedStartAt", "plannedEndAt",
        "durationMinutes", "windowType", "windowLabel", "matchLabel", score,
        recommendation, "calendarUrl", "eventTimezone", "eventLocationName", "schedulingMode", "activityId")
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
     RETURNING *`,
    [
      id,
      input.userId,
      input.title,
      input.activityType ?? null,
      input.icon ?? null,
      input.plannedStartAt,
      input.plannedEndAt,
      input.durationMinutes,
      input.windowType,
      input.windowLabel ?? null,
      input.matchLabel ?? null,
      input.score ?? null,
      input.recommendation ?? null,
      input.calendarUrl ?? null,
      input.eventTimezone ?? null,
      input.eventLocationName ?? null,
      parseSchedulingMode(input.schedulingMode),
      input.activityId ?? null,
    ]
  );
  return result.rows[0];
}

/**
 * Day Constructor V1 PR E2 -- the ONLY other Plan-insert primitive besides
 * `createPlannedActivity` above, used exclusively by the Day Constructor
 * acceptance persistence path (`dayConstructorAcceptancePersistence.ts`)
 * from inside its own atomic transaction. Two deliberate differences from
 * `createPlannedActivity`, both explained here rather than left implicit:
 *
 *   1. REQUIRES a `PoolClient` (never falls back to `pool`) -- a caller
 *      that already holds a transaction is the only legitimate caller;
 *      there is no non-transactional use case for this function.
 *   2. Performs NO content-based soft-dedup `SELECT` before inserting.
 *      `createPlannedActivity`'s own dedup check exists to protect ad-hoc
 *      callers (Forward Planner, Ask Aura, etc.) that have no other
 *      idempotency mechanism of their own. Day Constructor acceptance
 *      already has its OWN authoritative replay mechanism --
 *      `PlanCreationIdempotency`, keyed by a deterministic per-item id
 *      derived from the acceptance's own `clientRequestId` (see
 *      `deriveAcceptanceIdempotencyKey`) -- checked BEFORE this function
 *      is ever called. Reusing the title/time-based soft dedup here would
 *      risk exactly the confusion this ticket's own review flagged: a
 *      coincidentally-identical Plan created by a wholly unrelated action
 *      (e.g. a manual `POST /api/plans` call) could be mistaken for this
 *      acceptance's own output and have this acceptance's idempotency
 *      claim filled with SOMEONE ELSE'S Plan id. In practice this
 *      soft-dedup collision is already vanishingly unlikely to matter here
 *      even before considering idempotency: `evaluateAcceptance`'s own
 *      fresh-blocker revalidation (re-run inside this same transaction,
 *      see `dayConstructorAcceptancePersistence.ts`) already treats any
 *      existing Plan occupying the same interval as a `CONFLICT` and
 *      rejects the whole proposal BEFORE any insert is attempted -- so a
 *      title/time collision with a real, currently-active Plan can no
 *      longer reach this function at all. This function's own plain
 *      INSERT is therefore both simpler and strictly safer for this one
 *      caller than reusing the soft-dedup path would be.
 */
export async function createPlannedActivityWithClient(client: PoolClient, input: CreatePlannedActivityInput): Promise<PlannedActivity> {
  const id = randomUUID();
  const result = await client.query(
    `INSERT INTO "PlannedActivity"
       (id, "userId", title, "activityType", icon, "plannedStartAt", "plannedEndAt",
        "durationMinutes", "windowType", "windowLabel", "matchLabel", score,
        recommendation, "calendarUrl", "eventTimezone", "eventLocationName", "schedulingMode", "activityId")
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
     RETURNING *`,
    [
      id,
      input.userId,
      input.title,
      input.activityType ?? null,
      input.icon ?? null,
      input.plannedStartAt,
      input.plannedEndAt,
      input.durationMinutes,
      input.windowType,
      input.windowLabel ?? null,
      input.matchLabel ?? null,
      input.score ?? null,
      input.recommendation ?? null,
      input.calendarUrl ?? null,
      input.eventTimezone ?? null,
      input.eventLocationName ?? null,
      parseSchedulingMode(input.schedulingMode),
      input.activityId ?? null,
    ]
  );
  return result.rows[0];
}

export async function cancelPlannedActivity(userId: string, planId: string): Promise<PlannedActivity> {
  const result = await pool.query(
    `UPDATE "PlannedActivity"
     SET status = 'CANCELLED',
         "updatedAt" = now()
     WHERE id = $1 AND "userId" = $2 AND status = 'UPCOMING'
     RETURNING *`,
    [planId, userId]
  );
  if (result.rows.length === 0) throw new Error('Plan not found or cannot be cancelled.');
  return result.rows[0];
}

export class PlanSkipError extends Error {
  constructor(public readonly code: 'NOT_FOUND' | 'INVALID_STATE', message: string) {
    super(message);
    this.name = 'PlanSkipError';
  }
}

/**
 * Daily Experience V1 PR C1 -- "the user explicitly decided not to perform
 * this committed occurrence." UPCOMING -> SKIPPED only (including an elapsed,
 * derived-MISSED plan). One conditional UPDATE, so Skip/Skip, Skip/Log and
 * Skip/Cancel cannot both win: logPlannedActivity holds the row's FOR UPDATE
 * lock and re-checks status, cancelPlannedActivity is likewise conditional
 * on status = 'UPCOMING'. skippedAt = now() is the DB clock, set once; a
 * retry on an already-SKIPPED plan returns the original row unchanged.
 * Writes no HabitLog, Capture or GoalActivity row (both derive from the
 * linked plan's status).
 */
export async function skipPlannedActivity(userId: string, planId: string): Promise<PlannedActivity> {
  const updated = await pool.query(
    `UPDATE "PlannedActivity"
     SET status = 'SKIPPED',
         "skippedAt" = now(),
         "updatedAt" = now()
     WHERE id = $1 AND "userId" = $2 AND status = 'UPCOMING'
     RETURNING *`,
    [planId, userId]
  );
  if (updated.rows.length === 1) return updated.rows[0];

  const current = await pool.query(`SELECT * FROM "PlannedActivity" WHERE id = $1 AND "userId" = $2`, [planId, userId]);
  if (current.rows.length === 0) throw new PlanSkipError('NOT_FOUND', 'Plan not found.');
  if (current.rows[0].status === 'SKIPPED') return current.rows[0];
  throw new PlanSkipError('INVALID_STATE', 'Plan cannot be skipped.');
}

/** Permanently removes a plan from the list -- scoped to LOGGED/CANCELLED
 * only, never UPCOMING (that's what cancelPlannedActivity is for). Lets the
 * user actually clear old completed plans instead of them only ever
 * accumulating in "Recently Completed". */
export async function deletePlannedActivity(userId: string, planId: string): Promise<void> {
  const result = await pool.query(
    `DELETE FROM "PlannedActivity" WHERE id = $1 AND "userId" = $2 AND status IN ('LOGGED', 'CANCELLED')`,
    [planId, userId]
  );
  if (result.rowCount === 0) throw new Error('Plan not found or cannot be removed.');
}

// Goals V2 G2.2.2 -- optional, backward-compatible: every existing caller
// (Home/Right Now's createPlanExecutor, the Plan tab, every pre-G2.2.2 test)
// omits this entirely and is completely unaffected. See this function's own
// GoalActivityExecution section below for exactly what it does.
export interface LogPlannedActivityOptions {
  actualValue?: number;
}

export async function logPlannedActivity(userId: string, planId: string, options?: LogPlannedActivityOptions): Promise<{ plan: PlannedActivity; habitLog: HabitLogRow }> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const planRes = await client.query(
      `SELECT * FROM "PlannedActivity" WHERE id = $1 AND "userId" = $2 FOR UPDATE`,
      [planId, userId]
    );
    if (planRes.rows.length === 0) throw new Error('Plan not found.');
    const plan: PlannedActivity = planRes.rows[0];

    if (plan.status === 'LOGGED' && plan.habitLogId) {
      // Planned Activity Canonical Identity Propagation V1 -- widened to
      // include "activityId" (previously omitted), so a second/idempotent
      // completion request returns the SAME persisted identity as the
      // first, rather than silently reporting it as undefined.
      // Insights V1 PR6 -- widened to also include the four attribution
      // columns, so an idempotent retry returns the SAME complete row
      // shape as a first-time completion, never a narrower one.
      const existingLog = await client.query(
        `SELECT id, "userId", "activityTitle", "activityId", "activeWindow", "logTimestamp", "logMinuteOfDay", "durationMinutes", notes, "logSource", "activitySignificance",
           "originatingPlannedActivityId", "scheduledStartAtSnapshot", "completionAttribution", "originatingGoalActivityExecutionId"
         FROM "HabitLog"
         WHERE id = $1 AND "userId" = $2`,
        [plan.habitLogId, userId]
      );
      if (existingLog.rows.length === 0) {
        throw new Error('Logged plan is missing its activity log.');
      }
      await client.query('COMMIT');
      return { plan, habitLog: existingLog.rows[0] };
    }

    if (plan.status !== 'UPCOMING') {
      throw new Error('Plan is not available to log.');
    }

    // Goals V2 G2.2.2 -- resolve Goal linkage and validate actualValue
    // BEFORE any write, so an invalid actualValue fails the whole
    // completion attempt cleanly (nothing partially attempted) rather than
    // being caught only after other writes ran (atomicity is guaranteed by
    // the transaction either way, but failing fast here avoids doing work
    // that's about to be thrown away). Deliberately placed AFTER the
    // idempotent-retry early-return above: a second /log call for an
    // already-LOGGED plan returns there and never reaches this block at
    // all, so no duplicate GoalActivityExecution write is even attempted --
    // idempotency here is structural (the code path itself is never
    // re-entered), not dependent on the DB's unique constraint catching a
    // race.
    //
    // The GoalActivity is resolved SERVER-SIDE from persisted linkage --
    // never trusted from any client-supplied id. A plan with no such
    // linkage is an ordinary, non-Goal completion: entirely unaffected by
    // anything below.
    //
    // Insights V1 PR3 -- Durable Goal Completion Evidence: the OCCURRENCE
    // lookup (GoalActivityOccurrence.plannedActivityId, unique per plan)
    // is tried FIRST, and is the correct, authoritative resolution for a
    // Rhythm (N_PER_WEEK) GoalActivity's occurrence. The legacy
    // GoalActivity.plannedActivityId lookup is tried only as the fallback
    // for a plan with no occurrence row at all -- the finite/NONE-rhythm
    // case, where that single shared pointer IS reliable (a finite
    // GoalActivity never has more than one live link at once, so it is
    // never repointed out from under an in-flight completion the way a
    // Rhythm GoalActivity's pointer already is, by design, whenever a
    // sibling occurrence is materialized -- db.ts's own
    // materializeGoalActivityRhythmOccurrence doc comment: "most recently
    // materialized", never "the one being completed"). Resolving via the
    // shared pointer ALONE, as this function did before PR3, silently
    // wrote ZERO completion evidence for an older Rhythm occurrence
    // completed after a newer sibling already existed -- confirmed by
    // live reproduction (AURA_INSIGHTS_PR3_EVIDENCE_CONTRACT.md) -- this
    // is the exact defect this two-step resolution fixes.
    const occurrenceRes = await client.query(`SELECT id, "goalActivityId" FROM "GoalActivityOccurrence" WHERE "plannedActivityId" = $1 AND "userId" = $2`, [planId, userId]);
    const occurrenceRow: { id: string; goalActivityId: string } | undefined = occurrenceRes.rows[0];

    let goalActivity: GoalActivity | undefined;
    let occurrenceId: string | null = null;
    if (occurrenceRow) {
      const occurrenceGoalActivityRes = await client.query(`SELECT * FROM "GoalActivity" WHERE id = $1 AND "userId" = $2`, [occurrenceRow.goalActivityId, userId]);
      goalActivity = occurrenceGoalActivityRes.rows[0];
      occurrenceId = occurrenceRow.id;
    } else {
      const goalActivityRes = await client.query(`SELECT * FROM "GoalActivity" WHERE "plannedActivityId" = $1 AND "userId" = $2`, [planId, userId]);
      goalActivity = goalActivityRes.rows[0];
    }

    let executionWrite: { goalActivityId: string; occurrenceId: string | null; existingExecutionId: string | null; requirement: CompletionRequirement; currentValue: number | null } | null = null;
    if (goalActivity) {
      // Insights V1 PR3 -- serializes this completion's evidence write
      // against a concurrent deleteGoal for the SAME user (db.ts's
      // goalHasRetainedPlanLinkage/deleteGoal), closing the TOCTOU window
      // where deleteGoal's retained-evidence check could pass BEFORE this
      // transaction commits its new GoalActivityExecution row, and then
      // cascade-delete it anyway. A NEW, distinct advisory-lock keyspace
      // (never shared with day-constructor-accept's own per-user lock) --
      // same established, already-precedented pattern as recordVisit's
      // own `visit-log:${userId}` lock (db.ts), introduced independently
      // rather than overloading an existing keyspace for an unrelated
      // purpose. Acquired only once Goal linkage is already confirmed, so
      // the overwhelming majority of Done-taps (non-Goal-linked plans)
      // never acquire it at all -- zero added cost on the common path.
      // Exactly one lock is ever acquired per transaction in either this
      // function or deleteGoal, so no lock-ordering deadlock is possible.
      await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`goal-evidence:${userId}`]);
      // If an execution row already exists for THIS plan (not possible yet
      // via any production path in G2.2.2, since nothing creates one before
      // Done -- future partial-progress work will change that), its
      // immutable snapshot is authoritative: NEVER re-snapshot from the
      // live GoalActivity, which may have been edited since the execution
      // began (e.g. target 20 -> 30 pages). A first-write, by contrast,
      // snapshots the CURRENT canonical requirement -- that moment becomes
      // this execution's own historical definition from now on.
      const existingExecRes = await client.query(`SELECT * FROM "GoalActivityExecution" WHERE "plannedActivityId" = $1 AND "userId" = $2`, [planId, userId]);
      const existingExecution = existingExecRes.rows[0];
      const requirement = existingExecution
        ? fromPersistedGoalActivityExecutionSnapshot({
            completionKindSnapshot: existingExecution.completionKindSnapshot,
            completionTargetValueSnapshot: existingExecution.completionTargetValueSnapshot,
            completionUnitSnapshot: existingExecution.completionUnitSnapshot,
            currentValue: existingExecution.currentValue,
          }).completionRequirement
        : normalizeGoalActivityCompletionRequirement({
            completionKind: goalActivity.completionKind,
            completionTargetValue: goalActivity.completionTargetValue,
            completionUnit: goalActivity.completionUnit,
          });

      const actualValueResult = resolveCompletionActualValue(requirement, options?.actualValue);
      if (!actualValueResult.ok) throw new Error(actualValueResult.error);

      executionWrite = { goalActivityId: goalActivity.id, occurrenceId, existingExecutionId: existingExecution ? existingExecution.id : null, requirement, currentValue: actualValueResult.value };
    } else if (options?.actualValue !== undefined && options?.actualValue !== null) {
      // A caller supplied actualValue for a plan that isn't linked to any
      // Goal activity -- there is nothing for it to apply to. Reject rather
      // than silently discard it, same "never store meaningless numeric
      // progress" principle resolveCompletionActualValue already applies to
      // a DONE-kind Goal activity.
      throw new Error('actualValue was supplied, but this plan is not linked to a Goal activity.');
    }

    // Insights V1 PR6 -- Durable Completion Attribution. `executionWrite`
    // is now fully resolved (set whenever `goalActivity` was truthy above;
    // every path that leaves it unset without throwing corresponds to a
    // genuinely non-Goal-linked plan) -- the invariant this depends on:
    // there is no code path above that reaches this point with
    // `goalActivity` truthy and `executionWrite` still null, since the
    // only way out of the `if (goalActivity)` block besides setting
    // `executionWrite` is a thrown error (which rolls back the whole
    // transaction, writing nothing). Pre-generating the execution id here
    // -- BEFORE the HabitLog insert below -- mirrors the exact
    // `habitLogId = randomUUID()` precedent two lines down: both ids must
    // be known before the HabitLog row is written, so the row can carry a
    // stable, durable pointer to its own Goal-execution evidence from the
    // moment of creation, never correlated after the fact by title/
    // timestamp proximity. Reuses the EXISTING execution's own id
    // unchanged on an idempotent re-log (never generates a second id for
    // the same execution).
    const goalActivityExecutionId = executionWrite ? executionWrite.existingExecutionId ?? randomUUID() : null;
    const completionAttribution: 'GOAL_LINKED' | 'NON_GOAL' = executionWrite ? 'GOAL_LINKED' : 'NON_GOAL';

    // Plan Completion Historical Integrity V1 -- widened from the old
    // `SELECT timezone` to also fetch latitude/longitude, the two
    // additional Timing Location fields needed to resolve the ACTUAL
    // historical solar window at the real completion instant (previously
    // unavailable inside this transaction). Still exactly one User query,
    // still on this same transaction client. Deliberately User.latitude/
    // User.longitude/User.timezone (current Timing Location) -- never
    // birthLatitude/birthLongitude/birthTimezone (Birth Location) and
    // never plan.eventTimezone/plan.eventLocationName (Event Location,
    // which carries no coordinates anyway and is irrelevant to an ordinary
    // Plan completion).
    const userRes = await client.query(
      `SELECT latitude, longitude, timezone FROM "User" WHERE id = $1`,
      [userId]
    );
    const userLatitude: number = userRes.rows[0]?.latitude;
    const userLongitude: number = userRes.rows[0]?.longitude;
    const userTimezone = userRes.rows[0]?.timezone || 'UTC';
    const habitLogId = randomUUID();

    // Plan Completion Historical Integrity V1 -- ONE server-authoritative
    // clock read for the entire completion. Previously, `loggedAt = new
    // Date()` (the real completion instant) was captured correctly for
    // PlannedActivity.loggedAt, but HabitLog.logTimestamp/activeWindow/
    // logMinuteOfDay were independently derived from plan.plannedStartAt/
    // plan.windowType -- the PLAN, not the OBSERVATION. Both the plan's own
    // "when did you say you'd do this" (plannedStartAt/plannedEndAt/
    // windowType, all left untouched below) and this HabitLog's "when did
    // you actually do this" now come from that single distinction: the
    // former is never read past this point, the latter -- completionInstant
    // -- feeds every actual-history field, via derivePlanCompletionHistory
    // (apps/web/lib/planCompletionHistory.ts), which composes the exact
    // same resolveHistoricalActiveWindow/getMinuteOfDayInTimezone
    // primitives POST /api/habit-logs already uses for live and backdated
    // manual logs -- no new solar-window or timezone math.
    const completionInstant = new Date();
    const { logTimestamp, activeWindow, logMinuteOfDay } = derivePlanCompletionHistory({
      completionInstant,
      latitude: userLatitude,
      longitude: userLongitude,
      timezone: userTimezone,
    });
    const notes = `Logged from planned Aura activity${plan.recommendation ? `: ${plan.recommendation}` : '.'}`;

    // Planned Activity Canonical Identity Propagation V1 -- plan.activityId
    // is copied VERBATIM onto HabitLog.activityId: a factual copy, never a
    // catalog lookup/revalidation. plan.activityId is already available for
    // free (the plan SELECT above uses SELECT *), and is either a genuinely
    // known canonical id (persisted at Plan creation, apps/web/app/api/plans/route.ts)
    // or null (no canonical identity was known) -- both cases pass through
    // unchanged. If the catalog later drops an id that was valid at Plan
    // creation time, that historical fact is preserved here rather than
    // destroyed; C3's existing evaluateHabitLogAuraFit already handles that
    // drift gracefully (UNKNOWN_ACTIVITY_ID -> ineligible) without any
    // change to this function.
    // Insights V1 PR6 -- the four durable attribution columns are written
    // in this SAME INSERT, never a second statement: `plan.plannedStartAt`
    // is the row this function already holds `FOR UPDATE` from step 1,
    // read here (never re-queried), so it is necessarily the plan's own
    // CURRENT, post-any-prior-Move, committed schedule -- exactly "the
    // final accepted schedule at completion" (AURA_INSIGHTS_PR6_
    // COMPLETION_EVIDENCE_DECISION.md section 7). Never substitutes
    // logTimestamp/completionInstant for this value.
    const habitLogRes = await client.query(
      `INSERT INTO "HabitLog"
         (id, "userId", "activityTitle", "activityId", "activeWindow", "logMinuteOfDay",
          "logTimestamp", "durationMinutes", notes, "logSource", "activitySignificance",
          "originatingPlannedActivityId", "scheduledStartAtSnapshot", "completionAttribution", "originatingGoalActivityExecutionId")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'AURA_PLANNED', 'MEDIUM', $10, $11, $12, $13)
       RETURNING id, "userId", "activityTitle", "activityId", "activeWindow", "logTimestamp", "logMinuteOfDay", "durationMinutes", notes, "logSource", "activitySignificance",
         "originatingPlannedActivityId", "scheduledStartAtSnapshot", "completionAttribution", "originatingGoalActivityExecutionId"`,
      [
        habitLogId,
        userId,
        plan.title,
        plan.activityId ?? null,
        activeWindow,
        logMinuteOfDay,
        logTimestamp,
        plan.durationMinutes,
        notes,
        planId,
        plan.plannedStartAt,
        completionAttribution,
        goalActivityExecutionId,
      ]
    );

    const updatedPlanRes = await client.query(
      `UPDATE "PlannedActivity"
       SET status = 'LOGGED',
           "loggedAt" = $3,
           "habitLogId" = $4,
           "updatedAt" = now()
       WHERE id = $1 AND "userId" = $2
       RETURNING *`,
      [planId, userId, completionInstant, habitLogId]
    );

    // Quick Capture V1 PR B -- materialize the durable Capture-level
    // completion fact on the SAME transaction client, with the EXACT SAME
    // instant that was just written to PlannedActivity.loggedAt (never a
    // second clock read). COALESCE keeps any earlier completion timestamp.
    // A failure here throws into this function's own catch -> ROLLBACK, so
    // "plan LOGGED but linked Capture still PLANNED" cannot persist.
    await client.query(
      `UPDATE "Capture" SET "completedAt" = COALESCE("completedAt", $3), "updatedAt" = now()
       WHERE "plannedActivityId" = $1 AND "userId" = $2`,
      [planId, userId, completionInstant]
    );

    // Goals V2 G2.2.2 -- the SAME 'AURA_PLANNED' source this exact function
    // already used for the HabitLog insert above: this completion IS an
    // Aura-planned Done, so both records agree without a second, divergent
    // source calculation. currentValue never controls completion status --
    // PlannedActivity.status (already set to LOGGED above) remains the sole
    // completion truth regardless of what currentValue is written here, even
    // 0 or a value below target.
    if (executionWrite) {
      if (executionWrite.existingExecutionId) {
        // Only mutable facts change; goalActivityId/the snapshot/createdAt
        // are never touched.
        await client.query(
          `UPDATE "GoalActivityExecution" SET "currentValue" = $1, "source" = $2, "updatedAt" = now() WHERE id = $3`,
          [executionWrite.currentValue, 'AURA_PLANNED', executionWrite.existingExecutionId]
        );
      } else {
        const persisted = toPersistedGoalActivityExecutionSnapshot({ completionRequirement: executionWrite.requirement, currentValue: executionWrite.currentValue });
        // Insights V1 PR3 -- goalActivityOccurrenceId is the DURABLE link
        // (never cleared by deletePlannedActivity's hard-delete, unlike
        // plannedActivityId just beside it) back to the specific
        // occurrence this execution proves completion for. NULL for a
        // finite/NONE-rhythm completion (occurrenceId is null in that
        // case, from the resolution above) -- same nullability shape as
        // plannedActivityId's own optionality.
        // Insights V1 PR6 -- uses the SAME id already written onto
        // HabitLog.originatingGoalActivityExecutionId above (never a
        // second, independently-generated id), so the two rows this one
        // completion produces are durably, exactly cross-referenced from
        // the moment of creation.
        await client.query(
          `INSERT INTO "GoalActivityExecution"
             (id, "userId", "goalActivityId", "plannedActivityId", "goalActivityOccurrenceId", "completionKindSnapshot", "completionTargetValueSnapshot", "completionUnitSnapshot", "currentValue", "source")
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
          [goalActivityExecutionId, userId, executionWrite.goalActivityId, planId, executionWrite.occurrenceId, persisted.completionKindSnapshot, persisted.completionTargetValueSnapshot, persisted.completionUnitSnapshot, executionWrite.currentValue, 'AURA_PLANNED']
        );
      }
    }

    await client.query('COMMIT');
    return { plan: updatedPlanRes.rows[0], habitLog: habitLogRes.rows[0] };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

export async function upsertUserByEmail(input: {
  email: string;
  cityName: string;
  latitude: number;
  longitude: number;
  timezone: string;
}): Promise<User> {
  // Onboarding V1 PR 1 -- this INSERT never references "locationConfirmedAt",
  // so it is left at its NULL column default for every new signup, even
  // though `input.cityName`/etc. here are typically the hardcoded signup
  // placeholder (DEFAULT_SIGNUP_LOCATION, below). Signup must never stamp
  // a confirmation that didn't happen.
  //
  // Emails are case-insensitive identities. Both auth flows lowercase before
  // hashing/looking up codes, so the user lookup must too — otherwise
  // Foo@x.com and foo@x.com become two accounts and the second login lands
  // in an empty one. Migration 0012 enforces this with a unique index on
  // lower(email).
  const email = input.email.trim().toLowerCase();
  const existing = await pool.query('SELECT * FROM "User" WHERE lower(email) = $1', [email]);
  if (existing.rows.length > 0) return existing.rows[0];

  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "User" (id, email, "cityName", latitude, longitude, timezone)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
    [id, email, input.cityName, input.latitude, input.longitude, input.timezone]
  );
  return result.rows[0];
}

/**
 * Onboarding V1 PR 1 -- the ONE place `locationConfirmedAt` is ever
 * stamped: this function is reached only from a successful, already-
 * validated `PATCH /api/users/location` call (both the curated-city and
 * custom-location paths), never from signup (`upsertUserByEmail`, which
 * never references this column, leaving it at its NULL default), a read,
 * a background job, or timezone auto-detection. Stamped unconditionally
 * on every call -- including a user re-confirming the SAME city/coordinates
 * they already have, which must count as an explicit confirmation just as
 * much as an actual change does (this ticket's own requirement: "a user
 * explicitly confirming their existing city must be supported without
 * requiring a change in coordinates"). A validation failure in the route
 * never reaches this function at all, so it never stamps.
 */
export async function updateUserLocation(
  userId: string,
  location: { cityName: string; latitude: number; longitude: number; timezone: string }
): Promise<User> {
  const result = await pool.query(
    `UPDATE "User" SET "cityName" = $2, latitude = $3, longitude = $4, timezone = $5, "locationConfirmedAt" = now()
     WHERE id = $1 RETURNING *`,
    [userId, location.cityName, location.latitude, location.longitude, location.timezone]
  );
  return result.rows[0];
}

export async function getUserById(userId: string): Promise<User | null> {
  const result = await pool.query('SELECT * FROM "User" WHERE id = $1', [userId]);
  return result.rows[0] ?? null;
}

// v1 has no location-onboarding step yet (see MVP spec / README) — every new user
// defaults to Chennai until a location picker exists.
const DEFAULT_SIGNUP_LOCATION = {
  cityName: 'Chennai',
  latitude: 13.0827,
  longitude: 80.2707,
  timezone: 'Asia/Kolkata',
};

// Records at most one visit per user per calendar day — deliberately deduped so
// repeated page loads/refreshes in a session don't inflate the retention numbers
// this exists to measure. Pure analytics: deliberately carries no onboarding
// signal and is never read by onboarding logic (see markOnboardingResolved
// below for that durable, independent fact).
//
// Onboarding V1 PR 2 -- First-Run Reliability Correction: an earlier version
// of this function also reported "no VisitLog row existed before this call"
// as a first-visit proxy for onboarding. That coupling was removed after an
// empirical concurrency test showed two simultaneous calls (e.g. two
// browser tabs loading at once) would both see "no row yet" and both claim
// first-visit -- a plain check-then-insert race, with no DB-level
// uniqueness to prevent it. The SAME race could also duplicate a day's
// VisitLog row, corrupting this function's own pre-existing retention
// metric. Fixed here with a per-user advisory transaction lock -- the same
// established `pg_advisory_xact_lock(hashtext($1))` pattern already used by
// dayConstructorAcceptancePersistence.ts/remainingDayRecompositionAcceptance.ts/
// planMove.ts (auto-released at COMMIT/ROLLBACK) -- which serializes
// concurrent calls for the SAME user without any new schema.
export async function recordVisit(userId: string): Promise<void> {
  const client = await beginTransaction();
  try {
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`visit-log:${userId}`]);
    const existingToday = await client.query(
      `SELECT 1 FROM "VisitLog" WHERE "userId" = $1 AND "visitedAt"::date = CURRENT_DATE LIMIT 1`,
      [userId]
    );
    if (existingToday.rows.length === 0) {
      await client.query(`INSERT INTO "VisitLog" (id, "userId") VALUES ($1, $2)`, [randomUUID(), userId]);
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Onboarding V1 PR 2 -- First-Run Reliability Correction: the ONE place
 * `onboardingResolvedAt` is ever stamped. Reached only from the
 * authenticated `PATCH /api/users/onboarding` endpoint, itself called only
 * from the three true exit actions in the client (Skip Welcome, Go to
 * Home, Plan My Day -- apps/web/app/page.tsx's own `handleExitOnboarding`)
 * -- never from a session read, never from VisitLog/recordVisit, and never
 * merely because an onboarding step was rendered or advanced.
 *
 * Idempotent and safe under concurrent/repeated calls: the `WHERE
 * "onboardingResolvedAt" IS NULL` guard means a second call (a retry, a
 * double-click, two tabs both exiting) is a no-op that changes nothing --
 * the FIRST successful stamp wins and is never overwritten, so this never
 * needs its own advisory lock. Always returns the user's current,
 * authoritative row either way (already-resolved or freshly-resolved),
 * matching the endpoint's own "return the persisted resolution state"
 * contract.
 */
export async function markOnboardingResolved(userId: string): Promise<User | null> {
  const updated = await pool.query(
    `UPDATE "User" SET "onboardingResolvedAt" = now() WHERE id = $1 AND "onboardingResolvedAt" IS NULL RETURNING *`,
    [userId]
  );
  if (updated.rows.length > 0) return updated.rows[0];
  return getUserById(userId);
}

/** Per-day log counts for a given month, for the calendar view. Counts both fixed
 * action-card logs and custom-habit logs (habitId is nullable in HabitLog, so this
 * naturally covers both without a UNION). */
export async function getMonthlyActivity(
  userId: string,
  year: number,
  month: number // 1-12
): Promise<{ day: number; count: number }[]> {
  const result = await pool.query(
    `SELECT EXTRACT(DAY FROM "logTimestamp")::int AS day, COUNT(*)::int AS count
     FROM "HabitLog"
     WHERE "userId" = $1
       AND EXTRACT(YEAR FROM "logTimestamp") = $2
       AND EXTRACT(MONTH FROM "logTimestamp") = $3
     GROUP BY day
     ORDER BY day`,
    [userId, year, month]
  );
  return result.rows;
}

export async function getLogsForDay(
  userId: string,
  year: number,
  month: number,
  day: number
): Promise<HabitLogRow[]> {
  const result = await pool.query(
    `SELECT id, "userId", "activityTitle", "activeWindow", "logTimestamp", "logMinuteOfDay", "durationMinutes", notes, "logSource", "activitySignificance"
     FROM "HabitLog"
     WHERE "userId" = $1
       AND EXTRACT(YEAR FROM "logTimestamp") = $2
       AND EXTRACT(MONTH FROM "logTimestamp") = $3
       AND EXTRACT(DAY FROM "logTimestamp") = $4
     ORDER BY "logTimestamp"`,
    [userId, year, month, day]
  );
  return result.rows;
}

export async function checkDbConnection(): Promise<void> {
  await pool.query('SELECT 1');
}

export async function getOrCreateUserForAuth(email: string): Promise<User> {
  return upsertUserByEmail({ email, ...DEFAULT_SIGNUP_LOCATION });
}

// --- One-time sign-in codes (AuthCode table, migration 0011) ----------------

export interface AuthCodeRow {
  id: string;
  email: string;
  codeHash: string;
  attempts: number;
  expiresAt: Date;
  consumedAt: Date | null;
}

export async function createAuthCode(input: {
  email: string;
  codeHash: string;
  expiresAt: Date;
  requestIp?: string | null;
}): Promise<void> {
  await pool.query(
    `INSERT INTO "AuthCode" (id, email, "codeHash", "expiresAt", "requestIp")
     VALUES ($1, $2, $3, $4, $5)`,
    [randomUUID(), input.email.toLowerCase(), input.codeHash, input.expiresAt, input.requestIp ?? null]
  );
}

/** Requests in the last `windowMinutes` from this email or IP — rate limiting. */
export async function countRecentAuthRequests(
  email: string,
  requestIp: string | null,
  windowMinutes: number
): Promise<number> {
  const result = await pool.query(
    `SELECT COUNT(*)::int AS count FROM "AuthCode"
     WHERE "createdAt" > now() - ($1 || ' minutes')::interval
       AND (email = $2 OR ("requestIp" IS NOT NULL AND "requestIp" = $3))`,
    [windowMinutes, email.toLowerCase(), requestIp]
  );
  return result.rows[0].count;
}

/** Latest unconsumed, unexpired code row for this email. */
export async function findActiveAuthCode(email: string): Promise<AuthCodeRow | null> {
  const result = await pool.query(
    `SELECT id, email, "codeHash", attempts, "expiresAt", "consumedAt"
     FROM "AuthCode"
     WHERE email = $1 AND "consumedAt" IS NULL AND "expiresAt" > now()
     ORDER BY "createdAt" DESC LIMIT 1`,
    [email.toLowerCase()]
  );
  return result.rows[0] ?? null;
}

/**
 * Atomically spends one verification attempt and returns the code hash to
 * compare against, or null once the attempt cap is reached. The gate and the
 * increment are a single UPDATE so N concurrent guesses cost N attempts —
 * a read-check-increment sequence would let parallel requests all see
 * attempts=0 and bypass the cap entirely.
 */
export async function spendAuthCodeAttempt(
  id: string,
  maxAttempts: number
): Promise<{ codeHash: string } | null> {
  const result = await pool.query(
    `UPDATE "AuthCode" SET attempts = attempts + 1
     WHERE id = $1 AND attempts < $2 AND "consumedAt" IS NULL
     RETURNING "codeHash"`,
    [id, maxAttempts]
  );
  return result.rows[0] ?? null;
}

/**
 * Marks the code used. Returns false if it was already consumed — the caller
 * must NOT issue a session in that case, or two concurrent redemptions of the
 * same code would both mint sessions.
 */
export async function consumeAuthCode(id: string): Promise<boolean> {
  const result = await pool.query(
    `UPDATE "AuthCode" SET "consumedAt" = now() WHERE id = $1 AND "consumedAt" IS NULL RETURNING id`,
    [id]
  );
  return result.rowCount === 1;
}

/**
 * Good Right Now / Log Activity Failure State Correctness V1 -- looks up
 * an existing HabitLog by the same (userId, clientRequestId) pair the
 * partial unique index (migration 0032) enforces. Used both for the
 * common case (POST /api/habit-logs's own idempotent-replay check before
 * inserting) and by createHabitLog's own race-safe fallback below. Scoped
 * to userId so one user's request id can never resolve another's row.
 */
export async function getHabitLogByClientRequestId(userId: string, clientRequestId: string): Promise<HabitLogRow | null> {
  const result = await pool.query(
    `SELECT * FROM "HabitLog" WHERE "userId" = $1 AND "clientRequestId" = $2`,
    [userId, clientRequestId]
  );
  return result.rows[0] ?? null;
}

export async function createHabitLog(input: {
  userId: string;
  activityTitle: string;
  // Prospective Canonical Activity Identity V1 -- an already-validated
  // canonical activity id, or omitted/null when none is known. This
  // function performs NO catalog lookup/validation itself -- that belongs
  // at the API/service boundary (apps/web/app/api/habit-logs/route.ts),
  // the same layer that already validates/resolves activeWindow and
  // logMinuteOfDay before calling this DB helper. Persisted exactly as
  // given.
  activityId?: string | null;
  activeWindow: string;
  logMinuteOfDay: number;
  logTimestamp?: Date;
  durationMinutes?: number;
  notes?: string;
  logSource?: 'AURA_PLANNED' | 'AURA_DO_NOW' | 'MANUAL' | 'OVERRIDE_CAUTION';
  activitySignificance?: 'LOW' | 'MEDIUM' | 'HIGH';
  // Good Right Now / Log Activity Failure State Correctness V1 -- optional,
  // omitted/null persists NULL (a legitimate, expected value -- most
  // callers still don't send one). See migration 0032's own comment.
  clientRequestId?: string | null;
}): Promise<HabitLogRow> {
  const id = randomUUID();
  const timestamp = input.logTimestamp ?? new Date();

  try {
    const result = await pool.query(
      `INSERT INTO "HabitLog" (id, "userId", "activityTitle", "activityId", "activeWindow", "logMinuteOfDay", "logTimestamp", "durationMinutes", notes, "logSource", "activitySignificance", "clientRequestId")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING *`,
      [
        id,
        input.userId,
        input.activityTitle,
        input.activityId ?? null,
        input.activeWindow,
        input.logMinuteOfDay,
        timestamp,
        input.durationMinutes ?? 30,
        input.notes ?? null,
        input.logSource ?? 'MANUAL',
        input.activitySignificance ?? 'MEDIUM',
        input.clientRequestId ?? null,
      ]
    );
    return result.rows[0];
  } catch (err) {
    // Good Right Now / Log Activity Failure State Correctness V1 -- a
    // genuine concurrent race (two near-simultaneous requests carrying the
    // SAME clientRequestId, e.g. a real retry firing before the original
    // request's own INSERT has committed) hits the partial unique index
    // and raises Postgres 23505 (unique_violation) here, not a pre-check
    // race window this function could otherwise close. The winner's row
    // already exists at that point -- return it instead of surfacing a
    // 500 for what is, from the caller's perspective, a successful
    // idempotent replay.
    const pgError = err as { code?: string };
    if (pgError.code === '23505' && input.clientRequestId) {
      const existing = await getHabitLogByClientRequestId(input.userId, input.clientRequestId);
      if (existing) return existing;
    }
    throw err;
  }
}

export async function listHabitLogs(userId: string, executor: ReadQueryExecutor = pool): Promise<HabitLogRow[]> {
  const result = await executor.query(
    `SELECT * FROM "HabitLog" WHERE "userId" = $1 ORDER BY "logTimestamp" DESC LIMIT 50`,
    [userId]
  );
  return result.rows;
}

/**
 * Insights Correctness + Historical Integrity V1 -- a DATE-RANGE query
 * (never a row-count LIMIT) for the specific consumers that need real
 * period-based history: Insights' own "This Month"/7-day trend/30-day
 * heatmap/active-logging-streak calculations, and the reflection/alignment
 * correlation in apps/web/app/api/daily-assistant/insights/route.ts. A
 * row-count cap (listHabitLogs()'s existing LIMIT 50, deliberately left
 * unmodified above -- apps/web/lib/myDayOrchestrator.ts already relies on
 * its exact "last 50 overall" contract for a different, single-day
 * purpose) silently truncates any of those periods for a moderately active
 * logger, well before 30-50 real days of history are reached.
 *
 * `sinceDate` is caller-supplied (see INSIGHTS_HISTORY_DAYS below) rather
 * than hardcoded here, so callers can reason about/test the exact horizon
 * being requested.
 */
export async function listHabitLogsForInsights(userId: string, sinceDate: Date): Promise<HabitLogRow[]> {
  const result = await pool.query(
    `SELECT * FROM "HabitLog" WHERE "userId" = $1 AND "logTimestamp" >= $2 ORDER BY "logTimestamp" DESC`,
    [userId, sinceDate]
  );
  return result.rows;
}

/**
 * Insights Correctness + Historical Integrity V1 -- the historical horizon
 * listHabitLogsForInsights() queries by default. Chosen as a generous,
 * bounded (not literally unlimited) date range rather than a row count:
 * comfortably covers every current Insights period (This Month, the 7-day
 * trend, the 30-day heatmap) and gives the Active Logging Streak over a
 * full year of headroom -- the UI presents that streak as an unrestricted
 * current count with no "within the last N days" caveat, so silently
 * capping it at exactly 30 days would change its product meaning, not just
 * its performance profile. 400 days is a deliberate compromise: bounded
 * and indexable (never a truly unlimited lifetime scan), while realistic
 * habit-logging streaks are extremely unlikely to exceed it.
 */
export const INSIGHTS_HISTORY_DAYS = 400;

export async function listAllHabitLogsForExport(userId: string): Promise<HabitLogRow[]> {
  const result = await pool.query(
    `SELECT * FROM "HabitLog" WHERE "userId" = $1 ORDER BY "logTimestamp" DESC`,
    [userId]
  );
  return result.rows;
}

export async function upsertDailyReflection(input: {
  userId: string;
  reflectionDate: Date;
  outputLevel: 'LOW' | 'MODERATE' | 'PEAK_FLOW';
  followedGuidance: boolean;
  notes?: string;
}): Promise<DailyReflection> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "DailyReflection"
       (id, "userId", "reflectionDate", "outputLevel", "followedGuidance", notes)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT ("userId", "reflectionDate")
     DO UPDATE SET "outputLevel" = EXCLUDED."outputLevel",
                   "followedGuidance" = EXCLUDED."followedGuidance",
                   notes = EXCLUDED.notes,
                   "updatedAt" = now()
     RETURNING *`,
    [
      id,
      input.userId,
      input.reflectionDate,
      input.outputLevel,
      input.followedGuidance,
      input.notes ?? null,
    ]
  );
  return result.rows[0];
}

export async function getDailyReflection(userId: string, reflectionDate: Date): Promise<DailyReflection | null> {
  const result = await pool.query(
    `SELECT * FROM "DailyReflection" WHERE "userId" = $1 AND "reflectionDate" = $2 LIMIT 1`,
    [userId, reflectionDate]
  );
  return result.rows[0] ?? null;
}

export async function listDailyReflections(userId: string, limit = 60): Promise<DailyReflection[]> {
  const result = await pool.query(
    `SELECT * FROM "DailyReflection" WHERE "userId" = $1 ORDER BY "reflectionDate" DESC LIMIT $2`,
    [userId, limit]
  );
  return result.rows;
}

export async function listAllDailyReflectionsForExport(userId: string): Promise<DailyReflection[]> {
  const result = await pool.query(
    `SELECT * FROM "DailyReflection" WHERE "userId" = $1 ORDER BY "reflectionDate" DESC`,
    [userId]
  );
  return result.rows;
}

// ============================================================
// Product Instrumentation V1
//
// This table is written to ONLY via lib/productEvents.ts's
// validateProductEvent() -- see that module for the closed event-name
// vocabulary and per-event metadata allow-list. createProductEvent() below
// trusts its input completely (no validation here); that is intentional so
// the validation logic stays independently unit-testable without a database.
// ============================================================

export interface ProductEvent {
  id: string;
  eventName: string;
  userId: string | null;
  auraMomentId: string | null;
  metadata: Record<string, string | number | boolean>;
  createdAt: Date;
}

export interface CreateProductEventInput {
  eventName: string;
  userId?: string | null;
  auraMomentId?: string | null;
  metadata: Record<string, string | number | boolean>;
}

export async function createProductEvent(input: CreateProductEventInput): Promise<ProductEvent> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "ProductEvent" (id, "eventName", "userId", "auraMomentId", metadata)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [id, input.eventName, input.userId ?? null, input.auraMomentId ?? null, JSON.stringify(input.metadata)]
  );
  return result.rows[0];
}

/** One row per (eventName, metadata->>groupKey) pair within the window --
 * the raw material for both the volume table and the scope/mode breakdowns
 * on the internal metrics endpoint. `group` is null for events that don't
 * carry the requested key (e.g. AURA_HOME_VIEWED has no "scope"). */
export interface ProductEventCountRow {
  eventName: string;
  group: string | null;
  count: number;
}

export async function listProductEventCountsSince(since: Date, groupMetadataKey: string): Promise<ProductEventCountRow[]> {
  const result = await pool.query(
    `SELECT "eventName", metadata->>$2 as group, COUNT(*)::int as count
     FROM "ProductEvent"
     WHERE "createdAt" >= $1
     GROUP BY "eventName", metadata->>$2`,
    [since, groupMetadataKey]
  );
  return result.rows.map((row) => ({ eventName: row.eventName, group: row.group ?? null, count: row.count }));
}

/** Distinct AURA MOMENTS (not raw event rows) that fired a given event within
 * the window -- the correct denominator for the Moment lifecycle funnel,
 * since a recipient can (for example) reopen a moment or an owner can click
 * "share" more than once for the same moment. */
export async function countDistinctMomentsForEventSince(eventName: string, since: Date): Promise<number> {
  const result = await pool.query(
    `SELECT COUNT(DISTINCT "auraMomentId")::int as count
     FROM "ProductEvent"
     WHERE "eventName" = $1 AND "createdAt" >= $2 AND "auraMomentId" IS NOT NULL`,
    [eventName, since]
  );
  return result.rows[0]?.count ?? 0;
}

/** Distinct authenticated USERS that fired a given event within the window
 * -- used for the "unique users" side of Plan activation / personalization
 * rate, as distinct from total event volume. */
export async function countDistinctUsersForEventSince(eventName: string, since: Date): Promise<number> {
  const result = await pool.query(
    `SELECT COUNT(DISTINCT "userId")::int as count
     FROM "ProductEvent"
     WHERE "eventName" = $1 AND "createdAt" >= $2 AND "userId" IS NOT NULL`,
    [eventName, since]
  );
  return result.rows[0]?.count ?? 0;
}

/** Union counterpart to countDistinctMomentsForEventSince -- distinct
 * moments that fired ANY of the given events within the window. Needed
 * because a single moment CAN fire more than one response-type event over
 * its lifetime (e.g. ANOTHER_TIME, revisited, then ACCEPTED), so naively
 * summing per-event distinct counts would double count; this runs one
 * query against the true union instead. */
export async function countDistinctMomentsForAnyEventSince(eventNames: string[], since: Date): Promise<number> {
  const result = await pool.query(
    `SELECT COUNT(DISTINCT "auraMomentId")::int as count
     FROM "ProductEvent"
     WHERE "eventName" = ANY($1) AND "createdAt" >= $2 AND "auraMomentId" IS NOT NULL`,
    [eventNames, since]
  );
  return result.rows[0]?.count ?? 0;
}

/** Raw durationMs values for an event within the window, optionally grouped
 * by another metadata key (e.g. "scope") -- the input to p50/p95 percentile
 * computation in lib/productMetrics.ts. Grouped entries with no such
 * metadata key come back under the `null` group. */
export interface ProductEventDurationGroup {
  group: string | null;
  durationsMs: number[];
}

export async function listProductEventDurationsSince(eventName: string, since: Date, groupMetadataKey: string | null = null): Promise<ProductEventDurationGroup[]> {
  const result = await pool.query(
    groupMetadataKey
      ? `SELECT metadata->>$3 as group, (metadata->>'durationMs')::numeric as duration
         FROM "ProductEvent"
         WHERE "eventName" = $1 AND "createdAt" >= $2 AND metadata ? 'durationMs'`
      : `SELECT NULL as group, (metadata->>'durationMs')::numeric as duration
         FROM "ProductEvent"
         WHERE "eventName" = $1 AND "createdAt" >= $2 AND metadata ? 'durationMs'`,
    groupMetadataKey ? [eventName, since, groupMetadataKey] : [eventName, since]
  );
  const byGroup = new Map<string | null, number[]>();
  for (const row of result.rows) {
    const key = row.group ?? null;
    if (!byGroup.has(key)) byGroup.set(key, []);
    byGroup.get(key)!.push(Number(row.duration));
  }
  return Array.from(byGroup.entries()).map(([group, durationsMs]) => ({ group, durationsMs }));
}

// ── Explicit activity duration preferences (Explicit Duration Preferences
// Foundation V1, migration 0033) ──────────────────────────────────────────
// Row absence IS "no explicit preference" -- these are raw persistence
// primitives only; see apps/web/lib/activityPreferences.ts for activityId/
// duration validation and the minimal app-facing contract built on top.

export interface UserActivityPreferenceRow {
  id: string;
  userId: string;
  activityId: string;
  preferredDurationMinutes: number;
  createdAt: Date;
  updatedAt: Date;
}

export async function listUserActivityPreferenceRows(userId: string, executor: ReadQueryExecutor = pool): Promise<UserActivityPreferenceRow[]> {
  const result = await executor.query(
    `SELECT id, "userId", "activityId", "preferredDurationMinutes", "createdAt", "updatedAt"
     FROM "UserActivityPreference"
     WHERE "userId" = $1
     ORDER BY "activityId" ASC`,
    [userId]
  );
  return result.rows;
}

/** Idempotent by design (ON CONFLICT ("userId", "activityId") DO UPDATE) --
 * setting the same activity's preference twice updates the one row rather
 * than erroring or duplicating it. */
export async function upsertUserActivityPreference(
  userId: string,
  activityId: string,
  preferredDurationMinutes: number
): Promise<UserActivityPreferenceRow> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "UserActivityPreference" (id, "userId", "activityId", "preferredDurationMinutes")
     VALUES ($1, $2, $3, $4)
     ON CONFLICT ("userId", "activityId")
     DO UPDATE SET "preferredDurationMinutes" = EXCLUDED."preferredDurationMinutes", "updatedAt" = now()
     RETURNING id, "userId", "activityId", "preferredDurationMinutes", "createdAt", "updatedAt"`,
    [id, userId, activityId, preferredDurationMinutes]
  );
  return result.rows[0];
}

/** Idempotent: clearing a preference that doesn't exist deletes zero rows
 * and never errors. */
export async function deleteUserActivityPreference(userId: string, activityId: string): Promise<void> {
  await pool.query(`DELETE FROM "UserActivityPreference" WHERE "userId" = $1 AND "activityId" = $2`, [userId, activityId]);
}

// ── Availability periods (Availability Context V1 PR H1, migration 0034)
// ──────────────────────────────────────────────────────────────────────
// Raw persistence primitives only, mirroring UserActivityPreference's own
// convention above -- see apps/web/lib/availabilityContext.ts for the pure
// resolver these rows feed into. `User.availabilityConfigured` (not a row
// in this table) is the ONLY signal that distinguishes "no schedule saved
// at all" from "schedule saved, this weekday has zero periods" -- a table
// containing only period rows can never make that distinction by itself
// (a user with a real but entirely-empty saved week would be
// indistinguishable from a user who never configured anything, if
// configured-state were inferred from row presence alone). Only the
// minimal helpers H1 itself needs (list + a single-row create, for its
// own pure-resolver integration and test seeding) -- H2 owns the real
// user-facing replace/CRUD surface (add/remove/reorder periods) on top of
// these same primitives.

export interface UserAvailabilityPeriodRow {
  id: string;
  userId: string;
  weekday: number;
  startTime: string;
  endTime: string;
  createdAt: Date;
  updatedAt: Date;
}

export async function listUserAvailabilityPeriods(userId: string, executor: ReadQueryExecutor = pool): Promise<UserAvailabilityPeriodRow[]> {
  const result = await executor.query(
    `SELECT id, "userId", weekday, "startTime", "endTime", "createdAt", "updatedAt"
     FROM "UserAvailabilityPeriod"
     WHERE "userId" = $1
     ORDER BY weekday ASC, "startTime" ASC`,
    [userId]
  );
  return result.rows;
}

/** O5 P2d -- the persisted "has this user configured availability" flag, readable through a snapshot executor so it is
 * seen from the SAME snapshot as the availability periods it qualifies (the preview's `User` object is read earlier). */
export async function readUserAvailabilityConfigured(userId: string, executor: ReadQueryExecutor = pool): Promise<boolean> {
  const result = await executor.query('SELECT "availabilityConfigured" FROM "User" WHERE id = $1', [userId]);
  return result.rows[0]?.availabilityConfigured === true;
}

/** No upsert/uniqueness constraint -- unlike `UserActivityPreference`
 * (unique per activityId), a user may legitimately have several periods
 * for the SAME weekday (this ticket's own section 15/17: multiple
 * periods per day, e.g. a lunch gap), so there is no natural single key
 * to conflict on. Each call always inserts a new row. */
export async function createUserAvailabilityPeriod(userId: string, weekday: number, startTime: string, endTime: string): Promise<UserAvailabilityPeriodRow> {
  const id = randomUUID();
  const result = await pool.query(
    `INSERT INTO "UserAvailabilityPeriod" (id, "userId", weekday, "startTime", "endTime")
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, "userId", weekday, "startTime", "endTime", "createdAt", "updatedAt"`,
    [id, userId, weekday, startTime, endTime]
  );
  return result.rows[0];
}

/** Sets the single `User.availabilityConfigured` flag -- the CONFIGURED/
 * UNCONFIGURED discriminant itself (see this section's own module note
 * above). H2's own future settings API is the real production caller;
 * exported now only because H1's own DB tests need a way to seed both
 * states deterministically. */
export async function setAvailabilityConfigured(userId: string, configured: boolean): Promise<void> {
  await pool.query(`UPDATE "User" SET "availabilityConfigured" = $2 WHERE id = $1`, [userId, configured]);
}

/** Clears every saved period for a user -- exported for H1's own live-DB
 * test cleanup (this repository's own established convention: a
 * throwaway test user's rows are always deleted in a `finally` block,
 * e.g. `dayConstructorAcceptancePersistenceDb.test.ts`'s own
 * `deletePlannedActivity` cleanup). H2's real settings API will likely
 * use a per-row delete/replace instead; this whole-user clear is not
 * exposed as end-user-facing behavior. */
export async function deleteUserAvailabilityPeriods(userId: string): Promise<void> {
  await pool.query(`DELETE FROM "UserAvailabilityPeriod" WHERE "userId" = $1`, [userId]);
}

// ── Availability Settings V1 PR H2 -- high-level, atomic operations built
// on H1's own low-level primitives above. The Settings API route calls
// ONLY these three; it never orchestrates multiple raw writes itself
// (this ticket's own section 31). ─────────────────────────────────────

export interface UserAvailabilityConfigurationView {
  configured: boolean;
  periods: UserAvailabilityPeriodRow[];
}

/** Read-only combination of `User.availabilityConfigured` + this user's
 * saved periods -- `null` only when the user itself doesn't exist (never
 * for a genuinely UNCONFIGURED or CONFIGURED_EMPTY user, both of which
 * are real, valid results). */
export async function getUserAvailabilityConfiguration(userId: string): Promise<UserAvailabilityConfigurationView | null> {
  const user = await getUserById(userId);
  if (!user) return null;
  const periods = await listUserAvailabilityPeriods(userId);
  return { configured: user.availabilityConfigured === true, periods };
}

/**
 * REPLACE semantics (this ticket's own section 20/21): the submitted
 * period set becomes the user's ENTIRE saved week, atomically, and
 * `availabilityConfigured` becomes `true` -- including when `periods` is
 * empty (this ticket's own section 22: a real, deliberate all-week-empty
 * CONFIGURED state, never silently reinterpreted as a reset). Delete +
 * insert + flag update all happen inside ONE transaction (mirrors
 * `persistAcceptedConstructedDay`'s own `beginTransaction`/COMMIT/
 * ROLLBACK convention, dayConstructorAcceptancePersistence.ts) -- a
 * failure at any point leaves the user's PREVIOUS configuration
 * untouched, never a partial replacement.
 */
export async function replaceUserAvailabilityConfiguration(userId: string, periods: readonly { weekday: number; startTime: string; endTime: string }[]): Promise<void> {
  const client = await beginTransaction();
  try {
    await client.query(`DELETE FROM "UserAvailabilityPeriod" WHERE "userId" = $1`, [userId]);
    for (const period of periods) {
      const id = randomUUID();
      await client.query(
        `INSERT INTO "UserAvailabilityPeriod" (id, "userId", weekday, "startTime", "endTime") VALUES ($1, $2, $3, $4, $5)`,
        [id, userId, period.weekday, period.startTime, period.endTime]
      );
    }
    await client.query(`UPDATE "User" SET "availabilityConfigured" = true WHERE id = $1`, [userId]);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

/**
 * The ONLY operation that returns a user to UNCONFIGURED (this ticket's
 * own section 23/29) -- deliberately distinct from
 * `replaceUserAvailabilityConfiguration(userId, [])`, which means
 * CONFIGURED with an all-empty week, not UNCONFIGURED. Same atomic
 * transaction shape as the replace above.
 */
export async function resetUserAvailabilityConfiguration(userId: string): Promise<void> {
  const client = await beginTransaction();
  try {
    await client.query(`DELETE FROM "UserAvailabilityPeriod" WHERE "userId" = $1`, [userId]);
    await client.query(`UPDATE "User" SET "availabilityConfigured" = false WHERE id = $1`, [userId]);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

// ── Daily Rhythm V1 PR DR1 -- Preferences Foundation. Mirrors the
// Availability functions directly above: a read, a write (always sets
// workStart/workEnd/workDays together), and a clear (the only operation
// that returns to the null/empty UNCONFIGURED state). Unlike availability,
// there is no separate "configured" flag -- workStart/workEnd both null
// IS unconfigured, by construction (see User.dailyRhythmWorkStart's own
// schema doc comment), so there is nothing else to keep in sync. ────────

export interface DailyRhythmPreferencesView {
  workStart: string | null;
  workEnd: string | null;
  workDays: number[];
}

/** `null` only when the user itself doesn't exist -- a genuinely
 * unconfigured user (both fields null, empty workDays) is a real, valid
 * result, not an error. */
export async function getDailyWorkPreferences(userId: string): Promise<DailyRhythmPreferencesView | null> {
  const result = await pool.query('SELECT "dailyRhythmWorkStart", "dailyRhythmWorkEnd", "dailyRhythmWorkDays" FROM "User" WHERE id = $1', [userId]);
  const row = result.rows[0];
  if (!row) return null;
  return { workStart: row.dailyRhythmWorkStart ?? null, workEnd: row.dailyRhythmWorkEnd ?? null, workDays: row.dailyRhythmWorkDays ?? [] };
}

/** Always writes all three columns together -- the caller (the API route)
 * has already run the submitted input through
 * validateDailyRhythmPreferencesInput (dailyRhythmPreferences.ts) before
 * this is called; this function performs no validation of its own, same
 * convention as replaceUserAvailabilityConfiguration above. */
export async function setDailyWorkPreferences(userId: string, prefs: { workStart: string; workEnd: string; workDays: readonly number[] }): Promise<void> {
  await pool.query(
    `UPDATE "User" SET "dailyRhythmWorkStart" = $2, "dailyRhythmWorkEnd" = $3, "dailyRhythmWorkDays" = $4 WHERE id = $1`,
    [userId, prefs.workStart, prefs.workEnd, Array.from(prefs.workDays)]
  );
}

/** The ONLY operation that returns a user to the unconfigured state
 * (both time fields null, workDays empty) -- deliberately a separate
 * function from setDailyWorkPreferences, same "clear is not just save
 * with different values" precedent resetUserAvailabilityConfiguration
 * establishes above. */
export async function clearDailyWorkPreferences(userId: string): Promise<void> {
  await pool.query(`UPDATE "User" SET "dailyRhythmWorkStart" = NULL, "dailyRhythmWorkEnd" = NULL, "dailyRhythmWorkDays" = '{}' WHERE id = $1`, [userId]);
}

// ============================================================
// Goals -> Planning Integration V1 PR A (migration 0035, apps/web/lib/
// goals.ts for the pure domain logic this persistence layer wraps). Like
// createPlannedActivity, these functions perform NO catalog lookup/
// validation themselves -- that belongs at the API/service boundary
// (app/api/goals/**/route.ts), same convention as every other
// activityId-accepting write in this file.
// ============================================================

export interface Goal {
  id: string;
  userId: string;
  title: string;
  // A plain "YYYY-MM-DD" civil-date string, deliberately never a JS Date
  // here. node-postgres's default type parser for a `date` column (OID
  // 1082) constructs a Date at LOCAL midnight in the reading process's own
  // timezone, not UTC midnight -- confirmed directly (test/goalsDb.test.ts
  // caught this exact bug during PR A's own validation: `SELECT
  // '2026-09-25'::date` came back as `2026-09-24T18:30:00.000Z` under
  // IST). Every query below that touches "targetDate" casts it to
  // ::text explicitly, so this field is a plain string straight out of
  // Postgres, never re-interpreted through any timezone at all -- the
  // exact property this ticket's own section 4 asked to be verified, not
  // just assumed.
  targetDate: string | null;
  status: 'ACTIVE' | 'ARCHIVED';
  createdAt: Date;
  updatedAt: Date;
  archivedAt: Date | null;
}

export interface GoalActivity {
  id: string;
  userId: string;
  goalId: string;
  title: string;
  activityId: string | null;
  status: 'SUGGESTED' | 'DISMISSED';
  plannedActivityId: string | null;
  // Goals V2 G2.1 (migration 0040) -- the raw persisted shape; see
  // apps/web/lib/goalCompletion.ts's normalizeGoalActivityCompletionRequirement
  // for turning these into the canonical CompletionRequirement (null
  // completionKind, from any existing/legacy row or an omitted G2.1
  // requirement, always normalizes to DONE).
  completionKind: string | null;
  completionTargetValue: number | null;
  completionUnit: string | null;
  // Goals V2 Rhythm R2 (migration 0043) -- the raw persisted shape; see
  // apps/web/lib/goalActivityRhythm.ts's normalizeGoalActivityRhythm for
  // turning these into the canonical GoalActivityRhythm (null rhythmKind,
  // from any existing/legacy row or an omitted R2 policy, always
  // normalizes to NONE).
  rhythmKind: string | null;
  rhythmTargetPerWeek: number | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface GoalActivityWithLinkedPlanStatus extends GoalActivity {
  linkedPlanStatus: 'UPCOMING' | 'LOGGED' | 'CANCELLED' | 'SKIPPED' | 'MOVED' | null;
  // Goals V2 G3.1 -- the CURRENT execution's measured fact, resolved by
  // joining on the SAME plannedActivityId this row already carries (never a
  // second/"latest" concept -- GoalActivityExecution.plannedActivityId is
  // unique, and is only ever set by logPlannedActivity's own server-side
  // resolution of THIS exact GoalActivity, so there is no ambiguity to
  // resolve). NULL both when plannedActivityId is null and when no
  // execution row exists yet for the current link -- identical "nothing
  // recorded" meaning either way, same convention as linkedPlanStatus
  // itself above. Insights V1 PR3 -- now resolved by a LATERAL subquery
  // that falls back to the most recent HISTORICAL execution (by
  // "goalActivityId", never by the now-possibly-NULL plannedActivityId
  // alone) when the live link has been cleared by deletePlannedActivity
  // -- see listGoalActivitiesWithLinkedPlanStatus's own doc comment.
  currentValue: number | null;
  // Insights V1 PR3 -- true iff ANY GoalActivityExecution row exists for
  // this GoalActivity, independent of whether its PlannedActivity link
  // is still live. This is the durable half of "was this ever
  // completed" that deriveGoalActivityState consults ONLY when
  // plannedActivityId is null, to distinguish "never planned" from "was
  // planned, completed, and its plan was later cleared from Recently
  // Completed" -- the latter must still derive COMPLETED, not revert to
  // SUGGESTED.
  everCompleted: boolean;
}

// Explicit column list, "targetDate" cast to ::text -- see Goal's own
// targetDate doc comment above for exactly why RETURNING */SELECT * would
// silently corrupt this column via node-postgres's default date parsing.
const GOAL_COLUMNS = `id, "userId", title, "targetDate"::text AS "targetDate", status, "createdAt", "updatedAt", "archivedAt"`;

export async function listGoalsForUser(userId: string, status: 'ACTIVE' | 'ARCHIVED' = 'ACTIVE'): Promise<Goal[]> {
  const result = await pool.query(`SELECT ${GOAL_COLUMNS} FROM "Goal" WHERE "userId" = $1 AND status = $2 ORDER BY "updatedAt" DESC`, [userId, status]);
  return result.rows;
}

export async function getGoalForUser(userId: string, goalId: string): Promise<Goal | null> {
  const result = await pool.query(`SELECT ${GOAL_COLUMNS} FROM "Goal" WHERE id = $1 AND "userId" = $2`, [goalId, userId]);
  return result.rows[0] ?? null;
}

/**
 * Creates a Goal and (optionally) its initial GoalActivity rows in one
 * transaction (implementation design section 14 / this PR's own section
 * 14 -- "if suggestion insertion fails, the Goal creation should roll
 * back"). `activities` is already fully resolved by the caller (title +
 * catalog-matched activityId, or an empty array for a free-text Goal with
 * no template) -- this function performs no catalog lookup itself, same
 * convention as createPlannedActivity above.
 */
export async function createGoalWithActivities(input: {
  userId: string;
  title: string;
  // Already-validated "YYYY-MM-DD" (isValidCivilDateString), or null.
  // Passed straight to Postgres as a string parameter -- $4::date casts it
  // server-side; no JS Date object is ever constructed for this value, so
  // there is nothing for a timezone to shift.
  targetDate: string | null;
  // Goals V2 G2.1 established this as optional plumbing, unused by any
  // production caller at the time. G3.4 is the first production caller to
  // supply it (GOAL_TEMPLATES's own per-activity completionRequirement,
  // resolved server-side and passed straight through by the POST
  // /api/goals route -- see lib/goals.ts). Omitted still means DONE, via
  // toPersistedCompletionRequirement(DONE_COMPLETION_REQUIREMENT)'s own
  // all-null encoding -- identical to every row this function persisted
  // before G2.1; this function's own write path is otherwise unchanged.
  // Goals V2 Rhythm R5 -- rhythm is likewise optional and additive, per
  // activity (Rhythm belongs to GoalActivity, this ticket's own section
  // 13 domain-truth decision -- never a single Goal-level frequency
  // copied across activities). Omitted means NONE, identical to every
  // activity this function persisted before R5 (this ticket's own section
  // 42/50 API-compatibility requirement -- a template creation that omits
  // rhythm entirely, which is every creation before this ticket and every
  // "Start from scratch" creation after it, is byte-identical to before).
  activities: ReadonlyArray<{ title: string; activityId: string | null; completionRequirement?: CompletionRequirement; rhythm?: GoalActivityRhythm }>;
  // Goals V2 Candidate B3.1 -- an explicit, caller-derived id (e.g.
  // deriveIdempotentGoalId's deterministic hash of (userId,
  // clientRequestId), goalCreateIdempotency.ts) instead of a fresh
  // randomUUID(). Omitted (every caller before this ticket) keeps
  // today's exact random-id behavior unchanged. When supplied and a Goal
  // with this id already exists, the INSERT below raises Postgres 23505
  // (unique_violation) on the existing primary key -- the caller recovers
  // by re-fetching, same "insert, let the DB's own constraint decide"
  // pattern as logHabitCompletion's own clientRequestId handling above.
  id?: string;
}): Promise<{ goal: Goal; activities: GoalActivity[] }> {
  const client = await beginTransaction();
  try {
    const goalId = input.id ?? randomUUID();
    const goalResult = await client.query(
      `INSERT INTO "Goal" (id, "userId", title, "targetDate") VALUES ($1, $2, $3, $4::date) RETURNING ${GOAL_COLUMNS}`,
      [goalId, input.userId, input.title, input.targetDate]
    );
    const goal: Goal = goalResult.rows[0];

    const activities: GoalActivity[] = [];
    for (const [index, activity] of input.activities.entries()) {
      const persistedCompletion = toPersistedCompletionRequirement(activity.completionRequirement ?? { kind: 'DONE' });
      const persistedRhythm = toPersistedGoalActivityRhythm(activity.rhythm ?? NONE_GOAL_ACTIVITY_RHYTHM);
      // The request's activity order is meaningful (it is the order the user sees, and an idempotent replay is compared against
      // it index by index). `now()` is the TRANSACTION start, identical for every row inserted here, and ids are random, so
      // without this the order would not be recoverable: tied rows come back in whatever order the query plan happens to
      // produce. Each activity therefore gets its own strictly increasing `createdAt` -- the last keeps the transaction
      // instant, earlier ones sit 1 ms apart before it (at most 19 ms, MAX_REVIEWED_ACTIVITIES is 20) -- so `ORDER BY
      // "createdAt"` IS the creation order. Nothing is ever placed in the future, so a later `addGoalActivity` still sorts after.
      const result = await client.query(
        `INSERT INTO "GoalActivity" (id, "userId", "goalId", title, "activityId", "completionKind", "completionTargetValue", "completionUnit", "rhythmKind", "rhythmTargetPerWeek", "createdAt")
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, now() - ($11::int * interval '1 millisecond')) RETURNING *`,
        [randomUUID(), input.userId, goalId, activity.title, activity.activityId, persistedCompletion.completionKind, persistedCompletion.completionTargetValue, persistedCompletion.completionUnit, persistedRhythm.rhythmKind, persistedRhythm.rhythmTargetPerWeek, input.activities.length - 1 - index]
      );
      activities.push(result.rows[0]);
    }

    await client.query('COMMIT');
    return { goal, activities };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Idempotent -- COALESCE keeps the original archivedAt on a repeat
 * archive call, not just the status, matching archiveHabit's own
 * idempotent-by-design shape above. Returns null if the Goal doesn't
 * exist or isn't owned by this user (ownership check via the WHERE
 * clause, never via id alone).
 */
export async function archiveGoal(userId: string, goalId: string): Promise<Goal | null> {
  const result = await pool.query(
    `UPDATE "Goal" SET status = 'ARCHIVED', "archivedAt" = COALESCE("archivedAt", now())
     WHERE id = $1 AND "userId" = $2 RETURNING ${GOAL_COLUMNS}`,
    [goalId, userId]
  );
  return result.rows[0] ?? null;
}

/**
 * Checks for a CURRENT, existing PlannedActivity linkage -- i.e. some
 * GoalActivity under this Goal still has a non-null plannedActivityId
 * right now, regardless of that linked Plan's own status (UPCOMING/
 * LOGGED/CANCELLED all count equally; only NULL doesn't). This is
 * deliberately NOT a durable "was this Goal ever scheduled" tombstone:
 * the plannedActivityId FK is ON DELETE SET NULL (schema.prisma), so once
 * the underlying PlannedActivity is itself hard-deleted, this check
 * naturally reports false again and the Goal becomes eligible for hard
 * deletion -- Aura intentionally keeps no separate "ever scheduled"
 * record solely to block a later Goal deletion. See deleteGoal's own doc
 * comment for exactly what this protects against and what it does not.
 *
 * Multi-Occurrence Rhythm PR 2 corrective fix -- this guard originally
 * read ONLY GoalActivity's own singular `plannedActivityId`, which was a
 * correct proxy for "any retained linkage exists" back when at most one
 * occurrence could ever be live at a time. Now that an N_PER_WEEK
 * GoalActivity can carry several simultaneously-UPCOMING occurrences,
 * that singular column tracks only the MOST RECENTLY materialized one --
 * an older sibling occurrence can still retain a live Plan link (via its
 * own `GoalActivityOccurrence.plannedActivityId`) even after the
 * singular column has been nulled (e.g. the newest occurrence's Plan was
 * hard-deleted). The authoritative occurrence ledger is therefore checked
 * too: ANY `GoalActivityOccurrence` row under this Goal's activities that
 * still references a real PlannedActivity also retains linkage, exactly
 * like the legacy singular column always has. A NONE-rhythm GoalActivity
 * never has an occurrence row (R1's own invariant, unchanged), so this
 * addition is a pure no-op for the legacy finite path.
 *
 * Insights V1 PR3 -- widened again, for a sibling reason to the
 * Multi-Occurrence Rhythm fix above: retained PLAN linkage is not the
 * only thing that must block deletion. A completed occurrence/finite
 * activity whose Plan has ALREADY been hard-deleted (deletePlannedActivity)
 * has no linkage left for the checks above to find, but still has real,
 * durable completion evidence (GoalActivityExecution, surviving that
 * delete via its own goalActivityId, which is never cleared by it) -- a
 * Goal in exactly this state must remain undeletable too, or hard-
 * deleting it would cascade away confirmed achievement history the user
 * never asked to erase (AURA_INSIGHTS_PR3_ARCHITECTURE_AUDIT.md /
 * AURA_INSIGHTS_PR3_EVIDENCE_CONTRACT.md). This is additive to the same
 * existing 'HAS_HISTORY' response, not a new deletion mode -- a Goal
 * with genuinely zero retained linkage AND zero completion evidence
 * remains exactly as deletable as before this addition.
 */
export async function goalHasRetainedPlanLinkage(userId: string, goalId: string, executor: Pool | PoolClient = pool): Promise<boolean> {
  const result = await executor.query(
    `SELECT 1 FROM "GoalActivity" ga
     WHERE ga."userId" = $1 AND ga."goalId" = $2
       AND (
         ga."plannedActivityId" IS NOT NULL
         OR EXISTS (
           SELECT 1 FROM "GoalActivityOccurrence" gao
           WHERE gao."goalActivityId" = ga.id AND gao."plannedActivityId" IS NOT NULL
         )
         OR EXISTS (
           SELECT 1 FROM "GoalActivityExecution" gae
           WHERE gae."goalActivityId" = ga.id
         )
       )
     LIMIT 1`,
    [userId, goalId]
  );
  return result.rows.length > 0;
}

/**
 * Hard delete, gated on RETAINED PlannedActivity linkage OR retained
 * completion evidence (Insights V1 PR3 widened this from linkage-only --
 * see goalHasRetainedPlanLinkage's own doc comment), not durable history
 * as a permanent record in every other sense (this PR's own
 * delete-history semantics decision): a GoalActivity whose
 * plannedActivityId currently points at a real PlannedActivity blocks
 * deletion regardless of that Plan's status (UPCOMING/LOGGED/CANCELLED
 * all block equally) -- but this is a snapshot of CURRENT linkage, not a
 * permanent record. If that PlannedActivity is later hard-deleted, its
 * FK's own ON DELETE SET NULL clears the linkage (unchanged, still a
 * mechanism that exists), and the Goal becomes deletable again --
 * UNLESS confirmed completion evidence also survived that same delete
 * (PR3's own addition), in which case it remains blocked. Row-locks the
 * Goal first (FOR UPDATE, same convention as logHabitCompletion above)
 * so a concurrent acceptance linking a GoalActivity under this Goal
 * can't race past the linkage check.
 *
 * Insights V1 PR3 -- ALSO acquires the SAME `goal-evidence:${userId}`
 * advisory transaction lock logPlannedActivity's Goal-linked completion
 * branch takes (db.ts), for the entire duration of this transaction
 * (held from here through the final DELETE/ROLLBACK, auto-released at
 * COMMIT/ROLLBACK) -- closing the TOCTOU window where this function's
 * own evidence check could read "none retained" microseconds before a
 * concurrent Done commits new evidence under this exact Goal, which the
 * subsequent DELETE would then cascade away anyway. Acquired
 * unconditionally here (deletion is a rare, deliberate action, unlike
 * the hot completion path, where the lock is acquired only once Goal
 * linkage is already confirmed) so no Goal-linked Done for this user can
 * commit while a deletion of one of their Goals is in flight, and vice
 * versa. Exactly one lock is ever acquired per transaction in either
 * function, so no lock-ordering deadlock is possible.
 */
export async function deleteGoal(userId: string, goalId: string): Promise<'DELETED' | 'NOT_FOUND' | 'HAS_HISTORY'> {
  const client = await beginTransaction();
  try {
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`goal-evidence:${userId}`]);
    const goalRes = await client.query(`SELECT 1 FROM "Goal" WHERE id = $1 AND "userId" = $2 FOR UPDATE`, [goalId, userId]);
    if (goalRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return 'NOT_FOUND';
    }
    if (await goalHasRetainedPlanLinkage(userId, goalId, client)) {
      await client.query('ROLLBACK');
      return 'HAS_HISTORY';
    }
    await client.query(`DELETE FROM "Goal" WHERE id = $1 AND "userId" = $2`, [goalId, userId]);
    await client.query('COMMIT');
    return 'DELETED';
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

/** Ownership-checks the parent Goal first (via getGoalForUser) -- returns
 * null rather than inserting under a Goal that doesn't exist or isn't
 * owned by this user. */
// Goals V2 G2.1 -- completionRequirement is optional and NOT yet supplied
// by the POST /api/goals/[goalId]/activities route: omitted means DONE
// (see createGoalWithActivities's identical convention above).
//
// Goals V2 Rhythm R5 -- rhythm is likewise optional and additive. Omitted
// means NONE (toPersistedGoalActivityRhythm(NONE_GOAL_ACTIVITY_RHYTHM)'s own
// all-null encoding -- identical to every row this function persisted
// before R5, this ticket's own section 42 API-compatibility requirement).
// The caller (POST /api/goals/[goalId]/activities) is responsible for
// validating any client-supplied rhythm through the canonical R2
// validator (validateGoalActivityRhythm) BEFORE calling this function --
// this function trusts its input the same way it already trusts
// completionRequirement.
export async function addGoalActivity(userId: string, goalId: string, input: { title: string; activityId: string | null; completionRequirement?: CompletionRequirement; rhythm?: GoalActivityRhythm }): Promise<GoalActivity | null> {
  const goal = await getGoalForUser(userId, goalId);
  if (!goal) return null;
  const persistedCompletion = toPersistedCompletionRequirement(input.completionRequirement ?? { kind: 'DONE' });
  const persistedRhythm = toPersistedGoalActivityRhythm(input.rhythm ?? NONE_GOAL_ACTIVITY_RHYTHM);
  const result = await pool.query(
    `INSERT INTO "GoalActivity" (id, "userId", "goalId", title, "activityId", "completionKind", "completionTargetValue", "completionUnit", "rhythmKind", "rhythmTargetPerWeek")
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
    [randomUUID(), userId, goalId, input.title, input.activityId, persistedCompletion.completionKind, persistedCompletion.completionTargetValue, persistedCompletion.completionUnit, persistedRhythm.rhythmKind, persistedRhythm.rhythmTargetPerWeek]
  );
  return result.rows[0];
}

/**
 * Goals V2 Rhythm R5 -- the one allowed Rhythm WRITE path for an EXISTING
 * GoalActivity (creation-time Rhythm goes through addGoalActivity /
 * createGoalWithActivities instead -- this function is never called from
 * either). A pure policy change: never touches plannedActivityId, never
 * creates/deletes a GoalActivityOccurrence row, never cancels an existing
 * UPCOMING commitment (this ticket's own section 21/22 -- eligibility
 * simply recalculates prospectively from the new policy the next time it
 * is read; nothing here is migrated or backfilled). Scoped by userId AND
 * goalId AND id together, same ownership convention as
 * dismissGoalActivity. The caller is responsible for validating `rhythm`
 * through validateGoalActivityRhythm first -- this function trusts its
 * input, same convention as every other persistence function in this file.
 */
export async function setGoalActivityRhythm(userId: string, goalId: string, goalActivityId: string, rhythm: GoalActivityRhythm): Promise<GoalActivity | null> {
  const persisted = toPersistedGoalActivityRhythm(rhythm);
  const result = await pool.query(
    `UPDATE "GoalActivity" SET "rhythmKind" = $1, "rhythmTargetPerWeek" = $2, "updatedAt" = now() WHERE id = $3 AND "goalId" = $4 AND "userId" = $5 RETURNING *`,
    [persisted.rhythmKind, persisted.rhythmTargetPerWeek, goalActivityId, goalId, userId]
  );
  return result.rows[0] ?? null;
}

/** Idempotent (repeat dismissal is a harmless no-op re-write of the same
 * status). Scoped by userId AND goalId AND id together, so a
 * goalActivityId belonging to a different Goal or a different user's Goal
 * never matches -- returns null rather than throwing. */
export async function dismissGoalActivity(userId: string, goalId: string, goalActivityId: string): Promise<GoalActivity | null> {
  const result = await pool.query(
    `UPDATE "GoalActivity" SET status = 'DISMISSED' WHERE id = $1 AND "goalId" = $2 AND "userId" = $3 RETURNING *`,
    [goalActivityId, goalId, userId]
  );
  return result.rows[0] ?? null;
}

/**
 * One query, LEFT JOINed against PlannedActivity for its status, so the
 * API/presentation layer can call deriveGoalActivityState (lib/goals.ts)
 * per row without an N+1 lookup. linkedPlanStatus is null both when
 * plannedActivityId is null and when the referenced row is gone (already
 * handled identically by deriveGoalActivityState).
 */
export async function listGoalActivitiesWithLinkedPlanStatus(userId: string, goalId: string): Promise<GoalActivityWithLinkedPlanStatus[]> {
  // TOTAL order: `createdAt` is creation order for every activity created through createGoalWithActivities (strictly increasing per
  // activity), and `id` makes the order deterministic under any remaining tie (e.g. rows that predate that), instead of leaving
  // tied rows in whatever order the query plan emits -- the idempotent Goal-create replay compares this list index by index.
  //
  // Insights V1 PR3 -- the execution join is now a LATERAL subquery
  // (never more than one row per GoalActivity, preserving this
  // function's own flat, one-row-per-activity shape exactly) that
  // prefers the execution tied to the CURRENT live "plannedActivityId"
  // when one exists (byte-for-byte the same result the old plain
  // "plannedActivityId = plannedActivityId" join already produced in
  // that case), and falls back to the most recently created execution
  // for this GoalActivity otherwise -- the case that matters once
  // deletePlannedActivity has cleared the live link (ga."plannedActivityId"
  // IS NULL afterward, so the old join's equality could never match
  // again; matching on "goalActivityId" instead is what survives that
  // deletion). "everCompleted" is true iff that subquery found any row
  // at all, independent of which plan (if any) is currently linked.
  const result = await pool.query(
    `SELECT ga.*, pa.status AS "linkedPlanStatus", gae."currentValue", (gae.id IS NOT NULL) AS "everCompleted"
     FROM "GoalActivity" ga
     LEFT JOIN "PlannedActivity" pa ON pa.id = ga."plannedActivityId"
     LEFT JOIN LATERAL (
       SELECT e.id, e."currentValue"
       FROM "GoalActivityExecution" e
       WHERE e."goalActivityId" = ga.id
       ORDER BY (e."plannedActivityId" IS NOT NULL AND e."plannedActivityId" = ga."plannedActivityId") DESC, e."createdAt" DESC
       LIMIT 1
     ) gae ON true
     WHERE ga."userId" = $1 AND ga."goalId" = $2
     ORDER BY ga."createdAt", ga.id`,
    [userId, goalId]
  );
  return result.rows;
}

/**
 * Insights V1 PR4 -- the multi-Goal sibling of listGoalActivitiesWithLinkedPlanStatus
 * above: byte-for-byte the SAME query (same LATERAL execution-evidence
 * join, same linkedPlanStatus/everCompleted shape, same TOTAL order), only
 * the WHERE clause is widened from one "goalId" to "goalId = ANY(...)" --
 * so a cross-Goal reporting read (apps/web/lib/insightsReporting.ts) can
 * fetch every GoalActivity for every one of a user's Goals in ONE round
 * trip, never one query per Goal (the N+1 shape this function exists to
 * avoid). No business rule is duplicated: this is the identical SELECT,
 * just not goalId-scoped to a single row. Order is additionally stable
 * across goalId first (so a caller grouping rows back by Goal can do so
 * with a single linear pass, never a second sort).
 */
export async function listGoalActivitiesWithLinkedPlanStatusForGoals(userId: string, goalIds: readonly string[]): Promise<GoalActivityWithLinkedPlanStatus[]> {
  if (goalIds.length === 0) return [];
  const result = await pool.query(
    `SELECT ga.*, pa.status AS "linkedPlanStatus", gae."currentValue", (gae.id IS NOT NULL) AS "everCompleted"
     FROM "GoalActivity" ga
     LEFT JOIN "PlannedActivity" pa ON pa.id = ga."plannedActivityId"
     LEFT JOIN LATERAL (
       SELECT e.id, e."currentValue"
       FROM "GoalActivityExecution" e
       WHERE e."goalActivityId" = ga.id
       ORDER BY (e."plannedActivityId" IS NOT NULL AND e."plannedActivityId" = ga."plannedActivityId") DESC, e."createdAt" DESC
       LIMIT 1
     ) gae ON true
     WHERE ga."userId" = $1 AND ga."goalId" = ANY($2::text[])
     ORDER BY ga."goalId", ga."createdAt", ga.id`,
    [userId, [...goalIds]]
  );
  return result.rows;
}

/**
 * Insights V1 PR4 -- the one new reporting read this PR adds: every
 * non-deleted PlannedActivity in a date range, EVERY status included
 * (unlike listPlannedActivitiesForDay, which deliberately excludes
 * CANCELLED for its own, unrelated display purpose -- reusing it here
 * would silently drop the "explicit cancellations" reporting category).
 * No status is filtered, no business rule is applied here at all --
 * classification into CONFIRMED COMPLETED / SCHEDULED / SKIPPED /
 * CANCELLED / RESCHEDULED / AWAITING CONFIRMATION happens entirely in the
 * pure, DB-free classifyPlanningStatus (insightsReporting.ts), so this
 * function has exactly one job: read the rows, ownership-scoped, range-
 * bounded, nothing else. Read-only; no write, no side effect.
 *
 * Insights V1 PR7 -- Move consistency correction (AURA_INSIGHTS_V1_PRODUCT_
 * COMPLETION_AUDIT.md finding F-3). The range bound below used to be
 * `"plannedStartAt" BETWEEN $2 AND $3` for every row, including a MOVED
 * row -- but a MOVED row's OWN plannedStartAt is the stale, ORIGINAL
 * schedule it was moved away FROM, not when the Move itself happened.
 * Since a live, actionable Move-chain terminal is (by construction)
 * scheduled in the future, its own source row's original plannedStartAt
 * is very often ALSO in the future, so the old filter silently excluded
 * the exact Move events PR5's REPEATED_RESCHEDULING signal was telling
 * the user about in the same response -- a confirmed, reproduced
 * self-contradiction ("0 rescheduled" next to "this activity has been
 * moved a few times").
 *
 * The fix: a MOVED row is now attributed by the actual Move timestamp
 * (`movedAt`) when one is recorded, falling back to its own
 * `plannedStartAt` only for a legacy row moved before migration 0046
 * introduced that column (`movedAt IS NULL`) -- never fabricated, never
 * guessed, the exact same "no backfill" discipline every PR1-6 migration
 * in this schema already established. Every non-MOVED row's own
 * attribution is completely unchanged (the CASE below evaluates to NULL
 * for any other status, so COALESCE falls straight through to
 * "plannedStartAt", byte-identical to the original query). A MOVED row's
 * successor is a separate row with its own status and its own
 * independent membership in this same range -- this change does not
 * touch how the successor is counted, so a single Move operation still
 * contributes exactly one RESCHEDULED fact, never two.
 */
export async function listPlannedActivitiesForReporting(userId: string, from: Date, to: Date): Promise<PlannedActivity[]> {
  const result = await pool.query(
    `SELECT * FROM "PlannedActivity"
     WHERE "userId" = $1
       AND COALESCE(CASE WHEN status = 'MOVED' THEN "movedAt" END, "plannedStartAt") BETWEEN $2 AND $3
     ORDER BY "plannedStartAt" ASC`,
    [userId, from, to]
  );
  return result.rows;
}

/**
 * Insights V1 PR6 -- Durable Completion Attribution: the count of
 * confirmed, non-Goal-linked completions whose ORIGINATING PlannedActivity
 * has since been hard-deleted, attributable to the same scheduled-date
 * range `listPlannedActivitiesForReporting` above already uses (never
 * `logTimestamp`/`createdAt`, which record completion time, a materially
 * different fact -- AURA_INSIGHTS_PR6_COMPLETION_EVIDENCE_DECISION.md
 * section 7). A pure, additive fallback: the live-Plan path above remains
 * fully authoritative and untouched; this only recovers evidence that
 * would otherwise silently vanish from `confirmedCompleted` the moment a
 * completed, non-Goal-linked Plan is cleared from "Recently Completed".
 *
 * Every condition below is required, matching the PR6 ticket's own exact
 * specification -- never relaxed, never inferred from title/activityId/
 * timestamp proximity:
 *   - `"userId" = $1`                        -- ownership.
 *   - `"logSource" = 'AURA_PLANNED'`          -- only a completion that
 *     originated from completing a Plan (never a manual/do-now/custom-
 *     habit log, which never sets the four PR6 columns at all).
 *   - `"completionAttribution" = 'NON_GOAL'`  -- excludes 'GOAL_LINKED'
 *     (already durably represented via GoalActivityExecution, PR3 -- see
 *     the decision doc's own "do not double-count" contract) AND excludes
 *     NULL/UNKNOWN_LEGACY (a row written before this feature existed,
 *     whose attribution is permanently unknown -- NEVER silently treated
 *     as NON_GOAL).
 *   - `"originatingPlannedActivityId" IS NOT NULL` / `"scheduledStartAtSnapshot" IS NOT NULL`
 *     -- defensive: both are always set together with a non-NULL
 *     `completionAttribution` by the one canonical writer
 *     (logPlannedActivity), so this should never actually filter
 *     anything out in practice; kept as an explicit guard rather than an
 *     assumption.
 *   - `"scheduledStartAtSnapshot" BETWEEN $2 AND $3` -- the exact same
 *     two range parameters the live-Plan query receives.
 *   - `NOT EXISTS (... "habitLogId" = hl.id)` -- the deduplication
 *     contract: a HabitLog whose originating Plan is STILL LIVE is
 *     already counted via the live-Plan path above; this clause is what
 *     prevents it from ever being counted twice. Uses the HabitLog's own
 *     stable id for this existence check, never title/date matching.
 *
 * Covered by the composite index on (userId, completionAttribution,
 * scheduledStartAtSnapshot) and the partial index on
 * PlannedActivity.habitLogId, both added by migration 0049 -- one bounded,
 * indexed query, no N+1. Read-only; no write, no side effect.
 */
export async function countDeletedNonGoalCompletionsInRange(userId: string, from: Date, to: Date): Promise<number> {
  const result = await pool.query(
    `SELECT count(*)::int AS count
     FROM "HabitLog" hl
     WHERE hl."userId" = $1
       AND hl."logSource" = 'AURA_PLANNED'
       AND hl."completionAttribution" = 'NON_GOAL'
       AND hl."originatingPlannedActivityId" IS NOT NULL
       AND hl."scheduledStartAtSnapshot" IS NOT NULL
       AND hl."scheduledStartAtSnapshot" BETWEEN $2 AND $3
       AND NOT EXISTS (
         SELECT 1 FROM "PlannedActivity" pa WHERE pa."habitLogId" = hl.id
       )`,
    [userId, from, to]
  );
  return result.rows[0]?.count ?? 0;
}

/** Insights V1 PR5 -- every row of this user's Move-chain graph: either a
 * row that has itself been moved (status = 'MOVED', an interior/origin
 * link) or a row that was PRODUCED by a move ("rescheduledFromPlanId" is
 * set, a candidate chain terminal). Unbounded by date range -- a chain's
 * own age is irrelevant to detecting it, only its CURRENT terminal's live
 * status matters (apps/web/lib/improvementSignals.ts's own
 * evaluateMoveChains, which reconstructs every chain in memory from this
 * flat edge list, never a second query per chain/hop). By the
 * `rescheduledFromPlanId` FK's own invariant (schema.prisma), any row
 * this set's forward edges point to must itself have status 'MOVED' and
 * therefore already be included here -- a reference that resolves to
 * nothing missing from this set is exactly the "broken chain" case
 * evaluateMoveChains treats as insufficient evidence, never guessed at. */
export interface MoveChainLinkRow {
  id: string;
  status: PlannedActivity['status'];
  rescheduledFromPlanId: string | null;
  movedAt: Date | null;
}

export async function listMoveChainLinksForUser(userId: string): Promise<MoveChainLinkRow[]> {
  const result = await pool.query(
    `SELECT id, status, "rescheduledFromPlanId", "movedAt" FROM "PlannedActivity"
     WHERE "userId" = $1 AND (status = 'MOVED' OR "rescheduledFromPlanId" IS NOT NULL)`,
    [userId]
  );
  return result.rows;
}

// Goals V2 G3.1 -- read-only Goal context for the Home/DailyAgenda read
// model (apps/web/lib/dailyAgenda.ts). Deliberately NOT
// GoalActivityWithLinkedPlanStatus's shape: the client needs MEANING
// (a normalized CompletionRequirement, a measured value), never storage
// structure -- no execution id/source/snapshot columns/timestamps.
export interface PlanGoalContext {
  goal: { id: string; title: string };
  goalActivity: { id: string; completionRequirement: CompletionRequirement };
  currentValue: number | null;
}

/**
 * Goals V2 G3.1 -- ONE batched query for every plan id in a day's agenda,
 * never one query per item (avoids N+1). Keyed by "plannedActivityId" so
 * the caller can do a plain Map lookup per DailyAgendaItem. Scoped to
 * "userId" on the base row (GoalActivity) -- same convention
 * listGoalActivitiesWithLinkedPlanStatus already uses (a LEFT JOIN target
 * is never independently re-scoped by userId in this codebase; the FK
 * relationship itself, plus the owning row's own userId filter, is what
 * already prevents cross-user leakage everywhere else). A plan id with no
 * GoalActivity link simply has no entry in the returned Map -- never a
 * null-valued entry, so `.get(planId)` doubles as a clean existence check.
 * completionKind/TargetValue/Unit are normalized through the canonical G2.1
 * helper (normalizeGoalActivityCompletionRequirement) -- a legacy/never-set
 * GoalActivity therefore always reads as DONE here, exactly like every
 * other consumer of that helper.
 *
 * Multi-Occurrence Rhythm PR 2 corrective fix -- this previously matched
 * ONLY `ga."plannedActivityId"` (the singular, "most recently
 * materialized occurrence" column), so every sibling occurrence except
 * the newest silently got no Goal context at all anywhere this function
 * feeds (Home/My Day's daily agenda, Day Recompose, the Recomposition
 * move card). The query is now a UNION of the legacy singular-link match
 * (unchanged, still the only path for a NONE-rhythm/finite GoalActivity)
 * with a second branch resolving through the authoritative occurrence
 * ledger (`GoalActivityOccurrence.plannedActivityId`) -- so EVERY
 * occurrence's own Plan resolves to the same, correct Goal context,
 * independent of which single occurrence the singular column currently
 * references. `UNION` (not `UNION ALL`) de-duplicates the common case
 * where a plan is both an occurrence's own link AND currently the
 * singular pointer -- each plan id still produces exactly one result row.
 */
export async function loadGoalContextsForPlanIds(userId: string, planIds: readonly string[]): Promise<Map<string, PlanGoalContext>> {
  const contexts = new Map<string, PlanGoalContext>();
  if (planIds.length === 0) return contexts;
  const result = await pool.query(
    `SELECT matched."plannedActivityId", matched."goalActivityId", matched."completionKind", matched."completionTargetValue", matched."completionUnit",
            matched."goalId", matched."goalTitle", gae."currentValue"
     FROM (
       SELECT ga."plannedActivityId" AS "plannedActivityId", ga.id AS "goalActivityId", ga."completionKind", ga."completionTargetValue", ga."completionUnit",
              g.id AS "goalId", g.title AS "goalTitle"
       FROM "GoalActivity" ga
       JOIN "Goal" g ON g.id = ga."goalId"
       WHERE ga."userId" = $1 AND ga."plannedActivityId" = ANY($2::text[])
       UNION
       SELECT gao."plannedActivityId" AS "plannedActivityId", ga.id AS "goalActivityId", ga."completionKind", ga."completionTargetValue", ga."completionUnit",
              g.id AS "goalId", g.title AS "goalTitle"
       FROM "GoalActivityOccurrence" gao
       JOIN "GoalActivity" ga ON ga.id = gao."goalActivityId"
       JOIN "Goal" g ON g.id = ga."goalId"
       WHERE gao."userId" = $1 AND gao."plannedActivityId" = ANY($2::text[])
     ) matched
     LEFT JOIN "GoalActivityExecution" gae ON gae."plannedActivityId" = matched."plannedActivityId"`,
    [userId, [...planIds]]
  );
  for (const row of result.rows) {
    contexts.set(row.plannedActivityId, {
      goal: { id: row.goalId, title: row.goalTitle },
      goalActivity: {
        id: row.goalActivityId,
        completionRequirement: normalizeGoalActivityCompletionRequirement({
          completionKind: row.completionKind,
          completionTargetValue: row.completionTargetValue,
          completionUnit: row.completionUnit,
        }),
      },
      currentValue: row.currentValue,
    });
  }
  return contexts;
}

/**
 * Goals V2 Rhythm R2 -- READ-ONLY fact loader for the pure eligibility
 * engine (apps/web/lib/goalActivityRhythm.ts's own
 * computeGoalActivityRhythmEligibility). User-scoped, one query, no
 * occurrence/plan/execution/GoalActivity row is ever created, updated or
 * deleted here (this ticket's own section 23). Policy logic itself lives
 * entirely in the pure engine -- this function does nothing but join and
 * shape rows; it holds no eligibility semantics of its own.
 *
 * Only occurrences with a LIVE linked PlannedActivity (INNER JOIN) produce
 * a fact -- an occurrence with a null plannedActivityId has no date to
 * belong to any week yet, and R1/R2 together never create one anyway (no
 * production occurrence writer exists). `localDate` is derived via
 * getDatePartsInTimezone from the plan's OWN plannedStartAt, in the
 * caller-supplied timezone -- never the server's own clock/timezone.
 *
 * Rhythm R3 -- `executor` is optional (defaults to `pool`, same convention
 * as `goalHasRetainedPlanLinkage`) so the authoritative, pre-materialization
 * re-check (`materializeGoalActivityRhythmOccurrence`, below) can read
 * facts on the SAME transaction client as the write it is about to
 * authorize, inside the caller's own per-user advisory lock -- never a
 * second, unlocked connection racing the write it is meant to gate.
 */
export async function loadGoalActivityRhythmFacts(userId: string, goalActivityId: string, timezone: string, executor: Pool | PoolClient = pool): Promise<GoalActivityRhythmOccurrenceFact[]> {
  const result = await executor.query(
    `SELECT pa."plannedStartAt", pa.status, gao."scheduledWeekStart", gao."scheduledWeekTimezone", (gae.id IS NOT NULL) AS "hasCompletedExecution"
     FROM "GoalActivityOccurrence" gao
     LEFT JOIN "PlannedActivity" pa ON pa.id = gao."plannedActivityId"
     LEFT JOIN "GoalActivityExecution" gae ON gae."goalActivityOccurrenceId" = gao.id
     WHERE gao."userId" = $1 AND gao."goalActivityId" = $2`,
    [userId, goalActivityId]
  );
  return result.rows
    .map((row): GoalActivityRhythmOccurrenceFact | null => {
      const localDate = resolveOccurrenceLocalDateOrNull(
        { scheduledWeekStart: row.scheduledWeekStart, scheduledWeekTimezone: row.scheduledWeekTimezone },
        row.plannedStartAt ? new Date(row.plannedStartAt) : null,
        timezone
      );
      if (localDate === null) return null; // unattributable: pre-PR2 legacy occurrence whose plan was later deleted -- never fabricate a week
      return {
        localDate,
        contribution: deriveGoalActivityRhythmContributionWithEvidence(row.hasCompletedExecution, row.status as PlannedActivityStatusForRhythm | null),
      };
    })
    .filter((fact): fact is GoalActivityRhythmOccurrenceFact => fact !== null);
}

/**
 * Goals V2 Rhythm R4 -- ONE batched query for every N_PER_WEEK GoalActivity
 * on a single Goal Detail page, never one query per activity (this
 * ticket's own section 40; same batching convention as
 * loadGoalContextsForPlanIds above). Purely an N+1 fix: the per-row shaping
 * is identical to loadGoalActivityRhythmFacts above (same localDate
 * derivation, same deriveGoalActivityRhythmContribution mapping) -- this is
 * NOT a second eligibility/counting implementation, just a batched way to
 * produce the same facts for several activities in one round trip. A
 * goalActivityId with zero occurrences simply has no entry in the returned
 * Map (never an empty-array entry), matching loadGoalContextsForPlanIds'
 * own "no entry means none" convention.
 */
/** O5 P2d -- one occurrence's raw database row for the Rhythm facts: which GoalActivity, when its linked plan starts, and that
 * plan's status. Detached scalars (the instant is returned as read; callers copy it).
 * Insights V1 PR3 -- plannedStartAt/status are now nullable: the join to
 * PlannedActivity is LEFT, not INNER, so an occurrence whose plan has
 * been hard-deleted still produces a row (previously it would simply
 * vanish from the result set). hasCompletedExecution is the durable,
 * goalActivityOccurrenceId-linked completion fact (see
 * buildGoalActivityRhythmFactsFromOccurrenceRows below). */
export interface GoalActivityOccurrenceRow {
  goalActivityId: string;
  plannedStartAt: Date | string | null;
  status: string | null;
  /** Insights V1 PR2 -- the occurrence's own scheduled-week snapshot, if written (see resolveOccurrenceLocalDate). */
  scheduledWeekStart: string | null;
  scheduledWeekTimezone: string | null;
  hasCompletedExecution: boolean;
}

/** The raw read behind `loadGoalActivityRhythmFactsForActivities`, separated so the SAME rows can be read
 * through a snapshot executor and turned into facts later by the same pure mapping.
 * Insights V1 PR3 -- both joins widened to LEFT (PlannedActivity may be
 * hard-deleted; the new GoalActivityExecution join supplies durable
 * completion evidence that survives that deletion). */
export async function listGoalActivityOccurrenceRowsForActivities(userId: string, goalActivityIds: readonly string[], executor: ReadQueryExecutor = pool): Promise<GoalActivityOccurrenceRow[]> {
  if (goalActivityIds.length === 0) return [];
  const result = await executor.query(
    `SELECT gao."goalActivityId", pa."plannedStartAt", pa.status, gao."scheduledWeekStart", gao."scheduledWeekTimezone", (gae.id IS NOT NULL) AS "hasCompletedExecution"
     FROM "GoalActivityOccurrence" gao
     LEFT JOIN "PlannedActivity" pa ON pa.id = gao."plannedActivityId"
     LEFT JOIN "GoalActivityExecution" gae ON gae."goalActivityOccurrenceId" = gao.id
     WHERE gao."userId" = $1 AND gao."goalActivityId" = ANY($2::text[])`,
    [userId, [...goalActivityIds]]
  );
  return result.rows;
}

/** Pure: the per-activity Rhythm occurrence facts for already-read rows (the shaping `loadGoalActivityRhythmFactsForActivities`
 * has always applied). A goalActivityId with no rows has no entry.
 * Insights V1 PR3 -- an unattributable row (no scheduled-week snapshot
 * and no live plan to derive from, a pre-PR2 legacy occurrence whose
 * plan was later deleted) is silently excluded, same as
 * loadGoalActivityRhythmFacts's own identical fallback -- never
 * fabricated, never crashes the whole batch. */
export function buildGoalActivityRhythmFactsFromOccurrenceRows(rows: readonly GoalActivityOccurrenceRow[], timezone: string): Map<string, GoalActivityRhythmOccurrenceFact[]> {
  const factsByActivity = new Map<string, GoalActivityRhythmOccurrenceFact[]>();
  for (const row of rows) {
    const localDate = resolveOccurrenceLocalDateOrNull(
      { scheduledWeekStart: row.scheduledWeekStart, scheduledWeekTimezone: row.scheduledWeekTimezone },
      row.plannedStartAt ? new Date(row.plannedStartAt) : null,
      timezone
    );
    if (localDate === null) continue;
    const fact: GoalActivityRhythmOccurrenceFact = {
      localDate,
      contribution: deriveGoalActivityRhythmContributionWithEvidence(row.hasCompletedExecution, row.status as PlannedActivityStatusForRhythm | null),
    };
    const existing = factsByActivity.get(row.goalActivityId);
    if (existing) existing.push(fact);
    else factsByActivity.set(row.goalActivityId, [fact]);
  }
  return factsByActivity;
}

export async function loadGoalActivityRhythmFactsForActivities(userId: string, goalActivityIds: readonly string[], timezone: string): Promise<Map<string, GoalActivityRhythmOccurrenceFact[]>> {
  return buildGoalActivityRhythmFactsFromOccurrenceRows(await listGoalActivityOccurrenceRowsForActivities(userId, goalActivityIds), timezone);
}

// Goals V2 Multi-Occurrence Rhythm PR 2 -- the ownership-scoped discovery
// query for "which of this user's N_PER_WEEK GoalActivities are
// structurally eligible to be CONSIDERED for another occurrence."
//
// PR 2 removes the single-live-plan exclusion this query previously
// applied (`pa.status IS DISTINCT FROM 'UPCOMING'`, joined off
// GoalActivity's own singular `plannedActivityId`): a GoalActivity with
// one already-UPCOMING occurrence is no longer excluded outright merely
// for having one -- weekly CAPACITY (via the occurrence ledger, not this
// singular pointer) is the only remaining gate, exactly as
// materializeGoalActivityRhythmOccurrence (below) now also enforces.
// Dropping that filter also removes its join target: the `PlannedActivity`
// LEFT JOIN served no other purpose (no column from it is selected).
//
// Weekly CAPACITY is still deliberately NOT evaluated in SQL -- that
// stays the authoritative, already-tested
// evaluateNewOccurrenceEligibility/computeGoalActivityRhythmEligibility
// (goalActivityOccurrenceCapacity.ts / goalActivityRhythm.ts), applied by
// the caller (goalDemandCandidates.ts) against a second, batched facts
// query, never duplicated here as a second counting formula. Scoped by
// "userId" on GoalActivity only (ga."userId" = $1) -- the same convention
// loadGoalContextsForPlanIds above already established: a JOIN target is
// never independently re-scoped by userId, the FK relationship plus the
// owning row's own filter is what already prevents cross-user leakage
// throughout this file. ARCHIVED Goals and Rhythm NONE/undefined
// activities are still filtered in SQL, never pulled back just to be
// discarded in application code.
export interface CandidateGoalActivityForRhythmDemandRow {
  goalActivityId: string;
  goalId: string;
  goalTitle: string;
  title: string;
  activityId: string | null;
  rhythmKind: string | null;
  rhythmTargetPerWeek: number | null;
}

export async function loadCandidateGoalActivitiesForRhythmDemand(userId: string, executor: ReadQueryExecutor = pool): Promise<CandidateGoalActivityForRhythmDemandRow[]> {
  const result = await executor.query(
    `SELECT ga.id AS "goalActivityId", ga."goalId", g.title AS "goalTitle", ga.title, ga."activityId",
            ga."rhythmKind", ga."rhythmTargetPerWeek"
     FROM "GoalActivity" ga
     JOIN "Goal" g ON g.id = ga."goalId"
     WHERE ga."userId" = $1
       AND g.status = 'ACTIVE'
       AND ga.status != 'DISMISSED'
       AND ga."rhythmKind" = 'N_PER_WEEK'
     ORDER BY ga.id`,
    [userId]
  );
  return result.rows;
}

export type MaterializeGoalActivityRhythmOccurrenceResult =
  | { ok: true; occurrenceId: string }
  | { ok: false; reason: 'NOT_FOUND' | 'NOT_RHYTHM_ELIGIBLE' | 'CAPACITY_EXHAUSTED' };

/**
 * Goals V2 Rhythm R3, extended by Multi-Occurrence Rhythm PR 2 -- the one
 * write this slice introduces: "an N_PER_WEEK GoalActivity with weekly
 * capacity remaining links a NEWLY CREATED PlannedActivity and records a
 * new GoalActivityOccurrence." Called from EXACTLY ONE place
 * (dayConstructorAcceptancePersistence.ts's own write loop), on the SAME
 * `client` as the PlannedActivity insert that already happened
 * immediately before it, tried FIRST for every Goal-linked write (a pure,
 * side-effect-free read -- `NOT_RHYTHM_ELIGIBLE` -- for any GoalActivity
 * whose own rhythmKind isn't 'N_PER_WEEK'). The existing, UNCHANGED
 * `linkGoalActivityToPlannedActivity` is tried only as the fallback for
 * that exact `NOT_RHYTHM_ELIGIBLE` case, and alone still owns every
 * NONE/first-link/CANCELLED-or-SKIPPED-relink case exactly as before R3
 * (the finite legacy path is untouched). This ordering (Rhythm-aware
 * tried first) is what lets ONE call correctly cover a brand-new
 * N_PER_WEEK GoalActivity's very FIRST occurrence too -- the legacy
 * function alone would successfully link a NULL-plannedActivityId
 * GoalActivity but would never create the occurrence row every N_PER_WEEK
 * link requires.
 *
 * PR 2 removes the single-live-commitment rejection (formerly
 * HAS_LIVE_COMMITMENT, returned whenever the CURRENT linked plan was
 * UPCOMING) for N_PER_WEEK activities: an already-UPCOMING occurrence no
 * longer blocks a further one by itself. The ONLY remaining gate is
 * weekly capacity, below, via `evaluateNewOccurrenceEligibility`
 * (goalActivityOccurrenceCapacity.ts, PR 1's own pure capacity API, wired
 * in here verbatim -- no new/duplicated arithmetic). NONE-rhythm
 * activities are unaffected: they already return `NOT_RHYTHM_ELIGIBLE`
 * one line earlier and never reach this gate either before or after this
 * change.
 *
 * EVERY check here reads FRESH state on this same client, inside the
 * caller's own already-held per-user advisory lock
 * (`day-constructor-accept:<userId>`, persistAcceptedConstructedDay) --
 * this is what makes two genuinely concurrent requests for the same user
 * safe without any new locking: the second request blocks on the SAME
 * lock key until the first's transaction fully commits or rolls back, then
 * re-reads this exact fresh state and correctly sees reduced (or
 * exhausted) capacity. A GENUINE RETRY of the identical acceptance (same
 * clientRequestId) never reaches this function a second time at all -- it
 * short-circuits at the EXISTING PlanCreationIdempotency replay check,
 * before the write loop even starts (the existing mechanism is reused
 * verbatim, never duplicated).
 *
 * Creates the occurrence with no status, no windowKey, no Rhythm/
 * CompletionRequirement snapshot -- R1's own minimal shape, unextended.
 *
 * `GoalActivity.plannedActivityId` (still a singular, `@unique` column)
 * is repointed to THIS newest occurrence's plan on every successful call
 * -- "most recently materialized", never "the one live commitment" now
 * that more than one occurrence can be live at once. Existing siblings'
 * OWN `GoalActivityOccurrence.plannedActivityId` rows are never read or
 * written by this repoint; each occurrence's link is independent and
 * never overwritten by another occurrence's write (proved in PR 1's own
 * DB suite, goalActivityOccurrenceCapacityDb.test.ts, scenarios C-E/H).
 */
export async function materializeGoalActivityRhythmOccurrence(
  userId: string,
  goalActivityId: string,
  newPlannedActivityId: string,
  plannedStartAt: Date,
  planningLocalDate: string,
  timezone: string,
  client: PoolClient
): Promise<MaterializeGoalActivityRhythmOccurrenceResult> {
  const gaRes = await client.query(
    `SELECT ga.status, ga."rhythmKind", ga."rhythmTargetPerWeek"
     FROM "GoalActivity" ga
     WHERE ga.id = $1 AND ga."userId" = $2`,
    [goalActivityId, userId]
  );
  if (gaRes.rows.length === 0) return { ok: false, reason: 'NOT_FOUND' };
  const row = gaRes.rows[0];
  if (row.status === 'DISMISSED') return { ok: false, reason: 'NOT_FOUND' };

  const rhythm = normalizeGoalActivityRhythm({ rhythmKind: row.rhythmKind, rhythmTargetPerWeek: row.rhythmTargetPerWeek });
  if (rhythm.kind !== 'N_PER_WEEK') return { ok: false, reason: 'NOT_RHYTHM_ELIGIBLE' };

  const facts = await loadGoalActivityRhythmFacts(userId, goalActivityId, timezone, client);
  const eligibility = evaluateNewOccurrenceEligibility({ rhythm, planningLocalDate, occurrences: facts });
  if (!eligibility.eligible) return { ok: false, reason: 'CAPACITY_EXHAUSTED' };

  const relinked = await client.query(
    `UPDATE "GoalActivity" SET "plannedActivityId" = $1, "updatedAt" = now()
     WHERE id = $2 AND "userId" = $3 AND status != 'DISMISSED' AND "rhythmKind" = 'N_PER_WEEK'`,
    [newPlannedActivityId, goalActivityId, userId]
  );
  if ((relinked.rowCount ?? 0) !== 1) return { ok: false, reason: 'NOT_FOUND' };

  const occurrenceId = randomUUID();
  // Insights V1 PR2 -- the scheduled-week snapshot is written atomically,
  // in this SAME INSERT, from the exact `timezone`/`plannedStartAt` this
  // call is already authoritative for -- never a separate statement, so
  // there is no window where the occurrence exists without its snapshot.
  // `localCalendarWeekStart` is the repository's one existing canonical
  // week-start function (goalActivityRhythm.ts) -- no second algorithm.
  const scheduledWeekStart = localCalendarWeekStart(getDatePartsInTimezone(timezone, plannedStartAt).dateStr);
  await client.query(
    `INSERT INTO "GoalActivityOccurrence" (id, "userId", "goalActivityId", "plannedActivityId", "scheduledWeekStart", "scheduledWeekTimezone") VALUES ($1, $2, $3, $4, $5, $6)`,
    [occurrenceId, userId, goalActivityId, newPlannedActivityId, scheduledWeekStart, timezone]
  );
  return { ok: true, occurrenceId };
}

/**
 * Goals -> Planning Integration V1 PR C -- the one atomic write that
 * closes the GoalActivity -> PlannedActivity handoff. Called from INSIDE
 * the existing Day Constructor acceptance transaction
 * (dayConstructorAcceptancePersistence.ts), on the SAME `client`, never
 * as a second request/eventual-consistency repair (this PR's own section
 * 26).
 *
 * A single conditional UPDATE, not a check-then-act pair (this PR's own
 * section 25/27: "use conditional linkage semantics", avoiding a TOCTOU
 * race entirely) -- ownership (`userId`), non-DISMISSED, and eligibility
 * are all enforced in the WHERE clause itself, so the row either matches
 * exactly the one eligible GoalActivity or matches nothing at all.
 *
 * ELIGIBILITY (this PR's own section 29, the mandatory design check):
 * linkage is allowed when the GoalActivity is currently unlinked
 * (`plannedActivityId IS NULL`) OR its existing link points at a
 * PlannedActivity that is itself CANCELLED or SKIPPED for this same user -- the
 * exact "safe rule" the ticket proposes, and the only rule consistent
 * with PR A's own established derived-state semantics: a linked-but-
 * CANCELLED GoalActivity already derives back to SUGGESTED
 * (deriveGoalActivityState, lib/goals.ts) and is therefore already
 * eligible for re-selection at the handoff bootstrap boundary
 * (resolveGoalActivityHandoff, planDayBootstrap.ts) -- requiring a bare
 * `plannedActivityId IS NULL` here would silently make that already-
 * eligible state impossible to ever actually replan, a real
 * inconsistency between the two layers. A GoalActivity linked to an
 * UPCOMING or LOGGED Plan is NEVER eligible -- this function never
 * steals/relinks a currently retained active linkage.
 *
 * Returns true iff EXACTLY ONE row was linked. The caller MUST treat
 * `false` as a hard failure and roll back the entire transaction (this
 * PR's own section 27: "if zero rows: throw -> rollback... do not
 * silently continue") -- this function itself never throws; the
 * rowCount check is the caller's own explicit decision point.
 */
export async function linkGoalActivityToPlannedActivity(
  userId: string,
  goalActivityId: string,
  plannedActivityId: string,
  executor: Pool | PoolClient = pool
): Promise<boolean> {
  const result = await executor.query(
    `UPDATE "GoalActivity"
     SET "plannedActivityId" = $1, "updatedAt" = now()
     WHERE id = $2
       AND "userId" = $3
       AND status != 'DISMISSED'
       AND (
         "plannedActivityId" IS NULL
         OR "plannedActivityId" IN (
           SELECT id FROM "PlannedActivity" WHERE "userId" = $3 AND status IN ('CANCELLED', 'SKIPPED')
         )
       )`,
    [plannedActivityId, goalActivityId, userId]
  );
  return (result.rowCount ?? 0) === 1;
}

/**
 * Goal LIFECYCLE authorization for planning acceptance.
 *
 * Archiving a Goal revokes its authority to produce NEW Goal-derived
 * planning state. For the GoalActivities (owned by `userId`) in
 * `goalActivityIds`, this returns which ones are owned and which of those
 * have a parent Goal that is owned by the same user AND currently ACTIVE.
 * `Goal.status` is the sole lifecycle authority (`archivedAt` is only the
 * audit timestamp archiveGoal sets alongside it and nothing ever clears);
 * ANY status other than exactly 'ACTIVE' is treated as not active.
 *
 * It runs on the caller's TRANSACTION client and takes a SHARE lock on the
 * parent Goal rows (`FOR SHARE OF g`) that is held until that transaction
 * ends. archiveGoal's UPDATE needs a conflicting row lock, so an archive
 * that is in flight when the acceptance reads makes the acceptance WAIT and
 * then see ARCHIVED, and an archive arriving after the read waits until the
 * acceptance commits: the ACTIVE check and the Goal-provenance writes
 * cannot be separated by a concurrent archive. One batched query for the
 * whole request, never one per item. Read-only apart from the lock.
 *
 * Activities this user does not own (or that do not exist) are absent from
 * `owned`; the existing ownership / existence checks at the write keep
 * rejecting them exactly as before, so this adds no new failure shape for
 * them.
 */
export async function lockGoalParentLifecycleForPlanning(
  userId: string,
  goalActivityIds: readonly string[],
  client: PoolClient
): Promise<{ owned: ReadonlySet<string>; active: ReadonlySet<string> }> {
  const owned = new Set<string>();
  const active = new Set<string>();
  if (goalActivityIds.length === 0) return { owned, active };
  const result = await client.query(
    `SELECT ga.id AS "goalActivityId", g."userId" AS "goalUserId", g.status AS "goalStatus"
     FROM "GoalActivity" ga
     JOIN "Goal" g ON g.id = ga."goalId"
     WHERE ga."userId" = $1 AND ga.id = ANY($2::text[])
     FOR SHARE OF g`,
    [userId, [...goalActivityIds]]
  );
  for (const row of result.rows) {
    owned.add(row.goalActivityId);
    if (row.goalUserId === userId && row.goalStatus === 'ACTIVE') active.add(row.goalActivityId);
  }
  return { owned, active };
}

// ============================================================
// Quick Capture V1 PR A (migration 0036) -- see lib/captures.ts.
// ============================================================

export interface Capture {
  id: string;
  userId: string;
  title: string;
  status: 'OPEN' | 'DISMISSED';
  completedAt: Date | null;
  plannedActivityId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface CaptureWithLinkedPlanStatus extends Capture {
  linkedPlanStatus: 'UPCOMING' | 'LOGGED' | 'CANCELLED' | 'SKIPPED' | 'MOVED' | null;
}

/** Validates via the same pure rule the API uses; duplicates are allowed. */
export async function createCapture(userId: string, title: string): Promise<Capture> {
  const checked = validateCaptureTitle(title);
  if (!checked.ok) throw new Error(checked.error);
  const result = await pool.query(
    `INSERT INTO "Capture" (id, "userId", title) VALUES ($1, $2, $3) RETURNING *`,
    [randomUUID(), userId, checked.title]
  );
  return result.rows[0];
}

/**
 * Every Capture the user owns (any state), newest first, LEFT JOINed to the
 * linked PlannedActivity's status so deriveCaptureState can run per row
 * without an N+1. Deliberately NOT filtered to the active list: callers
 * apply isActiveCaptureState (lib/captures.ts) so completed/dismissed rows
 * stay retrievable for future history/review.
 */
export async function listCapturesWithLinkedPlanStatus(userId: string): Promise<CaptureWithLinkedPlanStatus[]> {
  const result = await pool.query(
    `SELECT c.*, pa.status AS "linkedPlanStatus"
     FROM "Capture" c
     LEFT JOIN "PlannedActivity" pa ON pa.id = c."plannedActivityId"
     WHERE c."userId" = $1
     ORDER BY c."createdAt" DESC, c.id`,
    [userId]
  );
  return result.rows;
}

export async function getCaptureWithLinkedPlanStatus(userId: string, captureId: string): Promise<CaptureWithLinkedPlanStatus | null> {
  const result = await pool.query(
    `SELECT c.*, pa.status AS "linkedPlanStatus"
     FROM "Capture" c
     LEFT JOIN "PlannedActivity" pa ON pa.id = c."plannedActivityId"
     WHERE c.id = $1 AND c."userId" = $2`,
    [captureId, userId]
  );
  return result.rows[0] ?? null;
}

export type CompleteCaptureResult =
  | { result: 'COMPLETED'; capture: CaptureWithLinkedPlanStatus }
  | { result: 'ALREADY_COMPLETED'; capture: CaptureWithLinkedPlanStatus }
  | { result: 'NOT_FOUND' }
  | { result: 'DISMISSED' }
  | { result: 'HAS_LIVE_PLAN' };

/**
 * Direct completion ("I did it without scheduling it"). ONE conditional
 * UPDATE carries every invariant (owned, OPEN, not already completed, no
 * live UPCOMING plan), so two concurrent completes / a complete racing a
 * remove cannot both win. Creates no PlannedActivity and no HabitLog.
 *
 * A retained CANCELLED link stays as historical provenance. A LOGGED link
 * with a null completedAt (transitional) materializes completedAt from the
 * plan's real loggedAt. A repeat call never moves completedAt: the first
 * timestamp stays authoritative (ALREADY_COMPLETED).
 */
export async function completeCapture(userId: string, captureId: string): Promise<CompleteCaptureResult> {
  const updated = await pool.query(
    `UPDATE "Capture" c
     SET "completedAt" = COALESCE(
           (SELECT pa."loggedAt" FROM "PlannedActivity" pa WHERE pa.id = c."plannedActivityId" AND pa.status = 'LOGGED'),
           now()
         ),
         "updatedAt" = now()
     WHERE c.id = $1 AND c."userId" = $2 AND c.status = 'OPEN' AND c."completedAt" IS NULL
       AND NOT EXISTS (SELECT 1 FROM "PlannedActivity" pa WHERE pa.id = c."plannedActivityId" AND pa.status = 'UPCOMING')
     RETURNING c.id`,
    [captureId, userId]
  );
  const current = await getCaptureWithLinkedPlanStatus(userId, captureId);
  if (!current) return { result: 'NOT_FOUND' };
  if ((updated.rowCount ?? 0) === 1) return { result: 'COMPLETED', capture: current };
  if (current.status === 'DISMISSED') return { result: 'DISMISSED' };
  if (current.completedAt) return { result: 'ALREADY_COMPLETED', capture: current };
  return { result: 'HAS_LIVE_PLAN' };
}

export type RemoveCaptureResult = 'DELETED' | 'DISMISSED' | 'NOT_FOUND' | 'HAS_LIVE_PLAN';

/**
 * "I don't need to do this anymore." Row-locks the Capture (FOR UPDATE) so a
 * concurrent link/complete cannot race past the decision:
 *  - live UPCOMING plan            -> HAS_LIVE_PLAN (cancel the plan first)
 *  - never linked, never completed -> hard DELETE
 *  - any history (retained link or completedAt) -> status = DISMISSED,
 *    keeping completedAt and the link (completion history is never destroyed)
 * Already-DISMISSED is an idempotent 'DISMISSED'.
 */
export async function removeCapture(userId: string, captureId: string): Promise<RemoveCaptureResult> {
  const client = await beginTransaction();
  try {
    const res = await client.query(
      `SELECT c.status, c."completedAt", c."plannedActivityId", pa.status AS "linkedPlanStatus"
       FROM "Capture" c
       LEFT JOIN "PlannedActivity" pa ON pa.id = c."plannedActivityId"
       WHERE c.id = $1 AND c."userId" = $2
       FOR UPDATE OF c`,
      [captureId, userId]
    );
    const row = res.rows[0];
    if (!row) {
      await client.query('ROLLBACK');
      return 'NOT_FOUND';
    }
    if (row.status === 'DISMISSED') {
      await client.query('ROLLBACK');
      return 'DISMISSED';
    }
    if (row.linkedPlanStatus === 'UPCOMING') {
      await client.query('ROLLBACK');
      return 'HAS_LIVE_PLAN';
    }
    if (!row.plannedActivityId && !row.completedAt) {
      await client.query(`DELETE FROM "Capture" WHERE id = $1 AND "userId" = $2`, [captureId, userId]);
      await client.query('COMMIT');
      return 'DELETED';
    }
    await client.query(`UPDATE "Capture" SET status = 'DISMISSED', "updatedAt" = now() WHERE id = $1 AND "userId" = $2`, [captureId, userId]);
    await client.query('COMMIT');
    return 'DISMISSED';
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Quick Capture V1 PR B -- the atomic Capture -> PlannedActivity link, the
 * exact sibling of linkGoalActivityToPlannedActivity. Called from INSIDE the
 * Day Constructor acceptance transaction on the same `client`. One
 * conditional UPDATE (no check-then-act): owned by this user, status OPEN,
 * not completed, and either unlinked or linked to a CANCELLED/SKIPPED plan of the
 * same user (replan replaces the retained link; the old plan stays as
 * history). Returns false when nothing matched -- the caller decides
 * (acceptance throws, rolling back the whole transaction).
 */
export async function linkCaptureToPlannedActivity(
  userId: string,
  captureId: string,
  plannedActivityId: string,
  executor: Pool | PoolClient = pool
): Promise<boolean> {
  const result = await executor.query(
    `UPDATE "Capture"
     SET "plannedActivityId" = $1, "updatedAt" = now()
     WHERE id = $2
       AND "userId" = $3
       AND status = 'OPEN'
       AND "completedAt" IS NULL
       AND (
         "plannedActivityId" IS NULL
         OR "plannedActivityId" IN (
           SELECT id FROM "PlannedActivity" WHERE "userId" = $3 AND status IN ('CANCELLED', 'SKIPPED')
         )
       )`,
    [plannedActivityId, captureId, userId]
  );
  return (result.rowCount ?? 0) === 1;
}
