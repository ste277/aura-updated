import type { DailyAgenda, DailyAgendaItem } from './dailyAgenda';
import { getMinuteOfDayInTimezone, getDatePartsInTimezone } from './timezone';
import { INTENTION_GROUPS, DailyIntentionGroupId, DailyIntentionActivity } from './dailyIntentions';
import { findActivityIntent } from '../../../packages/recommendation/src/personalizedTasks';
import type { TimingCandidate } from '../../../packages/recommendation/src/timingSearch';
import type { EverydaySharedCandidate } from '../../../packages/recommendation/src/everydayTimingFit';
import type { SavedPersonRelationshipType } from './db';

/**
 * Intentional Day Builder V1 -- the pure, deterministic domain layer (brief
 * sections 4/5/10/11/12/13/14/16). This is NOT a new timing or scoring
 * engine: it only decides WHAT to consider suggesting and WHETHER a
 * proposed time genuinely fits the day that's already there. The actual
 * time is always found by the existing canonical timing engines
 * (runTimingSearch / findEverydaySharedTiming), called by
 * dayBuilderOrchestrator.ts -- this file never invents a start/end time.
 *
 * "Agenda-as-anchors" (brief section 3): existing Plans/Moments are treated
 * as fixed anchors the day is built around, never as things to compete
 * with or duplicate. deriveAgendaOpenings() below is the whole of that
 * philosophy in code -- it computes what's genuinely free, nothing else.
 */

export interface AgendaOpening {
  /** Minute of the local day, inclusive. Always >= the minuteOfDay this was
   * derived from -- Day Builder only ever looks forward, never backfills a
   * time that's already passed. */
  startMinute: number;
  /** Minute of the local day, exclusive. */
  endMinute: number;
}

/** Below this, no catalog activity's shortest suggested/default duration
 * (10 minutes, e.g. tea-break/task-3) plus a little slack can realistically
 * fit -- not worth carrying forward as a candidate opening. */
const MIN_OPENING_MINUTES = 15;
const MINUTES_PER_DAY = 1440;

/** Brief section 3 -- items that still occupy real time today (anything not
 * already in the past as COMPLETED/MISSED). Only these block an opening;
 * a completed/missed item has no future minutes left to protect. */
function blockingItems(agenda: DailyAgenda): DailyAgendaItem[] {
  return agenda.items.filter((item) => item.status !== 'COMPLETED' && item.status !== 'MISSED' && item.status !== 'SKIPPED' && item.status !== 'MOVED' && item.endAt);
}

/** Local minute-of-day range for one agenda item. Returns null for a
 * (rare) item that crosses local midnight -- deliberately not handled:
 * openings only ever cover a single local day, and a cross-midnight block
 * is still protected indirectly (it still occupies presentActivityIds/
 * presentGroupIds for dedup purposes; only the minute-accurate opening math
 * skips it). Documented limitation, not a silent bug. */
function itemMinuteRange(item: DailyAgendaItem, timezone: string): { start: number; end: number } | null {
  if (!item.endAt) return null;
  const start = getMinuteOfDayInTimezone(timezone, new Date(item.startAt));
  const end = getMinuteOfDayInTimezone(timezone, new Date(item.endAt));
  if (end <= start) return null;
  return { start, end };
}

/**
 * Pure interval math: today's [now, end of local day) minus every
 * still-upcoming agenda item's own time block, merged into contiguous free
 * stretches. No astrology, no scoring -- just what's actually free.
 */
export function deriveAgendaOpenings(input: { agenda: DailyAgenda; minuteOfDay: number }): AgendaOpening[] {
  const { agenda, minuteOfDay } = input;
  const covered = new Array(MINUTES_PER_DAY).fill(false);
  for (let m = 0; m < Math.min(minuteOfDay, MINUTES_PER_DAY); m++) covered[m] = true;

  for (const item of blockingItems(agenda)) {
    const range = itemMinuteRange(item, agenda.timezone);
    if (!range) continue;
    for (let m = Math.max(0, range.start); m < Math.min(MINUTES_PER_DAY, range.end); m++) covered[m] = true;
  }

  const openings: AgendaOpening[] = [];
  let curStart = -1;
  for (let m = 0; m < MINUTES_PER_DAY; m++) {
    if (!covered[m]) {
      if (curStart === -1) curStart = m;
    } else if (curStart !== -1) {
      if (m - curStart >= MIN_OPENING_MINUTES) openings.push({ startMinute: curStart, endMinute: m });
      curStart = -1;
    }
  }
  if (curStart !== -1 && MINUTES_PER_DAY - curStart >= MIN_OPENING_MINUTES) {
    openings.push({ startMinute: curStart, endMinute: MINUTES_PER_DAY });
  }
  return openings;
}

/** Brief section 14: a resolved timing candidate is only usable if it
 * genuinely lands inside an already-computed opening AND on today's local
 * date (defensive -- the canonical engines are asked for TODAY only, this
 * just confirms rather than trusts blindly). Never adjusts or re-scores
 * the candidate; only accepts or rejects it as-is. */
export function candidateFitsOpenings(
  candidate: { start: string; end: string },
  openings: AgendaOpening[],
  timezone: string,
  localDate: string
): boolean {
  const startDate = getDatePartsInTimezone(timezone, new Date(candidate.start)).dateStr;
  if (startDate !== localDate) return false;
  const start = getMinuteOfDayInTimezone(timezone, new Date(candidate.start));
  const end = getMinuteOfDayInTimezone(timezone, new Date(candidate.end));
  if (end <= start) return false;
  return openings.some((o) => start >= o.startMinute && end <= o.endMinute);
}

export interface DayProfile {
  minuteOfDay: number;
  /** Nothing at all on today's agenda, past or future. */
  isEmpty: boolean;
  /** Brief section 13/29: a day that already has 3+ still-upcoming items is
   * treated as full -- Day Builder proposes nothing rather than crowding it
   * further. Zero suggestions is the correct, expected result here. */
  isBusy: boolean;
  /** No agenda item starts at/after 17:00 local -- same definition
   * dailyStory.ts's own isEveningOpen() already uses, computed
   * independently here since dayBuilder.ts intentionally has no dependency
   * on dailyStory.ts (kept as two separate, independently-testable pure
   * layers). */
  hasEveningOpen: boolean;
  /** Canonical activityIds already on today's agenda (Plan/Moment/logged
   * activity), resolved via the same findActivityIntent() title match
   * habitLogToAgendaItem() already uses for its icon lookup -- exact-id
   * dedup, brief section 12 level 1. */
  presentActivityIds: Set<string>;
  /** Every DailyIntentionGroupId already represented by something on
   * today's agenda (any activity in that group already present) --
   * diversity/semantic dedup, brief section 12 level 2 (a group already
   * "covered" by the real day is not suggested again). */
  presentGroupIds: Set<DailyIntentionGroupId>;
  openings: AgendaOpening[];
  longestOpeningMinutes: number;
}

/** Personalized Daily Story V2 -- the single per-item taxonomy-group
 * resolver, extracted so buildDayProfile's own presentGroupIds and the new
 * buildDailyPriorityCoverage() below always agree on "what taxonomy
 * group(s) does this agenda item represent" without maintaining two
 * separate resolution implementations (brief section 1: "do not duplicate
 * ... derivation"). An activityId can legitimately belong to more than one
 * group (e.g. 'coffee-tea' is in RELATIONSHIPS, SOCIAL, and ENJOYMENT) --
 * every matching group is returned, not just one canonical pick. */
function resolveItemIntentionGroups(item: DailyAgendaItem): DailyIntentionGroupId[] {
  const resolved = findActivityIntent(item.title);
  if (!resolved) return [];
  return INTENTION_GROUPS.filter((g) => g.activities.some((a) => a.activityId === resolved.id)).map((g) => g.id);
}

export function buildDayProfile(agenda: DailyAgenda, minuteOfDay: number): DayProfile {
  const presentActivityIds = new Set<string>();
  const presentGroupIds = new Set<DailyIntentionGroupId>();
  for (const item of agenda.items) {
    if (item.status === 'SKIPPED' || item.status === 'MOVED') continue; // a skipped or moved (superseded) occurrence does not represent the activity as present at this time
    const resolved = findActivityIntent(item.title);
    if (resolved) presentActivityIds.add(resolved.id);
    for (const groupId of resolveItemIntentionGroups(item)) presentGroupIds.add(groupId);
  }

  // Bug fix (Home Compactness follow-up -- "your evening is open" shown
  // even with several evening activities added): `.getHours()` reads the
  // Date in the SERVER PROCESS's own local timezone (UTC in production),
  // not the user's configured `agenda.timezone` -- a 6pm IST item is
  // 12:30pm UTC, whose .getHours() is 12, never >=17. Every local dev/test
  // run on this machine (also IST) coincidentally matched, hiding this in
  // every prior test run. getMinuteOfDayInTimezone is the same
  // timezone-correct helper every other hour-of-day check in this
  // codebase already uses.
  const hasEveningOpen = !agenda.items.some((item) => {
    if (item.status === 'COMPLETED' || item.status === 'MISSED' || item.status === 'SKIPPED' || item.status === 'MOVED') return false;
    return Math.floor(getMinuteOfDayInTimezone(agenda.timezone, new Date(item.startAt)) / 60) >= 17;
  });

  const openings = deriveAgendaOpenings({ agenda, minuteOfDay });
  const longestOpeningMinutes = openings.reduce((max, o) => Math.max(max, o.endMinute - o.startMinute), 0);
  const upcomingCount = agenda.items.filter((i) => i.status !== 'COMPLETED' && i.status !== 'MISSED' && i.status !== 'SKIPPED' && i.status !== 'MOVED').length;

  return {
    minuteOfDay,
    isEmpty: agenda.items.length === 0,
    isBusy: upcomingCount >= 3,
    hasEveningOpen,
    presentActivityIds,
    presentGroupIds,
    openings,
    longestOpeningMinutes,
  };
}

/** People-oriented groups -- the ones a real SavedPerson relationship can
 * resolve a SHARED candidate + Invite action for (brief section 21). */
export const PEOPLE_GROUP_IDS: DailyIntentionGroupId[] = ['RELATIONSHIPS', 'FAMILY', 'SOCIAL'];

/** Maps a people-oriented group to the SavedPersonRelationshipType values
 * eligible for it -- e.g. a RELATIONSHIPS suggestion looks for a PARTNER or
 * SPOUSE, never a FRIEND. FAMILY/SOCIAL similarly. Deliberately excludes
 * OTHER from SOCIAL's own explicit list here (OTHER is a genuine catch-all,
 * only used as SOCIAL's fallback in the orchestrator when no FRIEND exists). */
export const PEOPLE_GROUP_RELATIONSHIP_TYPES: Record<string, SavedPersonRelationshipType[]> = {
  RELATIONSHIPS: ['PARTNER', 'SPOUSE'],
  FAMILY: ['FAMILY'],
  SOCIAL: ['FRIEND', 'OTHER'],
};

export interface IntentionCandidate {
  groupId: DailyIntentionGroupId;
  activity: DailyIntentionActivity;
  isPeopleOriented: boolean;
  /** "Why today?" -- template-based, grounded in real DayProfile facts,
   * never LLM-generated prose (brief section 16). */
  reason: string;
}

/** Brief section 16 -- deterministic, template-based reasons grounded only
 * in facts buildDayProfile() already derived (evening open or not, whether
 * anything else is competing for the time). No new signal, no free text.
 *
 * Personalized Daily Story V2 (brief section 7) -- `isPrioritized` swaps in
 * a warmer, ownership-acknowledging phrasing when this candidate's group
 * is one of the user's own explicit priorities. Deliberately never spells
 * out the internal UserPriorityGroup/DailyIntentionGroupId name, an
 * activityId, SHARED/SOLO, or any score -- prose only, same discipline as
 * the generic branches below. */
function reasonForCandidate(groupId: DailyIntentionGroupId, profile: DayProfile, isPrioritized = false): string {
  const isPeople = PEOPLE_GROUP_IDS.includes(groupId);
  if (isPrioritized) {
    if (isPeople) {
      return profile.hasEveningOpen
        ? 'A good opening to spend some time together this evening.'
        : 'A good opening to spend some time together.';
    }
    if (groupId === 'WORK') return 'A little room for focused work before your plans later.';
    if (groupId === 'SELF') return 'This fits naturally with what you said matters to you.';
    return 'This fits one of the things that matters most to you lately.';
  }
  if (isPeople && profile.hasEveningOpen) return 'Your evening is open — a good chance to make room for someone.';
  if (isPeople) return "Nothing else is using this time — a good window to connect with someone.";
  if (groupId === 'WORK') return 'You have a clear stretch open for focused work.';
  if (groupId === 'SELF') return 'Some open time today to do something just for you.';
  return 'Room today to enjoy something, with nothing else competing for the time.';
}

/**
 * Home Compactness follow-up ("a date night or an evening walk shows time
 * slots in the morning and afternoon") -- most evening-social activities
 * (Date Night, Family Dinner, Dinner With Friends, ...) now carry their own
 * `timeOfDayPreference: 'EVENING'` directly on the shared catalog entry
 * (activityDefinitions.ts), which runTimingSearch's FIND mode applies as
 * its default automatically -- no per-caller override needed for those.
 *
 * 'walk-together' is the one exception: the exact same catalog entry also
 * serves the SELF taxonomy group's daytime "Walk" (dailyIntentions.ts), so
 * giving it a blanket catalog-level EVENING default would wrongly
 * constrain that morning/anytime use too. This function is the ONLY place
 * that distinguishes the two -- using the taxonomy GROUP context
 * (isPeopleOriented, i.e. was this candidate selected from RELATIONSHIPS/
 * FAMILY/SOCIAL, which is where "Walk together" as a social occasion
 * actually comes from) that only the caller (dayBuilderOrchestrator.ts)
 * has, since dayBuilder.ts's own selection doesn't carry a raw activityId
 * string this deep. Returns undefined for every other activity, meaning
 * "no override -- let the catalog's own default (if any) apply".
 */
export function resolvePeopleContextTimePreference(activityId: string, isPeopleOriented: boolean): 'EVENING' | undefined {
  return activityId === 'walk-together' && isPeopleOriented ? 'EVENING' : undefined;
}

/** Brief section 10/11/13 -- select candidates from the existing taxonomy
 * BEFORE any timing search runs (performance: search is the expensive
 * step, so only a small, already-diverse, already-deduped set is ever
 * handed to it). Returns [] whenever the day genuinely has no room left --
 * zero is a valid, expected result (brief section 13), not a fallback to
 * avoid. */
/**
 * Personalization Foundation V1 -- the user-facing "what matters most
 * lately?" choices (brief section 2/5). Deliberately a SEPARATE, smaller
 * presentation enum from DailyIntentionGroupId, not a new taxonomy in its
 * own right: every value below maps onto one or more EXISTING
 * DailyIntentionGroupId groups via PRIORITY_GROUP_TO_INTENTION_GROUPS
 * (brief section 1: "do not create a parallel activity taxonomy"). This
 * only ever affects candidate ORDERING (applyUserPriorities below) --
 * never which activities exist, never any score.
 */
export type UserPriorityGroup = 'RELATIONSHIPS' | 'WORK' | 'WELLBEING' | 'ENJOYMENT' | 'PERSONAL_GROWTH' | 'ROUTINE';

export const USER_PRIORITY_GROUPS: Array<{ id: UserPriorityGroup; label: string; icon: string }> = [
  { id: 'RELATIONSHIPS', label: 'Relationships', icon: '❤️' },
  { id: 'WORK', label: 'Work', icon: '💼' },
  { id: 'WELLBEING', label: 'Wellbeing', icon: '🏃' },
  { id: 'PERSONAL_GROWTH', label: 'Personal growth', icon: '🌱' },
  { id: 'ENJOYMENT', label: 'Enjoyment', icon: '🎉' },
  { id: 'ROUTINE', label: 'Routine', icon: '☕' },
];

/** Reuse mapping, not a new one: RELATIONSHIPS (the user-facing choice)
 * reasonably spans all three of the taxonomy's own people-oriented groups
 * (dailyIntentions.ts has no separate "family" or "friends" choice in the
 * brief's suggested 6). WELLBEING -> SELF ("do something for myself" --
 * workout/walk/meditation/quiet time, dailyIntentions.ts's own framing).
 * PERSONAL_GROWTH -> WORK: the taxonomy's only "Learning" activity lives
 * in the WORK group (dailyIntentions.ts has no dedicated growth/learning
 * group) -- the closest honest reuse, not a fabricated new one. ROUTINE ->
 * LIFE ("errands & home", dailyIntentions.ts's own existing, if
 * not-yet-first-level-surfaced, group). */
export const PRIORITY_GROUP_TO_INTENTION_GROUPS: Record<UserPriorityGroup, DailyIntentionGroupId[]> = {
  RELATIONSHIPS: ['RELATIONSHIPS', 'FAMILY', 'SOCIAL'],
  WORK: ['WORK'],
  WELLBEING: ['SELF'],
  PERSONAL_GROWTH: ['WORK'],
  ENJOYMENT: ['ENJOYMENT'],
  ROUTINE: ['LIFE'],
};

export function resolvePrioritizedIntentionGroups(priorities: UserPriorityGroup[]): Set<DailyIntentionGroupId> {
  const result = new Set<DailyIntentionGroupId>();
  for (const priority of priorities) {
    for (const groupId of PRIORITY_GROUP_TO_INTENTION_GROUPS[priority] ?? []) result.add(groupId);
  }
  return result;
}

/**
 * Personalized Daily Story V2 (brief section 5) -- "has the user already
 * made room today for something belonging to this explicit priority?"
 * Deliberately NOT scoring: a boolean-ish COVERED/OPEN state plus which
 * real agenda item(s) earned it, nothing weighted or ranked. Built from
 * the SAME per-item group resolution buildDayProfile() uses
 * (resolveItemIntentionGroups), applied with a DIFFERENT status filter:
 * MISSED items never count (brief: "cancelled/missed items do not falsely
 * imply accomplishment" -- a plan that didn't happen isn't room actually
 * made). CANCELLED plans never reach here at all (buildDailyAgenda already
 * excludes them). COMPLETED items DO count (brief: "completed items count
 * as covered").
 */
export interface DailyPriorityCoverage {
  priorityGroup: UserPriorityGroup;
  state: 'COVERED' | 'OPEN';
  agendaItemIds: string[];
}

export function buildDailyPriorityCoverage(agenda: DailyAgenda, priorities: UserPriorityGroup[]): DailyPriorityCoverage[] {
  return priorities.map((priorityGroup) => {
    const intentionGroups = new Set(PRIORITY_GROUP_TO_INTENTION_GROUPS[priorityGroup] ?? []);
    const agendaItemIds: string[] = [];
    for (const item of agenda.items) {
      if (item.status === 'MISSED' || item.status === 'SKIPPED' || item.status === 'MOVED') continue;
      const itemGroups = resolveItemIntentionGroups(item);
      if (itemGroups.some((g) => intentionGroups.has(g))) agendaItemIds.push(item.id);
    }
    return { priorityGroup, state: agendaItemIds.length > 0 ? 'COVERED' : 'OPEN', agendaItemIds };
  });
}

/** Convenience for callers (dayBuilderOrchestrator.ts) that need the
 * DailyIntentionGroupId-level union of every COVERED priority's mapped
 * groups, e.g. to pass into applyUserPriorities' coveredGroupIds param. */
export function coveredIntentionGroupIds(coverage: DailyPriorityCoverage[]): Set<DailyIntentionGroupId> {
  const result = new Set<DailyIntentionGroupId>();
  for (const c of coverage) {
    if (c.state !== 'COVERED') continue;
    for (const groupId of PRIORITY_GROUP_TO_INTENTION_GROUPS[c.priorityGroup] ?? []) result.add(groupId);
  }
  return result;
}

/** Brief section 3 -- a stable partition, not a re-sort: every group the
 * user explicitly prioritized moves to the front, IN THEIR ORIGINAL
 * relative order from `baseOrder` (never re-ordered relative to each
 * other by this function -- that relative order already encodes the
 * existing hasEveningOpen heuristic, e.g. RELATIONSHIPS before FAMILY).
 * Groups the user did NOT prioritize keep their own original relative
 * order too, just pushed after. This is ORDERING ONLY: it cannot add,
 * remove, mute, or re-score a candidate -- selectIntentionCandidates'
 * existing mutedGroups/presentGroupIds checks run identically afterward
 * (brief section 6: priorities can never override a mute).
 *
 * Personalized Daily Story V2 (brief section 6) -- `coveredGroupIds`
 * (derived from DailyPriorityCoverage) further splits the prioritized
 * subset in two: STILL-OPEN priorities stay at the very front (most
 * valuable to suggest), already-COVERED priorities move to the back of
 * the whole list -- diversity, not exclusion. A covered priority is never
 * removed or muted, only deprioritized below everything else, so it can
 * still surface if nothing else in the day has room. */
export function applyUserPriorities(
  baseOrder: DailyIntentionGroupId[],
  prioritizedGroupIds: Set<DailyIntentionGroupId>,
  coveredGroupIds: Set<DailyIntentionGroupId> = new Set()
): DailyIntentionGroupId[] {
  if (prioritizedGroupIds.size === 0) return baseOrder;
  const openPrioritized = baseOrder.filter((g) => prioritizedGroupIds.has(g) && !coveredGroupIds.has(g));
  const coveredPrioritized = baseOrder.filter((g) => prioritizedGroupIds.has(g) && coveredGroupIds.has(g));
  const rest = baseOrder.filter((g) => !prioritizedGroupIds.has(g));
  return [...openPrioritized, ...rest, ...coveredPrioritized];
}

export function selectIntentionCandidates(
  profile: DayProfile,
  mutedGroups: Set<DailyIntentionGroupId>,
  maxCandidates: number,
  /** Personalization Foundation V1 -- defaults to empty so every existing
   * caller/test (no personalization configured) is unaffected. */
  prioritizedGroupIds: Set<DailyIntentionGroupId> = new Set(),
  /** Personalized Daily Story V2 (brief section 6) -- which of the
   * prioritized groups are already COVERED today (from
   * buildDailyPriorityCoverage()). Defaults to empty, same
   * backward-compatibility discipline as prioritizedGroupIds. */
  coveredGroupIds: Set<DailyIntentionGroupId> = new Set()
): IntentionCandidate[] {
  if (profile.isBusy) return [];
  if (profile.openings.length === 0) return [];

  const baseOrder: DailyIntentionGroupId[] = profile.hasEveningOpen
    ? ['RELATIONSHIPS', 'FAMILY', 'SOCIAL', 'SELF', 'ENJOYMENT', 'WORK']
    : ['SELF', 'ENJOYMENT', 'WORK', 'RELATIONSHIPS', 'FAMILY', 'SOCIAL'];
  const priorityOrder = applyUserPriorities(baseOrder, prioritizedGroupIds, coveredGroupIds);

  const candidates: IntentionCandidate[] = [];
  // Two-level dedup (brief section 12): level 1 is exact-activityId, tracked
  // globally across every group below (an activityId like 'coffee-tea' that
  // appears in more than one group's list is only ever offered once). Level
  // 2 is "one activity per group" -- a group already chosen doesn't offer a
  // second, near-identical variant of the same kind of intention.
  const seenActivityIds = new Set<string>();

  for (const groupId of priorityOrder) {
    if (candidates.length >= maxCandidates) break;
    if (mutedGroups.has(groupId)) continue;
    // Diversity: a group already represented on today's real agenda isn't
    // genuinely additive to suggest again (brief section 3/11).
    if (profile.presentGroupIds.has(groupId)) continue;

    const group = INTENTION_GROUPS.find((g) => g.id === groupId);
    if (!group) continue;

    for (const activity of group.activities) {
      if (!activity.activityId) continue;
      if (profile.presentActivityIds.has(activity.activityId)) continue;
      if (seenActivityIds.has(activity.activityId)) continue;
      seenActivityIds.add(activity.activityId);
      candidates.push({
        groupId,
        activity,
        isPeopleOriented: PEOPLE_GROUP_IDS.includes(groupId),
        reason: reasonForCandidate(groupId, profile, prioritizedGroupIds.has(groupId)),
      });
      break;
    }
  }

  return candidates;
}

/**
 * Home Compactness + Flexible Day Story V1 (brief section 24/26) -- a
 * suggestion now carries 1-3 already-resolved, ranked timing candidates
 * instead of exactly one. `candidates[0]` is the default-selected slot
 * (highest-ranked); every entry is untouched canonical engine output
 * (runTimingSearch/findEverydaySharedTiming), never re-scored or
 * re-ordered here. Which one is "selected" is purely a client-side UI
 * concern (dayBuilderOrchestrator.ts and this file never track selection
 * state) -- see DayBuilderCard.tsx.
 */
export interface IntentionalDayCandidateSolo {
  kind: 'SOLO';
  candidates: TimingCandidate[];
}

export interface IntentionalDayCandidateShared {
  kind: 'SHARED';
  candidates: EverydaySharedCandidate[];
  person: { id: string; name: string; relationshipType: SavedPersonRelationshipType };
}

export type IntentionalDayCandidate = IntentionalDayCandidateSolo | IntentionalDayCandidateShared;

/** "Not today" dismissal identity: activityId alone for a no-person
 * suggestion, activityId+personId for a people-oriented one -- personId is
 * '' (the DB's own sentinel for "no person") in the no-person case, never
 * undefined/null, so a plain string Set works as the lookup structure.
 * Kept here (not in db.ts) since it's pure string composition, used by
 * both dayBuilderOrchestrator.ts (checking) and the dismiss route
 * (writing) to guarantee they can never drift out of sync. */
export function dismissalKey(activityId: string, personId: string): string {
  return `${activityId}|${personId}`;
}

/**
 * Brief section 17 -- the DTO Daily Story's UI renders. Always carries an
 * already-RESOLVED real time (never just an activity name) -- `candidate`
 * is exactly what the canonical timing engine returned, untouched.
 */
export interface IntentionalDaySuggestion {
  id: string;
  groupId: DailyIntentionGroupId;
  activityId: string;
  label: string;
  icon: string;
  durationMinutes: number;
  reason: string;
  candidate: IntentionalDayCandidate;
}

/**
 * Brief section 24 -- pure selection logic for the "Another idea" swap
 * (used by DayBuilderCard.tsx). Given the currently-visible suggestion ids
 * and the full already-resolved set (visible + reserve, exactly what
 * GET /api/my-day/suggestions returned in one response), returns the NEW
 * visible id list with `outgoingId` replaced by the next not-yet-shown
 * suggestion. A pure array recombination -- no fetch, no timing search, no
 * re-scoring: by construction this function cannot perform I/O (its
 * signature is array-in, array-out), so the replacement can only ever be a
 * suggestion the canonical engines already resolved a real time for in
 * that same original response. Never introduces a duplicate activityId
 * (selectIntentionCandidates already guarantees every suggestion in
 * `allSuggestions` has a globally-unique activityId, so any two entries in
 * its output are automatically distinct too). Returns the list with
 * `outgoingId` simply removed (one fewer visible suggestion) when no
 * reserve candidate remains -- the caller's own "Another idea" control
 * disappearing is a direct, reactive consequence of an empty reserve after
 * this call, not a separate branch to get wrong.
 */
export function swapSuggestion(visibleIds: string[], allSuggestions: IntentionalDaySuggestion[], outgoingId: string): string[] {
  const reserve = allSuggestions.filter((s) => !visibleIds.includes(s.id));
  const next = reserve[0];
  const withoutOutgoing = visibleIds.filter((id) => id !== outgoingId);
  return next ? [...withoutOutgoing, next.id] : withoutOutgoing;
}
