/**
 * Day Constructor V1 -- PR C: real-data orchestration + preview contract.
 *
 * ARCHITECTURAL BOUNDARY (this ticket's own section 3):
 *
 *   REQUEST (real user input)
 *     -> REAL-DATA ADAPTATION (this file)
 *     -> NORMALIZED ConstructDayInput (dayConstructor.ts's own contract)
 *     -> constructDay() (dayConstructor.ts, PURE, untouched)
 *     -> PREVIEW CONTRACT (this file)
 *
 * ORCHESTRATOR ASSEMBLES. CONSTRUCTOR DECIDES. This file makes zero
 * placement decisions of its own: it never ranks candidates, never
 * chooses a slot, never decides what gets deferred. Every one of those
 * decisions is made by `constructDay` (dayConstructor.ts) -- still a
 * pure, synchronous, self-contained function, still with zero callback/
 * I/O capability of its own. Dynamic Candidate Replenishment V1 (see
 * `orchestrateConstructDay`'s own doc comment) means this file may now
 * call it MORE THAN ONCE per orchestration run -- each individual call
 * is byte-identical in shape/behavior to before that amendment; only
 * this file's own OWN coordination between calls is new. This file's
 * job remains turning real, already-fetched application data into the
 * exact inputs `constructDay` already knows how to consume -- now
 * possibly refreshed and re-submitted, never placed here.
 *
 * PREVIEW ONLY (this ticket's own section 2/22/23): this file never
 * calls `createPlannedActivity`, `saveUpcomingPlanFromCandidate`, any
 * `POST /api/plans` equivalent, or anything that mutates a Plan. It
 * returns a `ConstructDayPreview` -- CHECK-before-save and acceptance
 * belong to a future PR.
 */

import type { User, HabitLogRow } from './db';
import { listPlannedActivitiesOverlappingRange, listHabitLogs, listUserAvailabilityPeriods, getDailyWorkPreferences } from './db';
import { resolveAvailability, normalizeUsableWindowsToConstructionWindow, type AvailabilityConfiguration } from './availabilityContext';
import { applyDailyRhythmPreference, explainDailyRhythmPlacement, resolveDailyRhythmSearchLimit, type DailyRhythmPreferencesInput } from './dailyRhythmScheduling';
import { listUserActivityPreferences, type UserActivityPreference } from './activityPreferences';
import { buildDurationContext } from './durationContext';
import { durationMinutesFor, GENERIC_DURATION_FALLBACK_MINUTES } from './dayBuilderOrchestrator';
import { localDayBoundsUTC } from './myDayOrchestrator';
import { resolveTzOffsetMinutes, getDatePartsInTimezone } from './timezone';
import { buildPersonalMuhurtaContextForUser } from './natalContext';
import { findActivityIntent, getActivityProfileById } from '../../../packages/recommendation/src/personalizedTasks';
import { classifyTask } from '../../../packages/recommendation/src/dailyAssistant';
import { familyForActivityProfile } from '../../../packages/recommendation/src/auraFitEngine';
import { runTimingSearch, type TimingCandidate, type TimingCandidateLabel, type TimingSearchRequest } from '../../../packages/recommendation/src/timingSearch';
import type { MuhurtaActivityFamily } from '../../../packages/muhurta/src/muhurtaEngine';
import {
  buildDayIntent,
  validateConstructionWindow,
  sumConstructibleDurationMinutes,
  type ConstructionWindow,
  type ConstructionWindowSource,
  type ConstructionWindowValidationError,
  type DayIntent,
  type DayIntentImportance,
  type DayIntentFlexibility,
} from './dayIntent';
import {
  constructDay,
  constructDayWithTrace,
  type ConstructDayInput,
  type ConstructDayResult,
  type ConstructedDay,
  type FixedPlacementConstraint,
  type PlacementCandidate,
  type PlacementDiagnostic,
  type PlacementTimingFit,
} from './dayConstructor';
import type { BlockedInterval } from './dayCapacity';
import { aggregateContentionTraces, type ContentionTrace } from './contentionTrace';
import { assembleConstructionBasis, captureCandidateLists, type ConstructionBasisOutcome } from './constructionBasis';
import { captureBaselinePlacements, type BaselinePlacementsOutcome } from './baselinePlacements';
import { isActivePlanBlocker, type PlanBlockerStatus, type PlanBlockerCandidate } from './planBlockerLifecycle';
import { resolveDecisionFactsForIntent, type DecisionFactsByIntentId } from './decisionFacts';
import { attachPreparedDecisionFacts, prepareDecisionEvidence, prepareDecisionFactsFailOpen, type DecisionFactPreparer } from './decisionFactPreparation';

// ============================================================
// Request contract (this ticket's own section 4). USER-LEVEL input --
// the caller never manufactures a DayIntent/PlacementCandidate/
// FixedPlacementConstraint directly.
// ============================================================

/**
 * One user-declared outcome/activity, in the shape a real caller (a
 * future PR D form, or Ask Aura) can supply without knowing anything
 * about `DayIntent`'s own internal id-assignment or defaulting rules.
 * `id` is the CALLER's own stable identifier (never generated here) --
 * it survives into `ResolvedIntentSummary.requestedIntentId` and every
 * `ConstructDayWarning.intentId` so a caller can correlate its own
 * request items with the preview's own output, and is threaded straight
 * through as the resulting `DayIntent.id` (see `resolveDayIntent` below)
 * rather than being replaced by `buildDayIntent`'s own auto-incrementing
 * counter, which PR A's own doc comment already anticipates as an
 * orchestration-layer concern ("a future orchestration layer that
 * persists a DayIntent is responsible for assigning a real id at that
 * boundary").
 */
export interface RequestedDayIntent {
  id: string;
  title: string;
  /** USER-PROVIDED, optional. Trusted only after re-validating it is a
   * genuine, current catalog id (this ticket's own section 6: never
   * trust a caller-supplied id blindly) -- an invalid value is treated
   * identically to an omitted one, falling through to alias/classifier
   * resolution from `title`. */
  activityId?: string;
  /** USER-PROVIDED, optional. Wins over every resolved duration source
   * (this ticket's own section 7, step 1). */
  durationMinutes?: number;
  importance?: DayIntentImportance;
  deadline?: string;
  flexibility: DayIntentFlexibility;
  /** Required, and only meaningful, when `flexibility === 'FIXED'` -- the
   * caller's own requested absolute start instant. The matching `end` is
   * always DERIVED by this file from the resolved duration (this
   * ticket's own section 9), never separately supplied -- so a
   * `FixedPlacementConstraint`'s start/end can never disagree with the
   * intent's own resolved duration by construction, for any request this
   * file builds. */
  fixedStart?: Date;
  originalOrder: number;
}

export interface ConstructDayRequest {
  /** Local calendar date (YYYY-MM-DD) the construction window targets --
   * the SAME `dateStr` convention every other date in this pipeline
   * uses. */
  targetDate: string;
  timezone: string;
  constructionWindowSource: ConstructionWindowSource;
  /**
   * ALWAYS required, regardless of `constructionWindowSource` (pre-
   * commit review fix, this ticket's own section 7: "no hidden new
   * Date()... introduce the smallest explicit reference instant
   * required"). Serves two roles, deliberately unified into one field
   * rather than two:
   *
   *   1. For `'REMAINING_TODAY'`: the window's own `start` (unchanged
   *      from the original design).
   *   2. For EITHER window source: the REFERENCE INSTANT
   *      `isActivePlanBlocker` (below) uses to decide whether a
   *      persisted `'UPCOMING'` Plan is still an active commitment or
   *      has already elapsed into a derived `MISSED` state (this
   *      ticket's own section 3/4/5) -- never the server's own clock,
   *      never re-read per Plan.
   *
   * This file never calls `new Date()` itself.
   */
  now: Date;
  /** Required iff `constructionWindowSource === 'EXPLICIT_RANGE'`. */
  explicitStart?: Date;
  explicitEnd?: Date;
  intents: RequestedDayIntent[];
  /** Decision Facts V1 -- OPTIONAL, generic, server-supplied facts keyed
   * by the caller's own intent id (decisionFacts.ts). This file only
   * looks them up; it never fetches, derives, or interprets them, and
   * nothing here reads them for ordering/placement/eligibility. Never
   * set from a client request body (the preview request parser builds
   * this request field-by-field). */
  decisionFactsByIntentId?: DecisionFactsByIntentId;
}

// ============================================================
// Dependency injection boundary (this ticket's own section 27). Narrow,
// explicit seams for the three real-data operations this file needs --
// production defaults wire them to genuine repository functions
// (`createRealDayConstructorOrchestratorDeps` below); tests inject
// deterministic fakes with no DB/network involved.
// ============================================================

// The plan-blocker lifecycle (PlanBlockerStatus, PlanBlockerCandidate,
// isActivePlanBlocker) lives in planBlockerLifecycle.ts and is re-exported
// here unchanged, so every existing importer of this module is unaffected.
export { isActivePlanBlocker, type PlanBlockerStatus, type PlanBlockerCandidate };

export interface DayConstructorOrchestratorDeps {
  /** Real Plan commitments that OVERLAP `bounds` (the target local day
   * together with the resolved construction window, see
   * `resolveBlockerLoadBounds`), whichever civil date a plan started on, in
   * the minimal `PlanBlockerCandidate` shape `isActivePlanBlocker` (above)
   * evaluates -- called EXACTLY ONCE per orchestration run (this ticket's
   * own section 20), never once per intent. Lifecycle filtering
   * (`isActivePlanBlocker`) is applied by `orchestrateConstructDay`
   * itself, AFTER this call returns -- this dependency's own job is
   * only to fetch the raw rows, never to decide which ones block. */
  loadBlockingPlans: (bounds: { from: Date; to: Date }) => Promise<PlanBlockerCandidate[]>;
  /** The two duration-personalization maps `durationMinutesFor`
   * (dayBuilderOrchestrator.ts) already accepts -- fetched ONCE per
   * orchestration run, exactly like `buildIntentionalDaySuggestions`'s
   * own established convention (its own doc comment: "fetched by the
   * CALLER -- this function never fetches preferences/behavior itself"). */
  loadDurationContext: () => Promise<{ preferredDurationByActivityId: Readonly<Record<string, number>>; behavioralDurationByActivityId: Readonly<Record<string, number>> }>;
  /** A thin wrapper around the real, pure, synchronous `runTimingSearch`
   * -- takes everything EXCEPT `context` (already pre-bound by the
   * production factory to the real user's own location/timezone/
   * personalContext at the single `now` this orchestration run uses).
   * Called once per FLEXIBLE intent (this ticket's own section 20: "only
   * if its API inherently requires it"); never for a FIXED intent (this
   * ticket's own section 9). May throw -- `orchestrateConstructDay`
   * catches this explicitly and reports `TIMING_SEARCH_FAILED`, never
   * silently reinterpreting a thrown error as "zero candidates found"
   * (this ticket's own section 19). */
  searchTiming: (request: Omit<TimingSearchRequest, 'context'>) => { candidates: TimingCandidate[] };
  /** Availability Context V1 PR H1 -- the user's saved availability
   * schedule, in the exact shape `resolveAvailability`
   * (availabilityContext.ts) consumes. Called EXACTLY ONCE per
   * orchestration run, same convention as `loadDurationContext` above.
   * This dependency's own job is only to fetch `User.
   * availabilityConfigured` + the raw period rows -- it makes no
   * resolution decision of its own (that stays entirely inside the pure
   * `resolveAvailability`, never duplicated here). */
  loadAvailabilityConfiguration: () => Promise<AvailabilityConfiguration>;
  /** Daily Rhythm V1 PR DR2 -- the user's saved work-hours preference
   * (DR1's own `User.dailyRhythmWork{Start,End,Days}`), in the exact
   * shape `applyDailyRhythmPreference`/`explainDailyRhythmPlacement`
   * (dailyRhythmScheduling.ts) consume. Called EXACTLY ONCE per
   * orchestration run, same convention as `loadAvailabilityConfiguration`
   * above -- this dependency's own job is only to fetch the raw
   * preference, never to decide workday/overlap/classification (that
   * stays entirely inside the pure dailyRhythmScheduling.ts, never
   * duplicated here). A user who never configured Daily Rhythm (DR1's
   * own both-null convention) resolves to `{workStart: null, workEnd:
   * null, workDays: []}`, which `isDailyRhythmConfigured` treats as "no
   * preference" -- zero behavior change for any such user. OPTIONAL
   * (same convention as `prepareDecisionFacts` below): omitting it is
   * byte-identical to the user never having configured Daily Rhythm, so
   * an existing caller that builds its own `DayConstructorOrchestratorDeps`
   * without this field (e.g. Remaining-Day Recomposition's own adapter,
   * remainingDayRecomposition.ts) keeps compiling and behaving exactly
   * as before DR2 -- this ticket's own explicit scope boundary. */
  loadDailyRhythmPreferences?: () => Promise<DailyRhythmPreferencesInput>;
  /** Constructor Decision Intelligence O5 P1 -- OPTIONAL. Prepares trusted
   * decision facts for the resolved intents BEFORE `constructDay` runs
   * (decisionFactPreparation.ts). The orchestrator only coordinates it: it
   * never reads a prepared fact, never passes one to `constructDay`, and
   * treats any failure as "no prepared facts". Omitting it is byte-identical
   * to this dependency never having existed. */
  prepareDecisionFacts?: DecisionFactPreparer;
}

/**
 * Real production wiring. Reuses existing repository functions verbatim
 * -- no new DB query shape, no new engine call:
 *
 *   - `listPlannedActivitiesOverlappingRange` (db.ts) -- the ONE half-open
 *     overlap definition (`start < to AND end > from`) the multi-day
 *     scheduling-range loader already uses. It deliberately replaces
 *     `listPlannedActivitiesForDay`, which selects by `plannedStartAt`
 *     alone and therefore never loaded a plan that starts before the day
 *     but runs into it (an overnight/multi-day plan), letting a new
 *     activity be proposed inside an occupied interval. Its SQL filter
 *     excludes `CANCELLED`; `status` is passed straight through
 *     (verbatim, not re-derived) to `isActivePlanBlocker` (this file's
 *     own lifecycle adapter, pre-commit review fix), which is what
 *     decides LOGGED-vs-UPCOMING-vs-elapsed-MISSED blocking -- this
 *     factory itself performs NO filtering of its own.
 *   - `listUserActivityPreferences` + `preferredDurationByActivityId`
 *     (activityPreferences.ts), `listHabitLogs` + `deriveBehavioralProfile`
 *     + `activityDurationByActivityId` (behavioralAffinity.ts) -- the
 *     SAME two-map assembly `dayBuilderOrchestrator.ts`'s own callers
 *     already perform before calling `durationMinutesFor`.
 *   - `runTimingSearch` (timingSearch.ts) -- called verbatim, with
 *     `context` pre-bound from the real `user`/`now` this factory
 *     closes over (`resolveTzOffsetMinutes`, `buildPersonalMuhurtaContextForUser`
 *     -- the SAME two calls `buildIntentionalDaySuggestions` already
 *     makes to build its own `DailyAssistantContext`).
 */
/**
 * The half-open `[from, to)` range the blocker load must cover: the target
 * local civil day AND the resolved construction window. They coincide for
 * every ordinary window (a window lies inside its day); an explicit window
 * that reaches past either end of the civil day extends the range so a plan
 * overlapping the window is still loaded. Pure -- the loader never clips
 * (`normalizeBlockedIntervals` in dayCapacity.ts owns clipping to the window).
 */
export function resolveBlockerLoadBounds(dayBounds: { from: Date; to: Date }, window: { start: Date; end: Date }): { from: Date; to: Date } {
  return {
    from: window.start.getTime() < dayBounds.from.getTime() ? window.start : dayBounds.from,
    to: window.end.getTime() > dayBounds.to.getTime() ? window.end : dayBounds.to,
  };
}

export function createRealDayConstructorOrchestratorDeps(user: User, now: Date): DayConstructorOrchestratorDeps {
  return {
    loadBlockingPlans: async (bounds) => {
      const plans = await listPlannedActivitiesOverlappingRange(user.id, bounds.from, bounds.to);
      return plans.map((plan) => ({ start: new Date(plan.plannedStartAt), end: new Date(plan.plannedEndAt), status: plan.status }));
    },
    loadDurationContext: async () => {
      const [preferences, habitLogs]: [UserActivityPreference[], HabitLogRow[]] = await Promise.all([listUserActivityPreferences(user.id), listHabitLogs(user.id)]);
      return buildDurationContext(preferences, habitLogs, user.timezone, now);
    },
    searchTiming: (request) => {
      const context: TimingSearchRequest['context'] = {
        now,
        latitude: user.latitude,
        longitude: user.longitude,
        timezone: user.timezone,
        tzOffsetMinutes: resolveTzOffsetMinutes(user.timezone, now),
        personalContext: buildPersonalMuhurtaContextForUser(user),
      };
      return runTimingSearch({ ...request, context } as TimingSearchRequest);
    },
    loadAvailabilityConfiguration: async () => {
      const periods = await listUserAvailabilityPeriods(user.id);
      return {
        configured: user.availabilityConfigured === true,
        periods: periods.map((row) => ({ weekday: row.weekday as AvailabilityConfiguration['periods'][number]['weekday'], startTime: row.startTime, endTime: row.endTime })),
      };
    },
    loadDailyRhythmPreferences: async () => {
      const prefs = await getDailyWorkPreferences(user.id);
      return prefs ? { workStart: prefs.workStart, workEnd: prefs.workEnd, workDays: prefs.workDays } : { workStart: null, workEnd: null, workDays: [] };
    },
  };
}

// ============================================================
// Timing label mapping (this ticket's own section 11) -- ONE explicit
// adapter, defined exactly once, reused for every candidate. Mirrors
// `homeTimelineComposer.ts`'s own established `mapTimingLabelToHomeStatus`
// tier collapse (EXCELLENT/VERY_GOOD -> best tier, GOOD -> good tier,
// USABLE -> workable tier, CAUTION -> caution tier) -- NOT imported from
// there (that function returns presentation-cased 'Best'/'Good'/etc.
// strings for a different, presentation-owned type; importing it here
// would blur this file's own domain boundary), but semantically
// identical and non-arbitrary: every one of the five real
// `TimingCandidateLabel` values maps to exactly one `PlacementTimingFit`
// tier with no ambiguity, so this file never had to stop and ask for a
// product decision here (this ticket's own section 11's own escape
// hatch was not needed).
// ============================================================

export function mapTimingLabelToPlacementFit(label: TimingCandidateLabel): PlacementTimingFit {
  switch (label) {
    case 'EXCELLENT':
    case 'VERY_GOOD':
      return 'BEST';
    case 'GOOD':
      return 'GOOD';
    case 'USABLE':
      return 'WORKABLE';
    case 'CAUTION':
      return 'CAUTION';
  }
}

// ============================================================
// Intent resolution (this ticket's own section 6). Preferred hierarchy,
// implemented literally:
//   1. explicit, RE-VALIDATED activityId (never trusted blindly)
//   2. findActivityIntent alias/title match
//   3. classifyTask coarse-family fallback (NEVER fabricates an
//      activityId -- activityId stays undefined, only activityFamily is
//      set, exactly this ticket's own "allowed: activityId = undefined,
//      activityFamily = resolved coarse family. Do not invent a catalog
//      match" instruction).
// ============================================================

interface ActivityResolution {
  activityId?: string;
  activityFamily?: MuhurtaActivityFamily;
  resolvedToCoarseFamily: boolean;
}

function resolveActivity(requested: RequestedDayIntent): ActivityResolution {
  if (requested.activityId) {
    const validated = getActivityProfileById(requested.activityId);
    if (validated) return { activityId: validated.id, activityFamily: familyForActivityProfile(validated), resolvedToCoarseFamily: false };
    // A supplied but unrecognized activityId is never trusted -- fall
    // through to title-based resolution exactly as if none had been
    // supplied at all (this ticket's own section 6: "Trusted only after
    // re-validating it is a genuine, current catalog id").
  }
  const aliasMatch = findActivityIntent(requested.title);
  if (aliasMatch) return { activityId: aliasMatch.id, activityFamily: familyForActivityProfile(aliasMatch), resolvedToCoarseFamily: false };

  const classified = classifyTask(requested.title);
  return { activityId: undefined, activityFamily: classified.family, resolvedToCoarseFamily: true };
}

// ============================================================
// Duration resolution (this ticket's own section 7, extended by Intent
// Fidelity V1 PR G2). Reuses `durationMinutesFor` (dayBuilderOrchestrator.ts)
// verbatim -- the SAME canonical chain already documented there: explicit
// preference -> behavioral typical duration -> catalog default -> catalog
// suggested -> `GENERIC_DURATION_FALLBACK_MINUTES`. That floor is NOT a
// new arbitrary fallback invented by this file -- it is
// `durationMinutesFor`'s own, already-canonical, already-shipped final
// case, and its own existing test suite already proves it is a general
// "no activity-specific signal at all" default (it fires even for a
// syntactically-valid but nonexistent activity id), not one scoped to
// resolved catalog activities.
//
// PR G2 (post-V1 audit gap G2): a free-text intent that never resolved a
// real `activityId` (a pure coarse-family fallback, or no classification
// signal at all) used to leave `estimatedDurationMinutes` `undefined`
// here -- `durationMinutesFor` cannot be called at all without a real
// `activityId` string (it looks up `getActivityDefinition(activityId)`
// internally), and the domain-level 45-minute floor lived ONLY inside
// that function, unreachable from this branch. This file still never
// fabricates a placeholder id merely to reach that function (identity
// and duration estimation stay separate concerns, this ticket's own
// section 7/9) -- instead it now applies the SAME
// `GENERIC_DURATION_FALLBACK_MINUTES` directly, since the audit
// confirmed that value already means "no better information exists,"
// which is exactly the situation an unresolved `activityId` represents.
// `fromGenericFallback: true` here activates the SAME already-shipped
// `DURATION_FROM_GENERIC_FALLBACK` warning/"Estimated duration" preview
// copy a resolved activity would get from `durationMinutesFor`'s own
// final case -- no new presentation path, this file's own already-built
// one simply becomes reachable for this input shape too.
// ============================================================

interface DurationResolution {
  estimatedDurationMinutes?: number;
  /** True whenever the returned value came from the generic duration
   * floor rather than an explicit request, a stored preference, a
   * behavioral pattern, or a real catalog default/suggested duration --
   * whether that floor was reached via `durationMinutesFor` (a resolved
   * activity with no stronger signal) or applied directly here (no
   * resolved activity at all, this ticket's own PR G2). An explanation
   * fact, not a failure. */
  fromGenericFallback: boolean;
}

function resolveDuration(
  requested: RequestedDayIntent,
  activityId: string | undefined,
  durationContext: { preferredDurationByActivityId: Readonly<Record<string, number>>; behavioralDurationByActivityId: Readonly<Record<string, number>> }
): DurationResolution {
  if (requested.durationMinutes !== undefined) return { estimatedDurationMinutes: requested.durationMinutes, fromGenericFallback: false };
  if (!activityId) return { estimatedDurationMinutes: GENERIC_DURATION_FALLBACK_MINUTES, fromGenericFallback: true };

  const resolved = durationMinutesFor(activityId, durationContext.preferredDurationByActivityId, durationContext.behavioralDurationByActivityId);
  const cameFromPreference = durationContext.preferredDurationByActivityId[activityId] !== undefined;
  const cameFromBehavior = durationContext.behavioralDurationByActivityId[activityId] !== undefined;
  const catalogProfile = getActivityProfileById(activityId);
  const cameFromCatalog = catalogProfile?.defaultDurationMinutes !== undefined;
  return { estimatedDurationMinutes: resolved, fromGenericFallback: !cameFromPreference && !cameFromBehavior && !cameFromCatalog };
}

/**
 * Availability Context V1 PR H1 hardening -- the ONE shared per-intent
 * resolution step (`resolveActivity` + `resolveDuration` +
 * `buildDayIntent`), extracted so the CONFIGURED_EMPTY early-exit path
 * below and the normal per-intent loop both call the EXACT SAME code,
 * never a second/duplicated resolution. Deliberately excludes
 * `runTimingSearch`/`FixedPlacementConstraint` construction -- those are
 * placement concerns, not duration-resolution concerns (this ticket's
 * own section 9/13: "duration resolution and timing search are separate
 * concerns... avoid duplicating resolveActivity/resolveDuration... if
 * existing orchestration can expose/reuse them cleanly"), so a caller
 * that only needs a resolved `DayIntent` (e.g. to sum requested minutes)
 * never pays for a timing-search call it doesn't need.
 */
function resolveRequestedDayIntent(
  requested: RequestedDayIntent,
  targetDate: string,
  durationContext: { preferredDurationByActivityId: Readonly<Record<string, number>>; behavioralDurationByActivityId: Readonly<Record<string, number>> }
): { dayIntent: DayIntent; warnings: ConstructDayWarning[] } {
  const warnings: ConstructDayWarning[] = [];
  const activity = resolveActivity(requested);
  if (activity.resolvedToCoarseFamily) warnings.push({ intentId: requested.id, code: 'ACTIVITY_RESOLVED_TO_COARSE_FAMILY' });

  const duration = resolveDuration(requested, activity.activityId, durationContext);
  if (duration.fromGenericFallback) warnings.push({ intentId: requested.id, code: 'DURATION_FROM_GENERIC_FALLBACK' });

  // buildDayIntent performs its own validation/defaulting (importance,
  // flexibility, dates); its auto-assigned `id` is then overridden with
  // the caller's own requested id (see RequestedDayIntent.id's own doc
  // comment) -- everything else about the built DayIntent is kept.
  const built = buildDayIntent(
    {
      title: requested.title,
      targetDate,
      deadline: requested.deadline,
      importance: requested.importance,
      activityId: activity.activityId,
      activityFamily: activity.activityFamily,
      estimatedDurationMinutes: duration.estimatedDurationMinutes,
      flexibility: requested.flexibility,
    },
    requested.originalOrder
  );
  return { dayIntent: { ...built, id: requested.id }, warnings };
}

// ============================================================
// Warnings (this ticket's own section 18) -- distinct from constructor
// failures. A warning never turns a valid proposal into an error.
// ============================================================

/** Daily Rhythm V1 PR DR2 -- three new codes, appended (never replacing
 * or renumbering an existing one). Generated once, AFTER construction
 * (including every replenishment round) has fully settled, from each
 * FLEXIBLE `ProposedItem`'s own final placed start/end -- never
 * speculatively from a candidate that wasn't actually chosen, and never
 * for a FIXED placement (see explainDailyRhythmPlacement's own doc
 * comment). */
export type ConstructDayWarningCode =
  | 'ACTIVITY_RESOLVED_TO_COARSE_FAMILY'
  | 'DURATION_FROM_GENERIC_FALLBACK'
  | 'NO_TIMING_CANDIDATES_FOUND'
  | 'DAILY_RHYTHM_PERSONAL_OUTSIDE_WORK_HOURS'
  | 'DAILY_RHYTHM_PERSONAL_DURING_WORK_HOURS_FALLBACK'
  | 'DAILY_RHYTHM_FLEXIBLE_BREAK_DURING_WORK_HOURS';

export interface ConstructDayWarning {
  /** The REQUESTED intent's own caller-supplied id (never the internal
   * `DayIntent.id`, though for this file's own construction the two are
   * always identical -- see `RequestedDayIntent.id`'s own doc comment). */
  intentId: string;
  code: ConstructDayWarningCode;
}

// ============================================================
// Preview contract (this ticket's own section 17). Small, sufficient for
// a future PR D to render what Aura proposes, what could not be placed
// and why, capacity state, and which times were Aura-selected vs.
// user-fixed -- without inventing any UI copy here.
// ============================================================

export interface ResolvedIntentSummary {
  requestedIntentId: string;
  dayIntent: DayIntent;
}

export interface ConstructDayPreview {
  targetDate: string;
  timezone: string;
  constructionWindow: ConstructionWindow;
  resolvedIntents: ResolvedIntentSummary[];
  constructedDay: ConstructedDay;
  warnings: ConstructDayWarning[];
}

/**
 * Top-level orchestration result. `'READY'` carries the full preview.
 * `'NO_USABLE_CAPACITY'`/`'INVALID_CONSTRUCTION_WINDOW'`/`'TIMEZONE_MISSING'`
 * are passed straight through from `constructDay`'s own fail-closed
 * contract (dayConstructor.ts/dayCapacity.ts) -- never re-derived or
 * re-worded here. `'INVALID_REQUEST'` covers a malformed
 * `ConstructDayRequest` itself (this ticket's own section 5: e.g.
 * `REMAINING_TODAY` without `now`, `EXPLICIT_RANGE` without explicit
 * bounds) caught BEFORE any real-data fetch is attempted.
 * `'TIMING_SEARCH_FAILED'` is the explicit distinction this ticket's own
 * section 19 requires: a thrown/failed search is never silently
 * reinterpreted as "this intent simply has no good candidates" (which
 * stays a legitimate, non-error `NO_CANDIDATES` deferral inside
 * `constructedDay.deferredItems`).
 */
export type OrchestrateConstructDayResult =
  | { status: 'READY'; preview: ConstructDayPreview }
  | { status: 'NO_USABLE_CAPACITY'; constructionWindowMinutes: number; blockedMinutes: number; requestedMinutes: number }
  | { status: 'INVALID_CONSTRUCTION_WINDOW'; error: ConstructionWindowValidationError }
  | { status: 'TIMEZONE_MISSING' }
  | { status: 'INVALID_REQUEST'; reason: string }
  | { status: 'TIMING_SEARCH_FAILED'; requestedIntentId: string; reason: string }
  /** Planning Horizon V1 PR P1 (this ticket's own section 8/12/13/22) --
   * `constructionWindowSource === 'REMAINING_TODAY'`, availability is
   * UNCONFIGURED, and `targetDate` is NOT the caller's own current civil
   * day. The pre-P1 REMAINING_TODAY fallback (`start = request.now`,
   * `end = that future day's own midnight`) is only ever correct when
   * `targetDate` IS today -- reusing it for a future date would silently
   * construct a window spanning from right now through a LATER day's
   * midnight. Rather than inventing a full-civil-day/default-daytime/
   * 9-5 fallback (which `dayIntent.ts`'s own locked principle forbids:
   * "the constructor must never pretend that an application default
   * represents known user availability"), this fails closed: future
   * planning requires a real, saved Availability configuration. `TODAY`
   * + UNCONFIGURED is completely unaffected -- see
   * `resolveAvailabilityAwareWindow` below. */
  | { status: 'FUTURE_AVAILABILITY_REQUIRED' };

// ============================================================
// Construction window resolution (this ticket's own section 5) -- no
// silent working-day/sleep inference. REMAINING_TODAY's own `start` is
// the request's own explicit `now`; its `end` is the target local day's
// own midnight boundary (`localDayBoundsUTC`, the SAME canonical
// dateStr-based helper Forward Planner/Daily Agenda already use --
// never a server-local calendar day). EXPLICIT_RANGE uses the caller's
// own explicit bounds verbatim.
// ============================================================

type ConstructionWindowResolution =
  | { status: 'READY'; window: ConstructionWindow }
  | { status: 'INVALID_REQUEST'; reason: string }
  | { status: 'TIMEZONE_MISSING' }
  | { status: 'INVALID_CONSTRUCTION_WINDOW'; error: ConstructionWindowValidationError };

export function resolveConstructionWindow(request: ConstructDayRequest): ConstructionWindowResolution {
  if (!request.timezone || !request.timezone.trim()) return { status: 'TIMEZONE_MISSING' };
  // `now` is required for BOTH window sources as of the pre-commit
  // review fix (see ConstructDayRequest.now's own doc comment) -- a
  // defensive runtime check here, since a JS/JSON caller crossing a
  // request boundary is not bound by the TypeScript type.
  if (!(request.now instanceof Date) || Number.isNaN(request.now.getTime())) return { status: 'INVALID_REQUEST', reason: 'now must be a valid Date, for either constructionWindowSource.' };

  let start: Date;
  let end: Date;
  if (request.constructionWindowSource === 'REMAINING_TODAY') {
    start = request.now;
    end = localDayBoundsUTC(request.targetDate, request.timezone).to;
  } else {
    if (!request.explicitStart || !request.explicitEnd) return { status: 'INVALID_REQUEST', reason: 'explicitStart and explicitEnd are required when constructionWindowSource is EXPLICIT_RANGE.' };
    start = request.explicitStart;
    end = request.explicitEnd;
  }

  const window: ConstructionWindow = { date: request.targetDate, start, end, timezone: request.timezone, source: request.constructionWindowSource };
  const error = validateConstructionWindow(window);
  if (error) return error.code === 'TIMEZONE_MISSING' ? { status: 'TIMEZONE_MISSING' } : { status: 'INVALID_CONSTRUCTION_WINDOW', error };
  return { status: 'READY', window };
}

// ============================================================
// Candidate normalization (this ticket's own section 10/12/13).
//
// SAFETY OF candidate.start AS AN EXACT PLACEMENT START (this ticket's
// own section 12, the "STOP if unsafe" checkpoint): confirmed safe, no
// stop required. `runTimingSearch`'s FIND mode (timingSearch.ts) always
// receives `durationMinutes` as a REQUEST-LEVEL field (never per-
// candidate) and evaluates each stepped instant via
// `evaluateTimingCandidate({profile, start, durationMinutes, context})`
// -- meaning every returned `TimingCandidate` already has
// `end - start === durationMinutes`, the EXACT duration this file
// requested. There is no "broad window containing an implied good
// sub-period" case to normalize around: a FIND candidate's own
// [start, end) IS already the exact, duration-matched placement PR B's
// own `deriveExactInterval` expects. Passing it through verbatim (never
// widening or re-deriving it here) is therefore safe and correct.
//
// `candidateOrder` is the candidate's own position in
// `TimingSearchResponse.candidates` -- FIND's own result is already
// ranked/sorted by the engine itself, so preserving array index
// preserves a real, meaningful, deterministic order (this ticket's own
// section 10 example: "e.g. the position runTimingSearch's own FIND
// result already returned them in"), never re-derived independently
// here.
//
// Malformed engine output (this ticket's own section 28: "malformed
// timing candidates filtered/fail safely") is dropped at this
// normalization boundary -- a candidate whose own `start`/`end` do not
// parse to a valid, ordered Date pair never reaches `constructDay` at
// all (`null` return, filtered by the caller).
// ============================================================

// ============================================================
// Dynamic Candidate Replenishment V1 -- two small, pure helpers the
// replenishment loop (orchestrateConstructDay, below) uses. Kept
// deliberately trivial and separate so the loop's own control flow
// reads as "what" (converge / no progress / next round), not "how" a
// diagnostic is classified or two sets are compared.
// ============================================================

/** True only when at least one of this deferred intent's own rejected
 * candidates failed SPECIFICALLY because it overlapped a same-run
 * proposed item -- never for an intent whose every candidate failed for
 * a reason replenishment cannot help with (DURATION_UNKNOWN/
 * NO_CANDIDATES carry no diagnostics at all; a candidate rejected as
 * OUTSIDE_CONSTRUCTION_WINDOW or BLOCKED_BY_COMMITMENT will be rejected
 * for the exact same reason again no matter how many times search is
 * re-run, since neither the window nor the pre-existing blockers ever
 * change between rounds). Deliberately checks every diagnostic, not
 * only a `primaryReason` of exactly `'CONFLICTS_WITH_PROPOSED_ITEM'` --
 * `summarizeRejections` (dayConstructor.ts) collapses a MIXED set of
 * per-candidate reasons to `'NO_FEASIBLE_WINDOW'`, and an intent whose
 * candidates failed for a mix of reasons, one of which is a same-run
 * conflict, still deserves a replenishment attempt (this ticket's own
 * product invariant: "the intent must not be falsely deferred merely
 * because its original bounded top-N candidates became occupied by
 * sibling activities"). */
function isReplenishableConflict(diagnostics: readonly PlacementDiagnostic[]): boolean {
  return diagnostics.some((d) => d.reason === 'CONFLICTS_WITH_PROPOSED_ITEM');
}

function setsEqual(a: ReadonlySet<string>, b: ReadonlySet<string>): boolean {
  if (a.size !== b.size) return false;
  for (const value of a) if (!b.has(value)) return false;
  return true;
}

function normalizeCandidate(intentId: string, candidate: TimingCandidate, candidateOrder: number): PlacementCandidate | null {
  const start = new Date(candidate.start);
  const end = new Date(candidate.end);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || start.getTime() >= end.getTime()) return null;
  return { intentId, start, end, timingFit: mapTimingLabelToPlacementFit(candidate.label), candidateOrder };
}

// ============================================================
// orchestrateConstructDay -- the main entry point. ORCHESTRATOR
// ASSEMBLES, CONSTRUCTOR DECIDES (this ticket's own section 3): every
// placement decision below is made by exactly one `constructDay` call;
// this function only resolves real data into that call's own inputs.
// ============================================================

/**
 * Availability Context V1 PR H1 -- resolves the target-day window using a
 * user's saved availability when one exists, otherwise defers entirely to
 * the EXISTING `resolveConstructionWindow` (below, untouched). Only ever
 * consulted for `constructionWindowSource === 'REMAINING_TODAY'` --
 * `EXPLICIT_RANGE` is an already-fully-specified caller-supplied window
 * and is never reinterpreted through availability (architecture audit's
 * own section 40 recommendation).
 *
 * UNCONFIGURED -> `{ status: 'UNCONFIGURED_TODAY' }` (targetDate IS the
 * caller's own current civil day) -> the caller must fall through to
 * `resolveConstructionWindow(request)` verbatim (this ticket's own
 * section 19 -- zero behavioral change for an existing user), OR
 * `{ status: 'FUTURE_AVAILABILITY_REQUIRED' }` (targetDate is NOT today
 * -- Planning Horizon V1 PR P1, this ticket's own section 8/12) -- the
 * caller must fail the whole orchestration closed, NEVER fall through to
 * `resolveConstructionWindow(request)` for a non-today date (see
 * `OrchestrateConstructDayResult['FUTURE_AVAILABILITY_REQUIRED']`'s own
 * doc comment for why). `resolveAvailability` itself is untouched --
 * this "is targetDate today" check is deliberately made HERE, at the
 * orchestration boundary (this ticket's own section 8: "Prefer enforcing
 * this at the orchestration boundary"), never inside the pure resolver.
 *
 * CONFIGURED with zero usable windows (this ticket's own section 18,
 * "CONFIGURED_EMPTY") -> `{ status: 'NO_USABLE_CAPACITY' }`: the caller
 * must report this directly, NEVER fabricate a zero-length
 * `ConstructionWindow` to pass through the normal path (this ticket's
 * own section 28 -- `validateConstructionWindow` already rejects
 * `start >= end` as `INVALID_CONSTRUCTION_WINDOW`, the wrong status for
 * a genuinely, deliberately empty day). Unaffected by P1 -- CONFIGURED_
 * EMPTY reaches this status regardless of which date it targets.
 *
 * CONFIGURED with at least one usable window -> `{ status: 'READY',
 * window, gapBlockers }`: `window` replaces what
 * `resolveConstructionWindow` would have produced; `gapBlockers` must be
 * merged into the existing Plan-blocker list before normalization
 * (architecture audit's own section 23/56 -- `dayConstructor.ts`/
 * `dayCapacity.ts` still consume exactly one window + one blocker list,
 * unchanged). Unaffected by P1 -- a future date's CONFIGURED windows
 * were already correctly unclipped by `resolveAvailability` before this
 * ticket existed.
 */
export async function resolveAvailabilityAwareWindow(
  request: ConstructDayRequest,
  deps: DayConstructorOrchestratorDeps
): Promise<
  | { status: 'UNCONFIGURED_TODAY' }
  | { status: 'FUTURE_AVAILABILITY_REQUIRED' }
  | { status: 'NO_USABLE_CAPACITY' }
  | { status: 'READY'; window: ConstructionWindow; gapBlockers: BlockedInterval[] }
> {
  const availabilityConfig = await deps.loadAvailabilityConfiguration();
  const resolution = resolveAvailability({ targetDate: request.targetDate, timezone: request.timezone, now: request.now, configuration: availabilityConfig });
  if (resolution.status === 'UNCONFIGURED') {
    const isTargetDateToday = request.targetDate === getDatePartsInTimezone(request.timezone, request.now).dateStr;
    return isTargetDateToday ? { status: 'UNCONFIGURED_TODAY' } : { status: 'FUTURE_AVAILABILITY_REQUIRED' };
  }
  if (resolution.usableWindows.length === 0) return { status: 'NO_USABLE_CAPACITY' };
  const normalized = normalizeUsableWindowsToConstructionWindow(resolution.usableWindows, request.targetDate, request.timezone)!;
  return { status: 'READY', window: normalized.window, gapBlockers: normalized.gapBlockers };
}

export async function orchestrateConstructDay(request: ConstructDayRequest, deps: DayConstructorOrchestratorDeps): Promise<OrchestrateConstructDayResult> {
  return runOrchestration(request, deps, constructDay); // the legacy path: the exported `constructDay` itself, no observer, no trace
}

/**
 * O5 P3a -- the same orchestration, additionally returning the CONTENTION TRACE (contentionTrace.ts) ACCUMULATED across
 * every Constructor pass (the first pass is round 0, each replenishment re-run the next round), so a later round that
 * leaves a candidate with NO_CANDIDATES cannot erase the earlier proof that it lost an interval to a Proposed owner.
 * Each pass runs through `constructDayWithTrace`, whose observer is created INSIDE the Constructor; nothing a caller
 * supplies is ever invoked from inside placement. `result` is exactly what `orchestrateConstructDay` returns for the same
 * request and deps: same queries, same searches, same output. Internal diagnostics only -- no route, preview, signed
 * contract, persistence or policy consumes it.
 */
export async function orchestrateConstructDayWithTrace(request: ConstructDayRequest, deps: DayConstructorOrchestratorDeps): Promise<{ result: OrchestrateConstructDayResult; contentionTrace: ContentionTrace }> {
  return runTraced(request, deps, undefined);
}

/**
 * O5 P3b -- the diagnostics entry point for the inert SHADOW stage: the same traced orchestration plus the two inputs a
 * shadow observation needs that otherwise stay internal -- the immutable per-intent evidence the P2a stage prepared (held
 * for the future policy stage; never passed to the Constructor, never rebuilt here) and the planning date. Both are handed
 * out AFTER the Constructor has decided, through a private write-only hand-off the orchestrator fills once; nothing
 * computed from them can flow back into construction. `result` is exactly what `orchestrateConstructDay` returns for the
 * same request and deps. Internal diagnostics only -- no route, preview, signed contract or persistence consumes it.
 */
export async function orchestrateConstructDayWithDiagnostics(
  request: ConstructDayRequest,
  deps: DayConstructorOrchestratorDeps
): Promise<{ result: OrchestrateConstructDayResult; contentionTrace: ContentionTrace; evidenceByIntentId: ReturnType<typeof prepareDecisionEvidence>; planningDate: string; constructionBasis: ConstructionBasisOutcome; baselinePlacements: BaselinePlacementsOutcome }> {
  const handOff: EvidenceHandOff = {};
  const traced = await runTraced(request, deps, handOff);
  return { result: traced.result, contentionTrace: traced.contentionTrace, evidenceByIntentId: handOff.byIntentId ?? new Map(), planningDate: request.targetDate, constructionBasis: handOff.constructionBasis ?? { status: 'UNAVAILABLE', reason: 'RUN_NOT_READY' }, baselinePlacements: handOff.baselinePlacements ?? { status: 'UNAVAILABLE', reason: 'RUN_NOT_READY' } };
}

/** O5 P3b -- private, write-only: the orchestrator assigns the prepared evidence here once, after preparation and before construction. */
interface EvidenceHandOff {
  byIntentId?: ReturnType<typeof prepareDecisionEvidence>;
  /** O5 P4b1 -- the immutable construction basis, assembled once at the very end of a READY run (T4). Same write-only discipline; nothing in this file reads it. */
  constructionBasis?: ConstructionBasisOutcome;
  /** O5 P4b1b -- the baseline Proposed placements of the SAME run, captured from the terminal `result.day` and validated against that run's basis. Same write-only discipline. */
  baselinePlacements?: BaselinePlacementsOutcome;
}

/** O5 P4b1 -- basis preparation is optional infrastructure: whatever it does, it can never make the baseline fail. */
function optionalBasisStep<T>(step: () => T): T | undefined {
  try {
    return step();
  } catch {
    return undefined;
  }
}

async function runTraced(request: ConstructDayRequest, deps: DayConstructorOrchestratorDeps, evidenceOut: EvidenceHandOff | undefined): Promise<{ result: OrchestrateConstructDayResult; contentionTrace: ContentionTrace }> {
  const passTraces: ContentionTrace[] = [];
  const constructWithTrace = (input: ConstructDayInput): ConstructDayResult => {
    const traced = constructDayWithTrace(input, passTraces.length);
    passTraces.push(traced.trace);
    return traced.result;
  };
  const result = await runOrchestration(request, deps, constructWithTrace, evidenceOut);
  return { result, contentionTrace: aggregateContentionTraces(passTraces) };
}

/** `constructDay` here is the Constructor entry point to call (the legacy path passes the exported `constructDay` itself); the orchestrator never gives it anything but the plain input. */
async function runOrchestration(request: ConstructDayRequest, deps: DayConstructorOrchestratorDeps, constructDay: (input: ConstructDayInput) => ConstructDayResult, evidenceOut?: EvidenceHandOff): Promise<OrchestrateConstructDayResult> {
  // Same defensive runtime checks `resolveConstructionWindow` itself
  // performs (below, untouched) -- duplicated here ONLY so a malformed
  // request fails before `deps.loadAvailabilityConfiguration`'s own I/O
  // is ever attempted, never to change either check's own behavior.
  if (!request.timezone || !request.timezone.trim()) return { status: 'TIMEZONE_MISSING' };
  if (!(request.now instanceof Date) || Number.isNaN(request.now.getTime())) return { status: 'INVALID_REQUEST', reason: 'now must be a valid Date, for either constructionWindowSource.' };

  let window: ConstructionWindow;
  let availabilityGapBlockers: BlockedInterval[] = [];

  if (request.constructionWindowSource === 'REMAINING_TODAY') {
    const availabilityWindow = await resolveAvailabilityAwareWindow(request, deps);
    if (availabilityWindow.status === 'FUTURE_AVAILABILITY_REQUIRED') {
      // Planning Horizon V1 PR P1 -- fails the whole orchestration closed
      // before any real-data fetch beyond `loadAvailabilityConfiguration`
      // is attempted (this ticket's own section 8/12): never falls
      // through to `resolveConstructionWindow`'s REMAINING_TODAY branch,
      // which is only correct for today.
      return { status: 'FUTURE_AVAILABILITY_REQUIRED' };
    }
    if (availabilityWindow.status === 'NO_USABLE_CAPACITY') {
      // CONFIGURED_EMPTY hardening: `requestedMinutes` means "the total
      // resolved duration requested by the user," identical to the
      // normal path's own semantics -- never "0 because we exited
      // early." Resolves each intent's real duration via the EXACT SAME
      // `resolveRequestedDayIntent` (and its own `resolveActivity`/
      // `resolveDuration`/`buildDayIntent`) the normal per-intent loop
      // below calls, then sums via the SAME canonical
      // `sumConstructibleDurationMinutes` `constructDay` itself uses --
      // no second duration resolver, no timing search (never reached:
      // this file's own `resolveRequestedDayIntent` never calls
      // `deps.searchTiming`), no `constructDay` call, no candidate
      // generation, no fabricated window.
      const durationContext = await deps.loadDurationContext();
      const dayIntents = request.intents.map((requested) => resolveRequestedDayIntent(requested, request.targetDate, durationContext).dayIntent);
      const { totalMinutes: requestedMinutes } = sumConstructibleDurationMinutes(dayIntents);
      return { status: 'NO_USABLE_CAPACITY', constructionWindowMinutes: 0, blockedMinutes: 0, requestedMinutes };
    }
    if (availabilityWindow.status === 'READY') {
      window = availabilityWindow.window;
      availabilityGapBlockers = availabilityWindow.gapBlockers;
    } else {
      // UNCONFIGURED_TODAY (the only remaining possibility here -- the
      // FUTURE_AVAILABILITY_REQUIRED case already returned above) -- the
      // exact existing REMAINING_TODAY path, unchanged (this ticket's
      // own section 9).
      const windowResolution = resolveConstructionWindow(request);
      if (windowResolution.status !== 'READY') return windowResolution;
      window = windowResolution.window;
    }
  } else {
    // EXPLICIT_RANGE -- never touched by availability resolution.
    const windowResolution = resolveConstructionWindow(request);
    if (windowResolution.status !== 'READY') return windowResolution;
    window = windowResolution.window;
  }

  // Real-data fetches -- EXACTLY ONCE each per orchestration run (this
  // ticket's own section 20), never once per intent.
  const dayBounds = localDayBoundsUTC(request.targetDate, request.timezone);
  const blockerBounds = resolveBlockerLoadBounds(dayBounds, window);
  const [blockingPlanCandidates, durationContext, dailyRhythmPrefs] = await Promise.all([
    deps.loadBlockingPlans(blockerBounds),
    deps.loadDurationContext(),
    deps.loadDailyRhythmPreferences ? deps.loadDailyRhythmPreferences() : Promise.resolve<DailyRhythmPreferencesInput>({ workStart: null, workEnd: null, workDays: [] }),
  ]);
  // Lifecycle filtering happens HERE, in the orchestrator's own testable
  // core (this ticket's own section 6: "Keep this in the orchestrator
  // layer") -- `deps.loadBlockingPlans` only fetches raw rows;
  // `isActivePlanBlocker` (above) is what actually decides LOGGED (always
  // blocks) vs CANCELLED (never blocks) vs UPCOMING (blocks only while
  // not yet elapsed relative to `request.now`, the SAME reference
  // instant regardless of window source -- see ConstructDayRequest.now's
  // own doc comment). Availability-gap blockers (Availability Context V1
  // PR H1) are prepended -- `[]` for every UNCONFIGURED/EXPLICIT_RANGE
  // request, so this list is byte-identical to before in those cases.
  const blockedIntervals: BlockedInterval[] = [
    ...availabilityGapBlockers,
    ...blockingPlanCandidates.filter((plan) => isActivePlanBlocker(plan, request.now)).map((plan) => ({ start: plan.start, end: plan.end, source: 'FIXED_PLAN' as const })),
  ];

  const warnings: ConstructDayWarning[] = [];
  const resolvedIntents: ResolvedIntentSummary[] = [];
  const candidatesByIntentId: Record<string, PlacementCandidate[]> = {};
  const fixedConstraintsByIntentId: Record<string, FixedPlacementConstraint[]> = {};
  /** Dynamic Candidate Replenishment V1 -- one entry per FLEXIBLE intent
   * that reached a real `searchTiming` call below, carrying exactly the
   * three fields a replenishment round (below) needs to re-issue that
   * SAME intent's own FIND request later. Never populated for FIXED
   * intents (they never call `searchTiming` at all, unaffected by this
   * ticket) or for a FLEXIBLE intent with an unresolved duration
   * (`constructDay`'s own `DURATION_UNKNOWN` gate handles that, no
   * search ever ran for it to replenish). */
  const flexibleSearchMetaByIntentId: Record<string, { activityId?: string; title: string; durationMinutes: number }> = {};
  /** O5 P1 -- intents whose duration came from the generic fallback, from
   * the SAME resolution that produced the duration (never a second one). */
  const fallbackDurationIntentIds = new Set<string>();

  for (const requested of request.intents) {
    const resolved = resolveRequestedDayIntent(requested, request.targetDate, durationContext);
    warnings.push(...resolved.warnings);
    if (resolved.warnings.some((w) => w.code === 'DURATION_FROM_GENERIC_FALLBACK')) fallbackDurationIntentIds.add(requested.id);
    // Decision Facts V1 -- attached AFTER resolution (never inside
    // `resolveRequestedDayIntent`/`buildDayIntent`), inert metadata only.
    const decisionFacts = resolveDecisionFactsForIntent(requested.id, request.decisionFactsByIntentId);
    const dayIntent: DayIntent = decisionFacts ? { ...resolved.dayIntent, decisionFacts } : resolved.dayIntent;
    resolvedIntents.push({ requestedIntentId: requested.id, dayIntent });

    if (requested.flexibility === 'FIXED') {
      // Never manufacture a PlacementCandidate for a FIXED intent (this
      // ticket's own section 9) -- candidatesByIntentId is simply never
      // populated for this intent's own id.
      if (requested.fixedStart && dayIntent.estimatedDurationMinutes !== undefined) {
        const end = new Date(requested.fixedStart.getTime() + dayIntent.estimatedDurationMinutes * 60000);
        fixedConstraintsByIntentId[dayIntent.id] = [{ intentId: dayIntent.id, start: requested.fixedStart, end }];
      }
      // A missing fixedStart, or an unresolved duration, leaves
      // fixedConstraintsByIntentId[dayIntent.id] unset entirely --
      // constructDay's own placeFixedIntent (or its own DURATION_UNKNOWN
      // gate, evaluated first) produces the correct typed deferral. This
      // file never converts a FIXED intent to FLEXIBLE to route around a
      // missing constraint (this ticket's own explicit prohibition).
      continue;
    }

    // FLEXIBLE
    if (dayIntent.estimatedDurationMinutes === undefined) continue; // constructDay's own DURATION_UNKNOWN gate handles this; no search to run.

    // Construction-Window-Aware Timing Search V1 -- `searchWindow` is the
    // SAME resolved `window` every candidate is later checked against in
    // `evaluateCandidate` (dayConstructor.ts's own `isWithinWindow` gate),
    // passed straight through with zero conversion (both are already the
    // same `{ start: Date; end: Date }` absolute-instant shape). This is
    // what fixes the root cause the audit found: FIND's own candidate
    // ranking/limit now only ever considers instants this specific
    // orchestration run could actually use, so a narrow construction
    // window can no longer have its own genuinely-feasible in-window
    // candidates silently truncated away in favor of higher-scoring but
    // useless out-of-window ones. `dayConstructor.ts`'s own feasibility
    // gates (window/blockers/conflicts) are completely unchanged and
    // remain the sole authority on final placement -- this only narrows
    // what FIND bothers to generate and rank in the first place.
    const searchWindow = { start: window.start, end: window.end };
    // Correctness amendment (PR #146 review) -- `excludedIntervals` is
    // the SAME `blockedIntervals` array assembled ONCE above (line 776),
    // BEFORE this per-intent loop ever runs, straight-mapped to the bare
    // `{start,end}` shape `runTimingSearch` needs (its own `source` tag
    // is a Day-Constructor-only concept, meaningless to that package).
    // Deliberately the ENTIRE array, every source: `'AVAILABILITY_GAP'`
    // (the gap between two disjoint configured periods) and `'FIXED_PLAN'`
    // (an existing active commitment) are BOTH already known, fixed, and
    // genuinely unusable before ANY intent's search runs -- exactly the
    // category this field exists for (see its own doc comment,
    // timingSearch.ts, for why `'EXTERNAL'`, reserved/unused in V1, would
    // be correct to include too if it were ever populated: it carries the
    // identical "already known, already unusable" semantic by
    // construction of `BlockedInterval` itself, not something this file
    // needs to special-case).
    //
    // Deliberately NEVER includes a same-run proposed-item conflict: at
    // this point in `orchestrateConstructDay`, `constructDay` has not
    // been called yet for ANY intent (every intent's own `searchTiming`
    // call happens here, in this loop, strictly before the single
    // `constructDay(constructInput)` call below) -- there is no
    // "already-placed item" to know about yet, for any intent, even the
    // very first one submitted. That conflict category is unavoidably,
    // and correctly, `constructDay`'s own `CONFLICTS_WITH_PROPOSED_ITEM`
    // gate's job alone (see this ticket's own audit item on whether a
    // later intent can still lose feasible alternatives to an
    // already-proposed item -- answered in the completion report, not
    // silently addressed here).
    const excludedIntervals = blockedIntervals.map((blocker) => ({ start: blocker.start, end: blocker.end }));
    // Daily Rhythm V1 PR DR3 -- widens the search's own `limit` ONLY when
    // this exact intent's own candidates would later be filtered by
    // applyDailyRhythmPreference (the identical gate, reused verbatim --
    // see resolveDailyRhythmSearchLimit's own doc comment for why this
    // costs nothing extra for every other intent/user). `undefined`
    // leaves `limit` unset entirely, preserving the engine's own default
    // (3) byte-for-byte.
    const dailyRhythmSearchLimit = resolveDailyRhythmSearchLimit(dayIntent.activityId, { targetDate: request.targetDate, timezone: request.timezone, prefs: dailyRhythmPrefs });
    const searchRequest: Omit<TimingSearchRequest, 'context'> = dayIntent.activityId
      ? { mode: 'FIND', activityId: dayIntent.activityId, durationMinutes: dayIntent.estimatedDurationMinutes, dateRange: { start: request.targetDate, end: request.targetDate }, searchWindow, excludedIntervals, ...(dailyRhythmSearchLimit !== undefined ? { limit: dailyRhythmSearchLimit } : {}) }
      : { mode: 'FIND', taskTitle: requested.title, durationMinutes: dayIntent.estimatedDurationMinutes, dateRange: { start: request.targetDate, end: request.targetDate }, searchWindow, excludedIntervals, ...(dailyRhythmSearchLimit !== undefined ? { limit: dailyRhythmSearchLimit } : {}) };

    let searchResult: { candidates: TimingCandidate[] };
    try {
      searchResult = deps.searchTiming(searchRequest);
    } catch (err) {
      // Infrastructure/search failure -- distinct from "no candidates
      // exist" (this ticket's own section 19). Fails the whole
      // orchestration closed rather than silently deferring this one
      // intent as though the engine had genuinely found nothing.
      return { status: 'TIMING_SEARCH_FAILED', requestedIntentId: requested.id, reason: err instanceof Error ? err.message : String(err) };
    }

    // Daily Rhythm V1 PR DR2 -- applied to the ALREADY-ranked candidate
    // list `deps.searchTiming` just returned, strictly before
    // normalization: a pure filter-with-fallback, never a re-score,
    // never touching `constructDay`'s own [timingFit, start,
    // candidateOrder] ranking (dayConstructor.ts remains untouched). See
    // dailyRhythmScheduling.ts's own doc comment for the full contract.
    const dailyRhythmFilteredCandidates = applyDailyRhythmPreference(searchResult.candidates, dayIntent.activityId, {
      targetDate: request.targetDate,
      timezone: request.timezone,
      prefs: dailyRhythmPrefs,
    });
    const normalized = dailyRhythmFilteredCandidates
      .map((candidate, index) => normalizeCandidate(dayIntent.id, candidate, index))
      .filter((candidate): candidate is PlacementCandidate => candidate !== null);
    candidatesByIntentId[dayIntent.id] = normalized;
    if (normalized.length === 0) warnings.push({ intentId: requested.id, code: 'NO_TIMING_CANDIDATES_FOUND' });
    // Dynamic Candidate Replenishment V1 -- kept for exactly the same
    // reason `excludedIntervals` was kept above: a replenishment round
    // (below) needs to re-issue THIS intent's own FIND request later,
    // against a larger `excludedIntervals`, without re-deriving
    // `activityId`/`title`/`estimatedDurationMinutes` from `requested`/
    // `dayIntent` a second time.
    flexibleSearchMetaByIntentId[dayIntent.id] = { activityId: dayIntent.activityId, title: requested.title, durationMinutes: dayIntent.estimatedDurationMinutes };
  }

  // O5 P4b1 -- T1: the candidate lists exactly as the ORIGINAL timing searches left them, captured (owned copies) BEFORE any replenishment
  // can replace a loser's list. Only when a diagnostics caller asked for the basis; no search is repeated to recover them.
  const initialCandidateLists = evidenceOut ? optionalBasisStep(() => captureCandidateLists(request.intents.map((requested) => requested.id), candidatesByIntentId)) : undefined;

  // O5 P1 -- decision facts are PREPARED here: after every intent's
  // authoritative duration is resolved, strictly BEFORE `constructDay`. They
  // are prepared exactly once, kept outside the Constructor input below
  // (`intentsForConstructDay` is built from the intents as resolved above,
  // not from the prepared facts), and attached to the preview metadata only
  // after construction. Preparing is not consuming: nothing in this file
  // reads a prepared fact.
  const preparationIntents = resolvedIntents.map((resolved) => ({
    intentId: resolved.requestedIntentId,
    durationMinutes: resolved.dayIntent.estimatedDurationMinutes,
    durationFromGenericFallback: fallbackDurationIntentIds.has(resolved.requestedIntentId),
    facts: resolved.dayIntent.decisionFacts,
  }));
  const preparedDecisionFacts = await prepareDecisionFactsFailOpen(deps.prepareDecisionFacts, {
    intents: preparationIntents,
    context: { planningDate: request.targetDate, timezone: request.timezone, now: request.now },
  });
  // O5 P2a -- the immutable DecisionEvidence for every fact-bearing intent, built ONCE here from the facts as prepared. It
  // is held for the future decision-policy stage and deliberately NOT passed to `constructDay`, the precedence comparator,
  // placement, capacity or replenishment below: building evidence is not consuming it, and it is never rebuilt later.
  const decisionEvidenceByIntentId = prepareDecisionEvidence(preparationIntents, preparedDecisionFacts);
  if (evidenceOut) evidenceOut.byIntentId = decisionEvidenceByIntentId; // O5 P3b -- write-only hand-off to the diagnostics entry point; read only after construction

  const intentsForConstructDay = resolvedIntents.map((r) => r.dayIntent);

  // ============================================================
  // Dynamic Candidate Replenishment V1 (PR #146's final correctness
  // amendment). `constructDay` itself is UNCHANGED and untouched --
  // still one pure, synchronous, self-contained call per invocation,
  // still the sole authority on feasibility/placement/precedence. What
  // changes here is that this file may now call it MORE THAN ONCE:
  //
  //   ROOT CAUSE this closes: every FLEXIBLE intent's own `searchTiming`
  //   call (the loop above) happens BEFORE `constructDay` places ANY
  //   intent -- so intent C's own candidate set can never know that
  //   intent A or B (processed earlier, same precedence order) will end
  //   up claiming one of C's own top-`limit` candidates. `excludedIntervals`
  //   (this file's own earlier amendment) cannot help here: it only
  //   carries what is known BEFORE search runs (availability gaps,
  //   existing Plans) -- a same-run proposed item does not exist yet at
  //   that point, for ANY intent, even the first one submitted.
  //
  //   THE FIX: run `constructDay` once with the candidates already
  //   gathered above (byte-identical to pre-amendment behavior for every
  //   request that never hits this condition -- the overwhelming
  //   majority, and the ENTIRE reason this stays a fast path, this
  //   ticket's own section 20). Then, for any FLEXIBLE intent deferred
  //   this round for a reason that INCLUDES `CONFLICTS_WITH_PROPOSED_ITEM`
  //   in its own diagnostics (never any other reason -- see
  //   `isReplenishableConflict` below), re-issue ONLY that intent's own
  //   FIND request, with `excludedIntervals` grown to also cover every
  //   interval `constructDay` actually proposed this round (real,
  //   already-committed-within-this-run time, exactly the same
  //   "already known unusable" category `excludedIntervals` already
  //   expresses -- never a same-run item that MIGHT still move, since
  //   nothing here ever un-places an already-proposed item). Re-run
  //   `constructDay` with the refreshed candidate set. Repeat.
  //
  //   OWNERSHIP BOUNDARY PRESERVED (this ticket's own section 4):
  //   `runTimingSearch` still only ever receives temporal bounds
  //   (`searchWindow`/`excludedIntervals`) -- it is never told about
  //   precedence, overload, or commit semantics, and never asked to
  //   place anything. `constructDay` still makes every placement
  //   decision, unchanged, called with a plain, complete
  //   `ConstructDayInput` each time -- it has no callback, no loop, no
  //   awareness that it might be invoked again. ONLY this orchestrator
  //   coordinates the state-aware interaction between the two, exactly
  //   the role this file's own module doc comment already assigns it.
  //
  //   TERMINATION (this ticket's own section 14, mandatory, deterministic
  //   bound, no unbounded retry): capped at `flexibleIntentCount` rounds
  //   -- a conservative but always-safe bound, since every round that
  //   makes forward progress permanently resolves (places) at least one
  //   previously-conflicted intent (an intent, once placed by
  //   `constructDay`, is never revisited -- its own candidate set is
  //   never touched again), and the loop stops immediately, before that
  //   bound is ever reached in practice, the instant a round produces
  //   the IDENTICAL still-conflicted intent-id set as the round before
  //   it (no forward progress -- accept the result as final; this is
  //   what correctly distinguishes a resolvable dynamic conflict from
  //   genuine capacity exhaustion, this ticket's own section 7/19).
  //
  //   DUPLICATE-CANDIDATE SAFETY (this ticket's own section 15): since
  //   `excludedIntervals` only ever GROWS between rounds (every
  //   already-proposed interval accumulates, none are ever removed), a
  //   replenished FIND call for the same intent can never return the
  //   exact interval that conflicted in an earlier round -- that
  //   interval is now itself part of `excludedIntervals`, filtered
  //   before generation, by construction. No separate cursor/dedupe
  //   bookkeeping is needed.
  // ============================================================
  const flexibleIntentCount = intentsForConstructDay.filter((i) => i.flexibility === 'FLEXIBLE').length;
  let result: ConstructDayResult = constructDay({
    intents: intentsForConstructDay,
    window,
    blockedIntervals,
    candidatesByIntentId,
    fixedConstraintsByIntentId,
    today: request.targetDate,
  });
  if (result.status !== 'READY') return result;

  let previouslyConflictedIds: Set<string> | undefined;
  for (let round = 0; round < flexibleIntentCount; round += 1) {
    const conflictedIds = new Set(
      result.day.deferredItems.filter((d) => isReplenishableConflict(d.diagnostics)).map((d) => d.intentId)
    );
    if (conflictedIds.size === 0) break; // Converged: nothing left that replenishment could help.
    if (previouslyConflictedIds && setsEqual(conflictedIds, previouslyConflictedIds)) break; // No forward progress -- genuine remaining deferral, stop.
    previouslyConflictedIds = conflictedIds;

    // Every interval `constructDay` actually proposed THIS round is now
    // real, committed-within-this-run time -- union with the original
    // gap/Plan blockers (never shrinks, never replaces).
    const proposedThisRound = result.day.proposedItems.map((p) => ({ start: p.start, end: p.end }));
    const excludedIntervals = [...blockedIntervals.map((b) => ({ start: b.start, end: b.end })), ...proposedThisRound];

    for (const intentId of conflictedIds) {
      const meta = flexibleSearchMetaByIntentId[intentId];
      if (!meta || meta.durationMinutes === undefined) continue; // Structurally unreachable (only ever set for FLEXIBLE intents that already had a resolved duration), defensive only.
      const searchWindow = { start: window.start, end: window.end };
      // Daily Rhythm V1 PR DR3 -- the SAME conditional limit widening as
      // the primary loop above, re-resolved per replenishment round
      // (meta.activityId never changes between rounds for the same
      // intent, so this is a cheap, pure re-check, not a second policy).
      const dailyRhythmSearchLimit = resolveDailyRhythmSearchLimit(meta.activityId, { targetDate: request.targetDate, timezone: request.timezone, prefs: dailyRhythmPrefs });
      const searchRequest: Omit<TimingSearchRequest, 'context'> = meta.activityId
        ? { mode: 'FIND', activityId: meta.activityId, durationMinutes: meta.durationMinutes, dateRange: { start: request.targetDate, end: request.targetDate }, searchWindow, excludedIntervals, ...(dailyRhythmSearchLimit !== undefined ? { limit: dailyRhythmSearchLimit } : {}) }
        : { mode: 'FIND', taskTitle: meta.title, durationMinutes: meta.durationMinutes, dateRange: { start: request.targetDate, end: request.targetDate }, searchWindow, excludedIntervals, ...(dailyRhythmSearchLimit !== undefined ? { limit: dailyRhythmSearchLimit } : {}) };

      let replenishedResult: { candidates: TimingCandidate[] };
      try {
        replenishedResult = deps.searchTiming(searchRequest);
      } catch (err) {
        return { status: 'TIMING_SEARCH_FAILED', requestedIntentId: intentId, reason: err instanceof Error ? err.message : String(err) };
      }
      // Daily Rhythm V1 PR DR2 -- the SAME filter-with-fallback applied to
      // the primary loop above, re-run independently on this round's own
      // freshly-searched candidates (never cached from the first round),
      // so a personal activity that lost its outside-work slot to a
      // same-run sibling still gets a fresh outside-first attempt here.
      const dailyRhythmFilteredReplenished = applyDailyRhythmPreference(replenishedResult.candidates, meta.activityId, {
        targetDate: request.targetDate,
        timezone: request.timezone,
        prefs: dailyRhythmPrefs,
      });
      candidatesByIntentId[intentId] = dailyRhythmFilteredReplenished
        .map((candidate, index) => normalizeCandidate(intentId, candidate, index))
        .filter((candidate): candidate is PlacementCandidate => candidate !== null);
    }

    result = constructDay({
      intents: intentsForConstructDay,
      window,
      blockedIntervals,
      candidatesByIntentId,
      fixedConstraintsByIntentId,
      today: request.targetDate,
    });
    if (result.status !== 'READY') return result;
  }

  // O5 P4b1 -- T3/T4: the terminal candidate lists are known; assemble the detached, frozen basis. It reads nothing back into construction,
  // and a failure leaves the baseline result untouched (the outcome is simply UNAVAILABLE).
  if (evidenceOut) {
    evidenceOut.constructionBasis =
      optionalBasisStep(() => assembleConstructionBasis({ planningDate: request.targetDate, window, intents: intentsForConstructDay, blockedIntervals, initialCandidates: initialCandidateLists, finalCandidatesByIntentId: candidatesByIntentId, fixedConstraintsByIntentId })) ?? { status: 'UNAVAILABLE', reason: 'ASSEMBLY_FAILED' };
    // O5 P4b1b -- the baseline OUTCOME, from the same terminal `result.day` the basis was just assembled alongside; validated against that basis.
    evidenceOut.baselinePlacements = optionalBasisStep(() => captureBaselinePlacements(result.day, evidenceOut.constructionBasis ?? { status: 'UNAVAILABLE', reason: 'ASSEMBLY_FAILED' })) ?? { status: 'UNAVAILABLE', reason: 'CAPTURE_FAILED' };
  }

  // Daily Rhythm V1 PR DR2 -- explanations are derived from the FINAL,
  // settled placement only (after every replenishment round), never
  // speculatively during the per-intent search loop above (where the
  // eventual winning candidate isn't known yet). A FIXED placement
  // (`placementSource === 'FIXED_CONSTRAINT'`) never gets one -- a
  // user-selected time is never second-guessed with Aura's own
  // preference reasoning (this ticket's own "user-selected fixed times
  // are never silently moved", which includes never implying they
  // could/should have been).
  for (const item of result.day.proposedItems) {
    if (item.placementSource !== 'SELECTED_CANDIDATE') continue;
    const explanation = explainDailyRhythmPlacement(item.activityId, item.start, item.end, { targetDate: request.targetDate, timezone: request.timezone, prefs: dailyRhythmPrefs });
    if (explanation === 'PERSONAL_OUTSIDE_WORK_HOURS') warnings.push({ intentId: item.intentId, code: 'DAILY_RHYTHM_PERSONAL_OUTSIDE_WORK_HOURS' });
    else if (explanation === 'PERSONAL_DURING_WORK_HOURS_FALLBACK') warnings.push({ intentId: item.intentId, code: 'DAILY_RHYTHM_PERSONAL_DURING_WORK_HOURS_FALLBACK' });
    else if (explanation === 'FLEXIBLE_BREAK_DURING_WORK_HOURS') warnings.push({ intentId: item.intentId, code: 'DAILY_RHYTHM_FLEXIBLE_BREAK_DURING_WORK_HOURS' });
  }

  return {
    status: 'READY',
    preview: {
      targetDate: request.targetDate,
      timezone: request.timezone,
      constructionWindow: window,
      resolvedIntents: attachPreparedDecisionFacts(resolvedIntents, preparedDecisionFacts),
      constructedDay: result.day,
      warnings,
    },
  };
}
