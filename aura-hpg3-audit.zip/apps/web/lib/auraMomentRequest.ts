import { MuhurthamRating, SharedMuhurthamRating } from '../../../packages/recommendation/src/muhurthamFinder';
import { EverydayTimingRating } from '../../../packages/recommendation/src/everydayTimingFit';
import { TimingCandidateLabel } from '../../../packages/recommendation/src/timingSearch';
import { FULL_ACTIVITY_CATALOG } from '../../../packages/recommendation/src/personalizedTasks';
import { getActivityDefinition } from '../../../packages/recommendation/src/activityDefinitions';
import { AuraMomentAlternativePreference, AuraMomentResponseState, AuraMomentScope, AuraMomentSource } from './db';
import { MAX_ALTERNATIVES } from './auraMomentAlternatives';
// Event Location AuraMoment Persistence V1: reuses the exact same
// {cityName, timezone} snapshot validator PR #56 built for POST /api/plans
// (brief section 7: "Prefer the same small persistence shape as PR #56")
// rather than a second, near-duplicate parser -- the shape and every rule
// (both-required-together, isValidIanaTimezone, no coordinates) are
// identical; only the field names differ at the call site below.
import { parseEventLocationSnapshot } from './plansRequest';

/**
 * Pure request validation for POST /api/aura-moments, kept out of
 * app/api/aura-moments/route.ts for the same reason muhurthamSearchRequest.ts
 * is kept out of its route (Next's route modules may only export HTTP
 * handlers).
 *
 * Deliberately does NOT accept from the client: activityTitle, activityIcon
 * (resolved server-side from the activity catalog by the route), a bare
 * `timezone` override (the route defaults to the authenticated owner's own
 * user.timezone -- the ONLY way to override it is the validated
 * `eventLocation: {cityName, timezone}` snapshot below, which must name a
 * real place, not an arbitrary zone string), senderDisplayName (derived
 * server-side from the owner's email, never client-supplied -- spoofing
 * risk), or explanationSnapshot (always server-templated from scope,
 * see auraMoments.ts's explanationSnapshotForScope -- no free-text public
 * copy from a request body, ever). This mirrors brief section 5: "Do not
 * allow arbitrary birth context in the request" applied broadly -- the
 * client may only select WHICH already-computed result to share, not
 * describe its own content.
 */

const VALID_SCOPES = new Set<AuraMomentScope>(['GENERAL', 'PERSONAL', 'SHARED']);
const VALID_SOURCES = new Set<AuraMomentSource>(['PLAN', 'MUHURTHAM']);
const MIN_DURATION_MINUTES = 15;
const MAX_DURATION_MINUTES = 360;

/** The union of every rating vocabulary ANY moment source can produce --
 * Muhurtham Finder's three scopes, Plan's own TimingCandidateLabel (a
 * solo/unspecified-participants everyday result), and everyday shared
 * timing's own vocabulary (findEverydaySharedTiming(), never the ceremonial
 * "Muhurtham" language). Validated as a closed set (not just "any string")
 * so a public moment can never display an arbitrary client-supplied label,
 * even though the actual astrological content of ratingLabel is not itself
 * sensitive. */
const VALID_RATING_LABELS = new Set<MuhurthamRating | SharedMuhurthamRating | TimingCandidateLabel | EverydayTimingRating>([
  'EXCELLENT', 'STRONG', 'FAVORABLE', 'ACCEPTABLE',
  'EXCELLENT_SHARED_FIT', 'STRONG_SHARED_FIT', 'GOOD_SHARED_FIT', 'MIXED_SHARED_FIT',
  'VERY_GOOD', 'GOOD', 'USABLE', 'CAUTION',
  'STRONG_TOGETHER_FIT', 'GOOD_TOGETHER_FIT', 'EASY_TOGETHER_FIT',
]);

export interface AuraMomentCreateInput {
  scope: AuraMomentScope;
  source: AuraMomentSource;
  activityId: string;
  startAt: Date;
  endAt: Date;
  ratingLabel: string | null;
  /** Required (and only meaningful) when scope === 'SHARED'; the route
   * resolves+ownership-checks this against the authenticated owner. */
  savedPersonId: string | null;
  /** Aura Reminders V1 dedup linkage (brief section 7) -- optional; the
   * route ownership-checks this against the authenticated owner (see
   * getPlannedActivityForOwner) before ever writing it. */
  plannedActivityId: string | null;
  /** Event Location AuraMoment Persistence V1: the validated Event Location
   * snapshot's timezone/cityName, both null together when the request
   * omitted eventLocation (the common, backward-compatible case -- share
   * uses the owner's Timing Location). The route computes the actual
   * persisted `timezone` as `eventLocationTimezone ?? user.timezone` and
   * `locationName` as `eventLocationName` directly (brief section 9) --
   * this layer only validates shape, never touches user.timezone. */
  eventLocationTimezone: string | null;
  eventLocationName: string | null;
}

export type AuraMomentCreateValidationResult =
  | { ok: true; input: AuraMomentCreateInput }
  | { ok: false; error: string; status: number };

function isIsoDateString(value: unknown): value is string {
  return typeof value === 'string' && !Number.isNaN(Date.parse(value));
}

export function buildAuraMomentCreateRequest(body: Record<string, unknown>): AuraMomentCreateValidationResult {
  const rawScope = typeof body.scope === 'string' ? body.scope : '';
  if (!VALID_SCOPES.has(rawScope as AuraMomentScope)) {
    return { ok: false, error: 'scope must be GENERAL, PERSONAL, or SHARED.', status: 400 };
  }
  const scope = rawScope as AuraMomentScope;

  const rawSource = typeof body.source === 'string' ? body.source : '';
  if (!VALID_SOURCES.has(rawSource as AuraMomentSource)) {
    return { ok: false, error: 'source must be PLAN or MUHURTHAM.', status: 400 };
  }
  const source = rawSource as AuraMomentSource;

  // Product Structure V2: generalized beyond Muhurtham Finder's own
  // eligibility list (isSupportedMuhurthamActivity) -- a Moment is "a
  // selected time the user intends to do/share" for ANY momentEligible
  // catalog activity, from either source. Muhurtham Finder's own strictness
  // is untouched (it lives entirely in SUPPORTED_MUHURTHAM_ACTIVITY_IDS,
  // which still gates the FINDER's own search results, not what can become
  // a Moment afterward).
  const activityId = typeof body.activityId === 'string' ? body.activityId.trim() : '';
  const activity = FULL_ACTIVITY_CATALOG.find((a) => a.id === activityId);
  const definition = activity ? getActivityDefinition(activity) : undefined;
  if (!activity || !definition?.experience.momentEligible) {
    return { ok: false, error: 'activityId must be a valid, moment-eligible catalog activity.', status: 400 };
  }

  if (!isIsoDateString(body.startAt) || !isIsoDateString(body.endAt)) {
    return { ok: false, error: 'startAt and endAt must be valid ISO date-times.', status: 400 };
  }
  const startAt = new Date(body.startAt as string);
  const endAt = new Date(body.endAt as string);
  const durationMinutes = (endAt.getTime() - startAt.getTime()) / 60_000;
  if (durationMinutes < MIN_DURATION_MINUTES || durationMinutes > MAX_DURATION_MINUTES) {
    return { ok: false, error: `endAt must be between ${MIN_DURATION_MINUTES} and ${MAX_DURATION_MINUTES} minutes after startAt.`, status: 400 };
  }

  let ratingLabel: string | null = null;
  if (body.ratingLabel !== undefined && body.ratingLabel !== null) {
    if (typeof body.ratingLabel !== 'string' || !VALID_RATING_LABELS.has(body.ratingLabel as MuhurthamRating | SharedMuhurthamRating)) {
      return { ok: false, error: 'ratingLabel must be a recognized Muhurtham rating.', status: 400 };
    }
    ratingLabel = body.ratingLabel;
  }

  let savedPersonId: string | null = null;
  if (scope === 'SHARED') {
    savedPersonId = typeof body.savedPersonId === 'string' ? body.savedPersonId.trim() : '';
    if (!savedPersonId) {
      return { ok: false, error: 'savedPersonId is required for SHARED scope.', status: 400 };
    }
  }

  // Aura Reminders V1 (brief section 7) -- optional, only ever set by
  // PlanWithAuraView's "Make this a Moment" when the same candidate was
  // already saved as a Plan in the same session. The route re-verifies
  // ownership; this layer only checks shape.
  let plannedActivityId: string | null = null;
  if (body.plannedActivityId !== undefined && body.plannedActivityId !== null) {
    plannedActivityId = typeof body.plannedActivityId === 'string' ? body.plannedActivityId.trim() : '';
    if (!plannedActivityId) {
      return { ok: false, error: 'plannedActivityId must be a non-empty string when provided.', status: 400 };
    }
  }

  // Event Location AuraMoment Persistence V1 (brief section 6-8): validated
  // the same way PR #56's plan-save request is -- absent/null eventLocation
  // -> both null (ordinary Timing Location share, unchanged behavior);
  // present -> cityName and timezone both required, timezone must be a
  // valid IANA zone. A malformed supplied override is a typed 400, never a
  // silent fallback to user.timezone (section 8: "Do not silently fall back
  // ... when a malformed override was explicitly supplied").
  const eventLocationSnapshot = parseEventLocationSnapshot(body.eventLocation);
  if (!eventLocationSnapshot.ok) {
    return { ok: false, error: eventLocationSnapshot.error, status: 400 };
  }

  return {
    ok: true,
    input: {
      scope, source, activityId, startAt, endAt, ratingLabel, savedPersonId, plannedActivityId,
      eventLocationTimezone: eventLocationSnapshot.eventTimezone,
      eventLocationName: eventLocationSnapshot.eventLocationName,
    },
  };
}

const VALID_RESPONSE_VALUES = new Set<AuraMomentResponseState>(['ACCEPTED', 'ANOTHER_TIME']);

/** Section 10/11's "only two allowed response values" -- POST
 * /api/aura-moments/[token]/response validates against this before touching
 * the database. Public/unauthenticated input, so this rejects anything that
 * isn't exactly one of the two known values (no free text, no extra states). */
export function isValidMomentResponse(value: unknown): value is AuraMomentResponseState {
  return typeof value === 'string' && VALID_RESPONSE_VALUES.has(value as AuraMomentResponseState);
}

const VALID_ALTERNATIVE_PREFERENCES = new Set<AuraMomentAlternativePreference>(['EARLIER', 'LATER', 'DIFFERENT_DAY', 'NO_PREFERENCE']);

/**
 * Aura Moment Rescheduling brief section 19: "the public API must remain
 * intentionally powerless" -- the ONLY additional thing a recipient may ever
 * submit alongside ANOTHER_TIME is one of these four closed values. No
 * dates, no activity ids, no SavedPerson ids, no free text.
 */
export function isValidAlternativePreference(value: unknown): value is AuraMomentAlternativePreference {
  return typeof value === 'string' && VALID_ALTERNATIVE_PREFERENCES.has(value as AuraMomentAlternativePreference);
}

/**
 * POST /api/aura-moments/[token]/suggest's entire request body: an index
 * into the alternatives just computed (0, 1, or 2 -- see MAX_ALTERNATIVES in
 * auraMomentAlternatives.ts), NEVER a client-supplied date/time/activity/
 * SavedPerson id (brief section 20: "Do not trust IDs supplied by the
 * browser where they can be resolved from AuraMoment"). The route re-runs
 * the exact same deterministic search server-side and picks
 * candidates[index] itself.
 */
export function isValidAlternativeIndex(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value < MAX_ALTERNATIVES;
}
