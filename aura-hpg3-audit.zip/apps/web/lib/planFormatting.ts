import { buildGoogleCalendarUrl } from '../../../packages/recommendation/src/dailyAssistant';
import { summarizeReasonsPlainly } from '../../../packages/muhurta/src/muhurtaPlainLanguage';
import type { TimingCandidate, TimingCandidateLabel } from '../../../packages/recommendation/src/timingSearch';
// DR4-E1 -- Time-Aware Upcoming Plans. timeBasedStatus is the SAME function
// Home's own agenda (dailyAgenda.ts's planToAgendaItem) already uses to
// derive MISSED/CURRENT/STARTING_SOON for an UPCOMING plan -- reused here
// verbatim rather than defining a second classification. A plain value
// import, not `db.ts` itself: dailyAgenda.ts only imports PlannedActivity
// etc. as types, so nothing server-only (pg, the pool) enters this client
// module's bundle -- homeMissedRecovery.ts, already bundled into the client
// via HomeDashboard.tsx, imports this exact function the same way.
import { timeBasedStatus } from './dailyAgenda';

/**
 * Pure plan display/formatting logic shared by PlanWithAuraView.tsx and its
 * callers -- extracted into a plain .ts module (Event Location Plan
 * Persistence V1 closeout) specifically so it can be unit-tested under this
 * repo's normal (non-JSX) test runner without importing a .tsx component
 * file. No React, no JSX, no UI here -- see PlanWithAuraView.tsx for the
 * component that renders these values.
 */

export type PlanIcon = 'workout' | 'focus' | 'heart' | 'study' | 'meditate' | 'meeting' | 'journey';

/** Event Location Plan Persistence V1: the minimal, coordinate-free shape
 * a plan-save call passes through to persistence -- deliberately just
 * `{cityName, timezone}`, extracted from PR #55's own resultEventLocation
 * (which also carries latitude/longitude) at the save boundary, never the
 * full CityOption shape. See saveUpcomingPlanFromCandidate()'s own doc
 * comment (PlanWithAuraView.tsx) for why coordinates are never passed this
 * far. */
export interface PlanEventLocation {
  cityName: string;
  timezone: string;
}

/** The persisted PlannedActivity lifecycle as it crosses the API boundary.
 * mapPlanRow maps it faithfully; which states a surface shows is a
 * presentation decision made by the surface, never by this mapper. */
export type PersistedPlanStatus = 'UPCOMING' | 'LOGGED' | 'CANCELLED' | 'SKIPPED' | 'MOVED';

export type UpcomingPlan = {
  id: string;
  title: string;
  icon: PlanIcon;
  duration: string;
  time: string;
  window: string;
  // DR4-E3 -- optional on purpose: a genuine timing-engine classification
  // (planPayloadFromCandidate, always one of these two) is truthful and
  // stays required there; a PERSISTED plan's matchLabel (mapPlanRow) may be
  // null/missing (e.g. manually-created or Day Builder plans never ran
  // through Find-a-Time) -- absent here means "no badge", never a
  // fabricated default. See mapPlanRow's own doc comment.
  match?: 'Best Match' | 'Good Match';
  note: string;
  accent: string;
  when: string;
  plannedStartAt: string;
  plannedEndAt: string;
  // DR4-E3 -- optional: a persisted plan with no saved recommendation text
  // (mapPlanRow) renders no paragraph at all rather than a fabricated
  // generic caption. A freshly-computed candidate (planPayloadFromCandidate)
  // always has real text and stays required there.
  details?: string;
  score?: number;
  googleCalendarUrl?: string;
  source?: 'Aura';
  status?: PersistedPlanStatus;
  loggedAt?: string;
  /** Event Location Plan Persistence V1 -- the immutable snapshot (both
   * present, or both absent -- never one without the other), kept
   * separately from the pre-formatted `time` string above so a future
   * surface can still read the raw timezone/location identity rather than
   * only ever having the already-formatted text. */
  eventTimezone?: string;
  eventLocationName?: string;
};

export type PlanApiRow = {
  id: string;
  title?: string | null;
  activityType?: string | null;
  // Planned Activity Canonical Identity Propagation V1 -- present here for
  // wire-format type completeness only; no UI reads or displays this field
  // (no badge/label/icon). See apps/web/lib/db.ts's PlannedActivity.activityId
  // for the full contract.
  activityId?: string | null;
  icon?: string | null;
  status?: PersistedPlanStatus | null;
  plannedStartAt: string | Date;
  plannedEndAt: string | Date;
  durationMinutes?: number | null;
  windowType?: string | null;
  windowLabel?: string | null;
  matchLabel?: string | null;
  score?: number | null;
  recommendation?: string | null;
  calendarUrl?: string | null;
  loggedAt?: string | Date | null;
  eventTimezone?: string | null;
  eventLocationName?: string | null;
};

/** TimingCandidateLabel -> friendly copy (section 11). Do not invent a second
 * fit classification -- this is purely a display mapping of the engine's own
 * label values. */
export const RESULT_LABEL_TEXT: Record<TimingCandidateLabel, string> = {
  EXCELLENT: 'Excellent fit',
  VERY_GOOD: 'Very good',
  GOOD: 'Good',
  USABLE: 'Usable',
  CAUTION: 'Caution',
};

export function durationLabel(minutes: number): string {
  if (minutes < 120) return `${minutes} min`;
  return `${minutes / 60} hours`;
}

export function minutesFromDuration(duration: string): number {
  const hourMatch = duration.match(/(\d+(?:\.\d+)?)\s*h/i);
  if (hourMatch) return Math.round(Number(hourMatch[1]) * 60);
  const minuteMatch = duration.match(/(\d+)\s*min/i);
  if (minuteMatch) return Number(minuteMatch[1]);
  return 60;
}

export function planIconForTitle(title: string): PlanIcon {
  const lower = title.toLowerCase();
  if (/workout|exercise|gym|training/.test(lower)) return 'workout';
  if (/date|relationship|romantic/.test(lower)) return 'heart';
  if (/study|learn|course|exam|read/.test(lower)) return 'study';
  if (/meditat|breath|prayer/.test(lower)) return 'meditate';
  if (/meeting|review|call|interview|presentation/.test(lower)) return 'meeting';
  if (/journey|travel|trip|flight|train/.test(lower)) return 'journey';
  return 'focus';
}

export function planAccentForTitle(title: string): string {
  const lower = title.toLowerCase();
  if (/date|relationship|romantic|workout|exercise|gym/.test(lower)) return '#ff5f95';
  if (/study|learn|meditat|breath/.test(lower)) return '#4ade80';
  if (/journey|travel|trip/.test(lower)) return '#facc15';
  return '#38bdf8';
}

export function addDays(date: Date, days: number): Date {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export function formatShortDate(date: Date): string {
  return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' });
}

export function getTodayForTimezone(timezone?: string): Date {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone || undefined,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  });
  const parts = formatter.formatToParts(new Date());
  const year = Number(parts.find((part) => part.type === 'year')?.value);
  const month = Number(parts.find((part) => part.type === 'month')?.value);
  const day = Number(parts.find((part) => part.type === 'day')?.value);
  if (!year || !month || !day) return new Date();
  return new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
}

export function formatPlanDay(date: Date): string {
  const today = getTodayForTimezone();
  const dateKey = date.toISOString().slice(0, 10);
  const todayKey = today.toISOString().slice(0, 10);
  const tomorrowKey = addDays(today, 1).toISOString().slice(0, 10);
  if (dateKey === todayKey) return 'Today';
  if (dateKey === tomorrowKey) return 'Tomorrow';
  return formatShortDate(date);
}

/** Event Location Plan Persistence V1: `timezone`, when given, is used
 * explicitly (Intl `timeZone` option) -- for a plan with an Event Location
 * snapshot this is `plan.eventTimezone`, and for an ordinary plan rendered
 * inside PlanWithAuraView it's the component's own Timing Location prop
 * (the "intended" fallback the audit found already threaded through but
 * never actually used here). Omitted entirely, this preserves the exact
 * prior browser-local behavior -- the one call site with no timezone of
 * any kind available (saveUpcomingPlanFromCandidate's own immediate
 * post-save response mapping, outside any component). */
export function formatPlanTimeRange(start: Date, end: Date, timezone?: string): string {
  const opts: Intl.DateTimeFormatOptions = timezone ? { hour: 'numeric', minute: '2-digit', timeZone: timezone } : { hour: 'numeric', minute: '2-digit' };
  return `${start.toLocaleTimeString('en-US', opts)} - ${end.toLocaleTimeString('en-US', opts)}`;
}

export function windowTypeFromLabel(label?: string): string {
  if (!label) return 'NEUTRAL';
  if (/abhijit/i.test(label)) return 'ABHIJIT';
  if (/gulika|steady/i.test(label)) return 'GULIKA';
  if (/brahma/i.test(label)) return 'BRAHMA';
  if (/rahu/i.test(label)) return 'RAHU_KALAM';
  if (/yama/i.test(label)) return 'YAMA';
  return 'NEUTRAL';
}

/** `fallbackTimezone` -- the Timing Location to format in when this row has
 * no Event Location snapshot of its own (row.eventTimezone null). Omitted
 * by the one call site with nothing better available (see
 * formatPlanTimeRange's own doc comment); every call site inside the
 * PlanWithAuraView component itself passes its own `timezone` prop. */
/** Exhaustive on purpose: a new persisted status fails to compile here
 * instead of silently falling through to UPCOMING. An absent status (legacy
 * rows/fixtures) has always meant UPCOMING. */
export function mapPersistedPlanStatus(status: PersistedPlanStatus | null | undefined): PersistedPlanStatus {
  switch (status) {
    case undefined:
    case null:
      return 'UPCOMING';
    case 'UPCOMING':
    case 'LOGGED':
    case 'CANCELLED':
    case 'SKIPPED':
    case 'MOVED':
      return status;
    default: {
      const unreachable: never = status;
      throw new Error(`Unknown plan status: ${String(unreachable)}`);
    }
  }
}

/** Plan-tab presentation (the mapper above never decides this): only an
 * UPCOMING plan is actionable work; only LOGGED shows as completed.
 * CANCELLED/SKIPPED/MOVED have no representation on this surface. Status-only
 * on purpose -- `isUpcomingOrCurrentPlan`/`isMissedPlan` below narrow this
 * further by time; this function itself stays the plain "not terminal" check
 * both of them (and isAwaitingConfirmationPlan) are built on. */
export const isActionableUpcomingPlan = (plan: { status?: PersistedPlanStatus }): boolean => (plan.status ?? 'UPCOMING') === 'UPCOMING';
export const isCompletedPlan = (plan: { status?: PersistedPlanStatus }): boolean => plan.status === 'LOGGED';

/**
 * DR4-E1 (Time-Aware Upcoming Plans) -- the lifecycle an UPCOMING plan
 * actually has right now, reusing dailyAgenda.ts's `timeBasedStatus` exactly
 * (never a second definition): a terminal persisted status (LOGGED/
 * CANCELLED/SKIPPED/MOVED) always wins over time, mirroring
 * `planToAgendaItem`'s own precedence; only while status is still UPCOMING
 * is the lifecycle time-derived (UPCOMING/STARTING_SOON/CURRENT/MISSED).
 * MISSED is never persisted -- this is computed fresh on every call, from
 * the caller's own `now`, exactly like Home's agenda.
 */
export function derivedPlanLifecycle(
  plan: { status?: PersistedPlanStatus; plannedStartAt: string; plannedEndAt: string },
  now: Date = new Date()
): PersistedPlanStatus | 'STARTING_SOON' | 'CURRENT' | 'MISSED' {
  const status = mapPersistedPlanStatus(plan.status);
  if (status !== 'UPCOMING') return status;
  // timeBasedStatus's declared return type is dailyAgenda.ts's full
  // DailyAgendaItemStatus (it's shared with Moments, which also use
  // COMPLETED/WAITING/CONFIRMED) -- but its OWN body only ever returns
  // 'MISSED' | 'CURRENT' | 'STARTING_SOON' | 'UPCOMING'. Narrowed here
  // rather than widening this function's own return type to a union
  // callers of a PLAN's lifecycle would never actually see.
  return timeBasedStatus(new Date(plan.plannedStartAt), new Date(plan.plannedEndAt), now) as 'UPCOMING' | 'STARTING_SOON' | 'CURRENT' | 'MISSED';
}

/**
 * DR4-E1 -- the Plan tab's "Upcoming Plans" default collection: persisted
 * UPCOMING whose derived lifecycle has NOT elapsed (UPCOMING/STARTING_SOON/
 * CURRENT). This is what fixes the DR4-E audit's reported bug: an activity
 * scheduled for a past date, never logged/skipped/cancelled/moved, no
 * longer counts as "upcoming" here even though its persisted status is
 * still UPCOMING (see isActionableUpcomingPlan's own doc comment -- that
 * status-only check is unchanged and still correct for what IT answers;
 * this is a narrower, time-aware question for a different surface).
 */
export const isUpcomingOrCurrentPlan = (
  plan: { status?: PersistedPlanStatus; plannedStartAt: string; plannedEndAt: string },
  now: Date = new Date()
): boolean => isActionableUpcomingPlan(plan) && derivedPlanLifecycle(plan, now) !== 'MISSED';

/**
 * Insights V1 PR7 -- presentation-only filter for the "Review plans" CTA's
 * filtered list (AURA_INSIGHTS_V1_PRODUCT_COMPLETION_AUDIT.md finding
 * F-4): an UPCOMING plan whose own window has already elapsed, mirroring
 * classifyPlanningStatus's AWAITING_CONFIRMATION branch
 * (insightsReporting.ts) exactly -- the server-side definition is the
 * source of truth; this just re-applies the identical, already-fetched
 * `plannedEndAt` fact to the client's own already-loaded plan list, never
 * a second eligibility rule. DR4-E1: now expressed through
 * `derivedPlanLifecycle` (same MISSED boundary, `now` now an explicit,
 * optional, testable parameter) rather than a second raw date comparison
 * -- the condition itself is unchanged (`plannedEndAt` strictly before
 * `now`), so every existing caller's behavior is unchanged.
 */
export const isAwaitingConfirmationPlan = (
  plan: { status?: PersistedPlanStatus; plannedStartAt: string; plannedEndAt: string },
  now: Date = new Date()
): boolean => derivedPlanLifecycle(plan, now) === 'MISSED';

/**
 * DR4-E1 -- the Plan tab's "Missed" collection, under the ticket's own
 * vocabulary for this audit: persisted UPCOMING whose scheduled end has
 * elapsed. Identical condition to `isAwaitingConfirmationPlan` above (same
 * underlying fact, two product-surface names for it) -- re-exported rather
 * than duplicating the check a third time. DR4-E1 scope is classification/
 * ordering only: these plans are still reachable (via "View all" in
 * PlanWithAuraView.tsx), just no longer displayed or counted as "upcoming."
 * DR4-E2 will give this collection its own presentation.
 */
export const isMissedPlan = isAwaitingConfirmationPlan;

export function mapPlanRow(row: PlanApiRow, fallbackTimezone?: string): UpcomingPlan {
  const start = new Date(row.plannedStartAt);
  const end = new Date(row.plannedEndAt);
  const title = row.title || row.activityType || 'Planned activity';
  const status = mapPersistedPlanStatus(row.status);
  const eventTimezone = row.eventTimezone || undefined;
  const eventLocationName = row.eventLocationName || undefined;
  return {
    id: row.id,
    title,
    icon: planIconForTitle(row.icon || title),
    when: formatPlanDay(start),
    plannedStartAt: start.toISOString(),
    plannedEndAt: end.toISOString(),
    duration: `${row.durationMinutes ?? 60} min`,
    time: formatPlanTimeRange(start, end, eventTimezone ?? fallbackTimezone),
    window: row.windowLabel || row.windowType || 'Neutral Flow',
    // DR4-E3 -- the DR4-E audit's own finding: this previously defaulted
    // ANY non-'Good Match' value (null, missing, or an unrecognized string)
    // to 'Best Match', fabricating a rating for plans that were never
    // actually classified (manually-created plans, Day Builder adds).
    // Explicit values are preserved verbatim; everything else is undefined
    // (no badge), never silently upgraded.
    match: row.matchLabel === 'Best Match' ? 'Best Match' : row.matchLabel === 'Good Match' ? 'Good Match' : undefined,
    note: status === 'LOGGED' ? 'Logged' : row.matchLabel || 'Good match',
    accent: planAccentForTitle(title),
    // DR4-E3 -- the DR4-E audit's other finding: this generic reassurance
    // caption previously filled in for EVERY plan with no saved
    // recommendation text, reading as personalized guidance when it was
    // pure filler. A genuine recommendation.details (search-and-save
    // flows) is preserved verbatim; everything else renders no paragraph
    // at all (UpcomingPlan/MissedActivityCard already skip the <p> when
    // details is falsy).
    details: row.recommendation || undefined,
    score: typeof row.score === 'number' ? row.score : undefined,
    googleCalendarUrl: row.calendarUrl || undefined,
    source: 'Aura',
    status,
    loggedAt: row.loggedAt ? new Date(row.loggedAt).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }) : undefined,
    eventTimezone,
    eventLocationName,
  };
}

export function findCandidateKey(candidate: TimingCandidate): string {
  return `${candidate.metadata.activityType}-${candidate.start}-${candidate.end}`.toLowerCase();
}

/** Adapts a TimingCandidate into the existing UpcomingPlan/handleSavePlan
 * pipeline (POST /api/plans) so Find/Check/Compare's "Use this time" reuses
 * the same persistence path the original Plan flow already had, rather than
 * a second save mechanism. candidate.metadata.windowLabel is produced by the
 * same formatWindowLabel() the old slot-task-backed flow used, so
 * windowTypeFromLabel() above still resolves it correctly.
 *
 * `sharedWithName` (Shared Muhurtham brief section 18): PlannedActivity has
 * no JSON metadata column and this PR does not add one ("do not create a new
 * plan model solely for this") -- so when a SHARED "Use this time" saves a
 * plan, the only schema-migration-free way to preserve that context is a
 * short human-readable prefix on the existing `details`/`recommendation`
 * text field. Omitted (undefined), `details` is byte-identical to before --
 * GENERAL/PERSONAL "Use this time" callers are completely unaffected.
 *
 * `eventLocation` (Event Location Plan Persistence V1): when the candidate
 * being saved came from a custom Event Location search (never the ordinary
 * Timing Location), this is PR #55's own resultEventLocation -- the
 * client-side snapshot of the location that actually produced the search
 * result, already trimmed to `{cityName, timezone}` (no coordinates) by the
 * caller. Used for the IMMEDIATE display time here (so the returned
 * UpcomingPlan is correct without waiting for a reload) and threaded
 * through to persistence by saveUpcomingPlanFromCandidate() (PlanWithAuraView.tsx).
 * Omitted entirely for an ordinary Timing Location save -- `time` falls
 * back to plain browser-local formatting here exactly as before, since
 * this function (unlike mapPlanRow's own call sites inside the component)
 * has no Timing Location value of its own to fall back to. */
export function planPayloadFromCandidate(candidate: TimingCandidate, durationMinutes: number, sharedWithName?: string, eventLocation?: PlanEventLocation): UpcomingPlan {
  const start = new Date(candidate.start);
  const end = new Date(candidate.end);
  const title = candidate.metadata.activityType;
  const reasonDetails = summarizeReasonsPlainly(candidate.reasons) ?? 'Aura found this as a good moment for this activity.';
  return {
    id: `aura-${findCandidateKey(candidate)}`.replace(/[^a-z0-9]+/g, '-'),
    title,
    icon: planIconForTitle(title),
    when: candidate.metadata.dateLabel,
    plannedStartAt: candidate.start,
    plannedEndAt: candidate.end,
    duration: durationLabel(durationMinutes),
    time: formatPlanTimeRange(start, end, eventLocation?.timezone),
    window: candidate.metadata.windowLabel,
    match: candidate.label === 'EXCELLENT' || candidate.label === 'VERY_GOOD' ? 'Best Match' : 'Good Match',
    note: RESULT_LABEL_TEXT[candidate.label],
    accent: planAccentForTitle(title),
    details: sharedWithName ? `❤️ Planned with ${sharedWithName}. ${reasonDetails}` : reasonDetails,
    score: candidate.score * 10,
    googleCalendarUrl: buildGoogleCalendarUrl(title, candidate.start, candidate.end),
    source: 'Aura',
    eventTimezone: eventLocation?.timezone,
    eventLocationName: eventLocation?.cityName,
  };
}

/** `guestConversionToken` (Recipient Conversion V1 Hardening, brief section
 * 10) is optional and only ever passed by the guest-conversion save path
 * (apps/web/app/find/GuestFindClient.tsx) -- every other caller of
 * saveUpcomingPlanFromCandidate (PlanWithAuraView.tsx) is unaffected. POST
 * /api/plans uses it purely as an idempotency key (see that route's own
 * doc comment); it never changes what gets created, only whether a retry
 * creates a SECOND Plan.
 *
 * `clientRequestId` (Intentional Day Builder V1, brief section 20) is the
 * same kind of idempotency key, only ever passed by Day Builder's own Add
 * action (DayBuilderCard.tsx) -- independent of guestConversionToken, never
 * both at once in practice. A stable id per (suggestion, local date) so a
 * double-tap or a benign re-render never creates a second Plan.
 *
 * `eventLocation` (Event Location Plan Persistence V1): only ever passed by
 * MuhurthamFinderView, and only ever PR #55's resultEventLocation (the
 * snapshot of the location that produced the currently-displayed result) --
 * never live picker state, never reconstructed from the User's current
 * Timing Location. Absent for every other caller and for an ordinary
 * Timing-Location Muhurtham save, in which case the persisted
 * eventTimezone/eventLocationName are both null (see route.ts's own
 * validation) -- byte-identical to this function's pre-persistence
 * behavior for those callers.
 *
 * Options-object shape (rather than a sixth positional parameter on
 * saveUpcomingPlanFromCandidate, PlanWithAuraView.tsx): that function
 * already had four optional trailing parameters before this PR: a fifth
 * positional would have made the call site unreadable without counting
 * commas.
 *
 * `activityId` (Planned Activity Canonical Identity Propagation V1): the
 * caller's own already-known canonical ActivityProfile.id (Day Builder's
 * suggestion.activityId, PlanWithAuraView's own resolved catalog
 * selection, Muhurtham Finder's activityId dropdown -- all real, already-
 * validated ids from the SAME FULL_ACTIVITY_CATALOG namespace), or omitted
 * when the Plan originates from free text / no clean canonical match. This
 * function performs NO resolution/inference of its own -- it only threads
 * a value the caller already has. The server (POST /api/plans) remains the
 * sole validation authority regardless of what's passed here.
 */
export interface SaveUpcomingPlanOptions {
  sharedWithName?: string;
  guestConversionToken?: string;
  clientRequestId?: string;
  eventLocation?: PlanEventLocation;
  activityId?: string | null;
}
